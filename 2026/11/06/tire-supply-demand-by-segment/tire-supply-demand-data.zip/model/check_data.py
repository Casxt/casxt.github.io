#!/usr/bin/env python3
"""Check the public observation snapshot without downloading any source."""

import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read(path):
    with path.open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))


def main():
    facts = read(ROOT / 'data/facts.csv')
    sources = read(ROOT / 'data/sources.csv')
    baselines = read(ROOT / 'model/us_baselines.csv')
    classification = read(ROOT / 'data/classification.csv')
    issues = read(ROOT / 'data/conflicts.csv')
    ids = {r['source_id'] for r in sources}
    checks = []
    def add(name, condition, detail):
        checks.append({'check_id': name, 'status': 'PASS' if condition else 'FAIL', 'detail': detail})
    add('observation_keys_unique', len({r['observation_id'] for r in facts}) == len(facts), 'One stable observation key; metric names alone may repeat')
    add('source_keys_unique', len(ids) == len(sources), 'Different source IDs can share URLs; not independent evidence counts')
    add('all_fact_sources_resolve', all(r['source_id'] in ids for r in facts), 'Every observation joins to the source ledger')
    add('allowed_data_status', all(r['data_status'] in {'actual','estimate','external_scenario','model_assumption','calculated'} for r in facts), 'No unclassified status')
    add('original_status_retained', all(r['original_data_status'] for r in facts), 'Status normalization does not erase source-table status')
    add('scope_unit_period_preserved', all(all(r[k] for k in ['product_spec','region','period','unit','conversion_formula']) for r in facts), 'No removal of product/region/time/unit/formula')
    add('cutoff_respected', all(r['retrieved_date'] <= '2026-11-06' for r in facts), 'Observation retrieval cutoff; source dates may be partial')
    add('nine_main_categories', len(classification) == len({r['category_id'] for r in classification}) == 9, 'Attributes remain outside the nine additive-purpose groups')
    add('no_unresolved_material_conflict', all(r['status'].startswith('resolved_') or r['status']=='boundary_unidentified' for r in issues), 'Unidentified global balance is a boundary, not an adopted numerical claim')
    for row in baselines:
        if row['segment']=='Truck_Bus':
            candidates = [r for r in facts if r['segment']=='truck_bus' and r['source_id']=='T04' and r['region']=='US' and r['period']==row['year'] and r['metric']=='shipments_'+row['channel']]
        else:
            mid='US_'+row['year']+'_'+row['segment'].replace('_','')+'_'+row['channel']
            candidates = [r for r in facts if r['original_metric_id']==mid and r['source_id']=='PL03']
        add('baseline_source_'+row['year']+'_'+row['segment']+'_'+row['channel'], len(candidates)==1 and float(candidates[0]['value'])==float(row['value']), 'Baseline value agrees with normalized source observation')
    capacity=read(ROOT/'data/truck_overseas_capacity.csv')
    add('source_dashes_not_zero', all(r['realized_2025']=='' and r['missing_status']=='source_dash_not_confirmed_zero' for r in capacity if r['region'] in {'Egypt','Algeria'}), 'Original dashes retained as unknown, not confirmed zero')
    for col,total in [('realized_2025',40.05),('planned_total',62.05)]:
        subtotal=sum(float(r[col]) for r in capacity if r['region']!='TOTAL' and r[col]!='')
        add('capacity_known_cells_'+col, abs(subtotal-total)<1e-9, 'Sum of listed known cells matches published table total; no assumption of missing values')
    path=ROOT/'results/data_checks.csv'
    path.parent.mkdir(exist_ok=True)
    with path.open('w',encoding='utf-8-sig',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=['check_id','status','detail']);writer.writeheader();writer.writerows(checks)
    failed=[r['check_id'] for r in checks if r['status']!='PASS']
    print(json.dumps({'facts':len(facts),'source_entries':len(sources),'exact_source_urls':len({r['url'] for r in sources}),'checks':len(checks),'failed':failed},ensure_ascii=False))
    if failed:
        raise SystemExit(1)


if __name__=='__main__':
    main()
