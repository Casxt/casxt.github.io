#!/usr/bin/env python3
"""Reproduce conditional US new-tire shipment scenarios using only stdlib."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODEL = ROOT / 'model'
RESULTS = ROOT / 'results'


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        raise ValueError(f'No rows for {path}')
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    RESULTS.mkdir(parents=True, exist_ok=True)
    baselines = read_csv(MODEL / 'us_baselines.csv')
    assumptions = read_csv(MODEL / 'assumptions.csv')
    parameters = {(r['scenario'], r['family']): r for r in assumptions}
    scenarios = ['Lower', 'Reference', 'Upper']
    components = ['Passenger', 'Light_Truck', 'Truck_Bus']
    channels = ['OE', 'RE']
    values = {(int(r['year']), r['segment'], r['channel']): float(r['value']) for r in baselines}
    output = []
    diagnostics = []
    for scenario in scenarios:
        for segment in components:
            family = 'Truck_Bus' if segment == 'Truck_Bus' else 'Passenger_Light_Truck'
            p = parameters[(scenario, family)]
            for channel in channels:
                anchor = values[(2026, segment, channel)]
                for year in range(2026, 2031):
                    n = year - 2026
                    production = (1 + float(p['oe_vehicle_production_growth'])) ** n
                    fitment = (1 + float(p['oe_fitment_per_vehicle_growth'])) ** n
                    fleet = (1 + float(p['re_fleet_growth'])) ** n
                    mileage = (1 + float(p['re_activity_growth'])) ** n
                    life = (1 + float(p['re_single_tread_life_growth'])) ** n
                    new_share = (1 + float(p['re_new_tire_service_share_index_growth'])) ** n
                    channel_multiplier = 1.0 if n == 0 else float(p['channel_shipment_to_consumption_multiplier'])
                    factor = (production * fitment if channel == 'OE' else fleet * mileage / life * new_share) * channel_multiplier
                    demand = anchor * factor
                    output.append({
                        'region': 'US', 'segment': segment, 'channel': channel,
                        'year': year, 'scenario': scenario,
                        'value_million_tires': round(demand, 6),
                        'data_status': 'external_scenario' if year == 2026 else 'calculated',
                        'anchor_year': 2026,
                        'anchor_status': 'external_scenario',
                        'anchor_source_id': 'PL03' if segment != 'Truck_Bus' else 'T04',
                        'output_scope': 'conditional_industry_shipments_not_terminal_installations',
                        'oe_vehicle_production_index': round(100 * production, 6),
                        'oe_fitment_index': round(100 * fitment, 6),
                        're_fleet_index': round(100 * fleet, 6),
                        're_activity_index': round(100 * mileage, 6),
                        're_single_tread_life_index': round(100 * life, 6),
                        're_new_tire_service_share_index': round(100 * new_share, 6),
                        're_activity_definition': p['re_activity_definition'],
                        'channel_shipment_to_consumption_multiplier': channel_multiplier,
                        'sustainable_supply_million_tires': '',
                        'inventory_change_million_tires': '',
                        'physical_shortfall_million_tires': '',
                        'balance_status': 'not_identifiable_public_supply_inventory_coverage_missing',
                    })
                    expected = anchor * factor
                    diagnostics.append(abs(demand - expected))
    write_csv(RESULTS / 'us_shipment_scenarios.csv', output)
    totals = []
    for scenario in scenarios:
        for year in range(2026, 2031):
            part = [r for r in output if r['scenario'] == scenario and r['year'] == year]
            entry = {'region': 'US', 'year': year, 'scenario': scenario}
            for segment in components:
                for channel in channels:
                    entry[f'{segment}_{channel}'] = next(r['value_million_tires'] for r in part if r['segment'] == segment and r['channel'] == channel)
                entry[f'{segment}_total'] = round(sum(r['value_million_tires'] for r in part if r['segment'] == segment), 6)
            entry['six_component_sum_million_tires'] = round(sum(r['value_million_tires'] for r in part), 6)
            entry['data_status'] = 'external_scenario' if year == 2026 else 'calculated'
            entry['not_an_official_total_or_physical_shortfall'] = 'true'
            totals.append(entry)
    write_csv(RESULTS / 'us_shipment_summary.csv', totals)

    # Explicit sensitivity changes one input, never the final shipment total.
    sensitivities = []
    for segment in components:
        family = 'Truck_Bus' if segment == 'Truck_Bus' else 'Passenger_Light_Truck'
        p = parameters[('Reference', family)]
        for driver in ['re_activity_growth', 're_single_tread_life_growth']:
            for step in [-0.01, 0.01]:
                changed = dict(p)
                changed[driver] = str(float(p[driver]) + step)
                base = values[(2026, segment, 'RE')]
                quantity = base * ((1 + float(changed['re_fleet_growth'])) * (1 + float(changed['re_activity_growth'])) / (1 + float(changed['re_single_tread_life_growth'])) * (1 + float(changed['re_new_tire_service_share_index_growth']))) ** 4
                reference = next(r['value_million_tires'] for r in output if r['scenario'] == 'Reference' and r['segment'] == segment and r['channel'] == 'RE' and r['year'] == 2030)
                sensitivities.append({'segment': segment, 'channel': 'RE', 'year': 2030, 'scenario': 'Reference_one_factor', 'driver': driver, 'annual_driver_change_percentage_points': step * 100, 'value_million_tires': round(quantity, 6), 'difference_from_reference_million_tires': round(quantity - reference, 6), 'data_status': 'calculated'})
    write_csv(RESULTS / 'us_one_factor_sensitivity.csv', sensitivities)

    checks = []
    def check(name: str, valid: bool, detail: str) -> None:
        checks.append({'check_id': name, 'status': 'PASS' if valid else 'FAIL', 'detail': detail})
    check('baseline_unique_keys', len(values) == len(baselines), 'year+segment+channel unique')
    check('baseline_complete', len(baselines) == 12 and all((y,s,c) in values for y in [2025,2026] for s in components for c in channels), '2025/2026 x three segments x two channels')
    check('baseline_finite_positive', all(math.isfinite(v) and v > 0 for v in values.values()), 'No negative or non-finite shipment anchor')
    check('2025_historical_mixed_status', all(r['data_status'] == 'estimate' for r in baselines if r['year'] == '2025'), 'Ended-year historical published values include actual and estimated data')
    check('2026_external_status', all(r['data_status'] == 'external_scenario' for r in baselines if r['year'] == '2026'), '2026 is external forecast, never annual actual')
    check('assumption_keys', len(parameters) == len(assumptions) == 6, 'Three conditions x two driver families')
    check('row_coverage', len(output) == 90, '3 conditions x 3 segments x 2 channels x 5 years')
    check('anchor_continuity', all(abs(r['value_million_tires']-values[(2026,r['segment'],r['channel'])]) < 1e-9 for r in output if r['year']==2026), 'Every condition starts from the same external 2026 forecast')
    check('formula_identity', max(diagnostics) < 1e-9, f'Max formula residual {max(diagnostics):.1g}; output CSV rounded to 0.000001 million')
    check('nonnegative_shipments', all(r['value_million_tires'] > 0 for r in output), 'Model has no negative quantities')
    check('retread_not_in_tread_life', all(p['re_single_tread_life_includes_retreading'] == 'false' for p in assumptions), 'Retreading appears only in new-tire service-share factor')
    check('channel_bridge_explicit', all(float(p['channel_shipment_to_consumption_multiplier']) == 1 for p in assumptions), 'Relative shipment-to-consumption ratio held at 2026 anchor; no extra restock/destock recovery assumed; absolute inventory unknown')
    check('truck_activity_no_duplicate_fleet', all(float(p['re_fleet_growth']) == 0 and p['re_activity_definition'] == 'total_tire_position_km_including_fleet' for p in assumptions if p['family'] == 'Truck_Bus'), 'Truck activity already includes fleet size; do not add fleet growth again')
    check('passenger_retread_factor_one', all(float(p['re_new_tire_service_share_index_growth']) == 0 for p in assumptions if p['family'] == 'Passenger_Light_Truck'), 'No unsupported passenger retread adoption')
    check('unknown_balance_blank', all(r[k] == '' for r in output for k in ['sustainable_supply_million_tires','inventory_change_million_tires','physical_shortfall_million_tires']), 'Unknown supply/inventory/gap retained blank, never zero')
    check('summary_component_identity', all(abs(r['six_component_sum_million_tires']-sum(r[f'{s}_{c}'] for s in components for c in channels)) < 2e-6 for r in totals), 'Summary equals six rounded component shipments; tolerance 0.000002 million')
    for year in range(2027,2031):
        vals = {r['scenario']:r['six_component_sum_million_tires'] for r in totals if r['year']==year}
        check(f'conditions_order_{year}', vals['Lower'] <= vals['Reference'] <= vals['Upper'], 'Driver combinations generate ordered volumes; no probability attached')
    published = {2025:336.3, 2026:330.3}
    rounding = []
    for year in [2025,2026]:
        component_sum = sum(v for (y,_,_),v in values.items() if y == year)
        difference = component_sum - published[year]
        rounding.append({'year':year,'six_rounded_component_sum_million_tires':round(component_sum,6),'official_published_total_million_tires':published[year],'difference_million_tires':round(difference,6),'treatment':'keep_original_components_and_official_total; do_not_force_adjust'})
        check(f'published_rounding_{year}', abs(difference) <= 0.100001, f'Rounded components minus published total = {difference:.1f} million; not a stock flow')
    write_csv(RESULTS / 'official_total_rounding.csv', rounding)
    write_csv(RESULTS / 'Checks.csv', checks)
    failed = [r['check_id'] for r in checks if r['status'] != 'PASS']
    print(json.dumps({'output_rows':len(output), 'summary_rows':len(totals), 'checks':len(checks), 'failed':failed}, ensure_ascii=False))
    if failed:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
