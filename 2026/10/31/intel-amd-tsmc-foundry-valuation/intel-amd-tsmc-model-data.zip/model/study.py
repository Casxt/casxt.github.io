"""Bind the shared research root and name the three issuers once."""

from pathlib import Path

from metrics import FACT_FILES, FACTS

from mid_term_capital.view_engine import loader

ROOT = Path(__file__).resolve().parents[1]
STUDY = loader.bind(ROOT, FACT_FILES, FACTS)
ISSUERS = {
    "intel": "issuer:英特尔_INTC",
    "amd": "issuer:超威半导体_AMD",
    "tsmc": "issuer:台积电_2330",
}
SECURITIES = {
    "intel": "security:英特尔美股_INTC",
    "amd": "security:超威半导体美股_AMD",
    "tsmc": "security:台积电台股_2330.TW",
}
EXPLICIT_YEARS = tuple(range(2026, 2031))
TARGET_YEARS = (2028, 2030)
LATEST = {"intel": ("2026-09-26", "Q3"), "amd": ("2026-06-27", "H1"), "tsmc": ("2026-09-30", "Q3")}
TENURES = {"intel": "2025-03-18", "amd": "2014-10-08", "tsmc": "2018-06-05"}

# TSMC Q3 slides disclose a diluted average; use the last verified issued count.
SHARE_BASE = {**LATEST, "tsmc": ("2026-06-30", "H1")}
