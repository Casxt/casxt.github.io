"""Map reviewed result schemas to their terminal views."""

from schemas import EXTRA
from views import core, deep, market

from mid_term_capital.view_engine import result_schema
from mid_term_capital.view_engine.calculate import ResultTable

RESULT_TABLES = [
    ResultTable("history_facts.csv", deep.history, result_schema.PREDICTION_KEY),
    ResultTable("forecast.csv", deep.forecast, result_schema.PREDICTION_KEY),
    ResultTable("valuation.csv", deep.valuation, result_schema.VALUATION_KEY),
    ResultTable("returns.csv", deep.returns, result_schema.RETURNS_KEY),
]
for name, instance in [
    ("financial_summary.csv", core.financial_summary),
    ("business_mix.csv", core.business_mix),
    ("capital_details.csv", core.capital_details),
    ("scale_check.csv", core.scale_check),
    ("capital_recovery.csv", deep.projection),
    ("buy_prices.csv", deep.buy_prices),
    ("valuation_evidence.csv", deep.evidence),
    ("reverse_valuation.csv", deep.reverse),
    ("market_comparison.csv", market.market_comparison),
    ("historical_returns.csv", market.historical_returns),
    ("historical_valuation.csv", market.historical_valuation),
    ("guidance_check.csv", market.guidance_check),
    ("profit_guidance_check.csv", market.profit_guidance_check),
    ("disclosure_screen.csv", market.disclosure_screen),
]:
    RESULT_TABLES.append(ResultTable(name, instance, EXTRA[name][1]))
