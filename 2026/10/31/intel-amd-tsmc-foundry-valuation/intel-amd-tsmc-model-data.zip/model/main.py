"""Rebuild the selected scenario from canonical facts and parameters."""

from study import STUDY
from tables import RESULT_TABLES

from mid_term_capital.view_engine.calculate import calculate

if __name__ == "__main__":
    calculate(STUDY, RESULT_TABLES)
