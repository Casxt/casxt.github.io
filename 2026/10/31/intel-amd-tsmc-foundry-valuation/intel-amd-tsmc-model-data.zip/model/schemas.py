"""Declare only report tables beyond the four shared framework schemas."""

import polars as pl

from mid_term_capital.view_engine import Field, result_schema

EXTRA = {}


def register(name, schema, key, units):
    result_schema.register(name, schema, key)
    EXTRA[name] = (schema, key)
    return {k: Field(t, units.get(k), "结果字段：" + k) for k, t in schema.items()}


FINANCIAL = register(
    "financial_summary.csv",
    {
        "entity_id": pl.String,
        "period_end": pl.Date,
        "period_type": pl.String,
        **{
            k: pl.Float64
            for k in [
                "revenue",
                "gross_margin",
                "operating_profit",
                "operating_margin",
                "net_income",
                "cfo",
                "cfo_continuing",
                "capex_cash",
                "gross_equipment_cash",
                "fcf_cfo_less_investing_capex",
                "cash_after_equipment",
                "cash_after_equipment_sbc",
                "cash_after_equipment_interest",
                "equity_parent",
                "cash",
                "debt_ex_lease",
                "net_debt_cash_only",
                "shares_outstanding",
                "diluted_average_shares",
                "dividends_paid",
                "buybacks_paid",
                "sbc",
                "acquisitions_paid",
                "roe_average",
                "eps_calculated",
                "inventory",
                "receivables",
                "lease_disclosed",
            ]
        },
    },
    ("entity_id", "period_end", "period_type"),
    {
        k: (
            "decimal_ratio"
            if k in ["gross_margin", "operating_margin", "roe_average"]
            else "currency_per_unit"
            if k == "eps_calculated"
            else "count"
            if "shares" in k
            else "currency"
        )
        for k in [
            "revenue",
            "gross_margin",
            "operating_profit",
            "operating_margin",
            "net_income",
            "cfo",
            "cfo_continuing",
            "capex_cash",
            "gross_equipment_cash",
            "fcf_cfo_less_investing_capex",
            "cash_after_equipment",
            "cash_after_equipment_sbc",
            "cash_after_equipment_interest",
            "equity_parent",
            "cash",
            "debt_ex_lease",
            "net_debt_cash_only",
            "shares_outstanding",
            "diluted_average_shares",
            "dividends_paid",
            "buybacks_paid",
            "sbc",
            "acquisitions_paid",
            "roe_average",
            "eps_calculated",
            "inventory",
            "receivables",
            "lease_disclosed",
        ]
    },
)
MIX = register(
    "business_mix.csv",
    {
        "entity_id": pl.String,
        "period_end": pl.Date,
        "period_type": pl.String,
        "segment_id": pl.String,
        "revenue": pl.Float64,
        "segment_profit": pl.Float64,
        "revenue_share": pl.Float64,
        "segment_margin": pl.Float64,
        "share_of_positive_segment_profit": pl.Float64,
    },
    ("entity_id", "period_end", "period_type", "segment_id"),
    {
        "revenue": "currency",
        "segment_profit": "currency",
        "revenue_share": "decimal_ratio",
        "segment_margin": "decimal_ratio",
        "share_of_positive_segment_profit": "decimal_ratio",
    },
)
SCALE = register(
    "scale_check.csv",
    {
        "entity_id": pl.String,
        "metric_id": pl.String,
        "period_end": pl.Date,
        "period_type": pl.String,
        "value": pl.Float64,
        "scale": pl.Float64,
        "scale_metric_id": pl.String,
        "ratio": pl.Float64,
        "threshold": pl.Float64,
        "exceeded": pl.Boolean,
    },
    ("entity_id", "metric_id", "period_end", "period_type"),
    {"value": "currency", "scale": "currency", "ratio": "multiple", "threshold": "multiple"},
)
MARKET = register(
    "market_comparison.csv",
    {
        "entity_id": pl.String,
        "price_date": pl.Date,
        "earnings_end": pl.Date,
        "share_count_end": pl.Date,
        "price": pl.Float64,
        "shares_outstanding": pl.Float64,
        "market_cap": pl.Float64,
        "revenue_ttm": pl.Float64,
        "net_income_ttm": pl.Float64,
        "pe_ttm": pl.Float64,
        "pb_latest": pl.Float64,
        "ps_ttm": pl.Float64,
    },
    ("entity_id", "price_date"),
    {
        "price": "currency_per_unit",
        "shares_outstanding": "count",
        "market_cap": "currency",
        "revenue_ttm": "currency",
        "net_income_ttm": "currency",
        "pe_ttm": "multiple",
        "pb_latest": "multiple",
        "ps_ttm": "multiple",
    },
)
TSR = register(
    "historical_returns.csv",
    {
        "entity_id": pl.String,
        "window": pl.String,
        "start_date": pl.Date,
        "end_date": pl.Date,
        "currency": pl.String,
        "price_return": pl.Float64,
        "total_return_reinvested": pl.Float64,
        "benchmark_return": pl.Float64,
        "benchmark_basis": pl.String,
    },
    ("entity_id", "window"),
    {
        "price_return": "decimal_ratio",
        "total_return_reinvested": "decimal_ratio",
        "benchmark_return": "decimal_ratio",
    },
)
CAPITAL = register(
    "scenario_economics.csv",
    {
        "entity_id": pl.String,
        "scenario": pl.String,
        "period": pl.String,
        "revenue": pl.Float64,
        "operating_profit": pl.Float64,
        "normalized_nopat": pl.Float64,
        "gross_equipment_cash_budget": pl.Float64,
        "margin_shock_profit": pl.Float64,
        "revenue_shock_profit": pl.Float64,
        "capex_ratio_shock_cash": pl.Float64,
        "margin_shock_ratio": pl.Float64,
        "revenue_shock_ratio": pl.Float64,
        "capex_cash_to_nopat_ratio": pl.Float64,
    },
    ("entity_id", "scenario", "period"),
    {
        k: "currency"
        for k in [
            "revenue",
            "operating_profit",
            "normalized_nopat",
            "gross_equipment_cash_budget",
            "margin_shock_profit",
            "revenue_shock_profit",
            "capex_ratio_shock_cash",
        ]
    }
    | {
        k: "decimal_ratio"
        for k in ["margin_shock_ratio", "revenue_shock_ratio", "capex_cash_to_nopat_ratio"]
    },
)
EVENTS = register(
    "disclosure_screen.csv",
    {
        "entity_id": pl.String,
        "event_date": pl.Date,
        "window_days": pl.Int32,
        "security_return": pl.Float64,
        "benchmark_return": pl.Float64,
        "relative_return": pl.Float64,
        "volume_ratio": pl.Float64,
        "flagged": pl.Boolean,
        "basis": pl.String,
    },
    ("entity_id", "event_date", "window_days"),
    {
        "window_days": "count",
        "security_return": "decimal_ratio",
        "benchmark_return": "decimal_ratio",
        "relative_return": "decimal_ratio",
        "volume_ratio": "multiple",
    },
)

HIST_VAL = register(
    "historical_valuation.csv",
    {
        "entity_id": pl.String,
        "fiscal_end": pl.Date,
        "quote_date": pl.Date,
        "price": pl.Float64,
        "pe_fy": pl.Float64,
        "pb_fy": pl.Float64,
        "ps_fy": pl.Float64,
    },
    ("entity_id", "fiscal_end"),
    {"price": "currency_per_unit", "pe_fy": "multiple", "pb_fy": "multiple", "ps_fy": "multiple"},
)
GUIDANCE = register(
    "guidance_check.csv",
    {
        "entity_id": pl.String,
        "announcement_date": pl.Date,
        "target_period": pl.String,
        "low_usd_million": pl.Float64,
        "high_usd_million": pl.Float64,
        "actual_usd_million": pl.Float64,
        "distance_from_midpoint": pl.Float64,
        "status": pl.String,
    },
    ("entity_id", "announcement_date", "target_period"),
    {
        "low_usd_million": "currency",
        "high_usd_million": "currency",
        "actual_usd_million": "currency",
        "distance_from_midpoint": "decimal_ratio",
    },
)
CAPITAL_DETAILS = register(
    "capital_details.csv",
    {
        "entity_id": pl.String,
        "metric_id": pl.String,
        "period_end": pl.Date,
        "period_type": pl.String,
        "value": pl.Float64,
        "source_ids": pl.String,
        "source_locator": pl.String,
    },
    ("entity_id", "metric_id", "period_end", "period_type"),
    {"value": "currency"},
)
PROFIT_GUIDANCE = register(
    "profit_guidance_check.csv",
    {
        "entity_id": pl.String,
        "announcement_date": pl.Date,
        "target_period": pl.String,
        "metric_id": pl.String,
        "guide_ratio_low": pl.Float64,
        "guide_ratio_high": pl.Float64,
        "actual_ratio": pl.Float64,
        "guide_eps": pl.Float64,
        "actual_eps": pl.Float64,
        "status": pl.String,
    },
    ("entity_id", "announcement_date", "target_period", "metric_id"),
    {
        **{k: "decimal_ratio" for k in ["guide_ratio_low", "guide_ratio_high", "actual_ratio"]},
        **{k: "currency_per_unit" for k in ["guide_eps", "actual_eps"]},
    },
)
