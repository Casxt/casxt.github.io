"""Render declared final results as human-readable, calculation-free HTML tables."""

from html import escape
from pathlib import Path

import polars as pl
import schemas  # noqa: F401 -- register study result schemas before readback

from mid_term_capital.view_engine.result_schema import read_result

ROOT = Path(__file__).resolve().parents[1]
NAMES = {
    "issuer:英特尔_INTC": "Intel",
    "security:英特尔美股_INTC": "Intel / USD",
    "issuer:超威半导体_AMD": "AMD",
    "security:超威半导体美股_AMD": "AMD / USD",
    "issuer:台积电_2330": "台积电",
    "security:台积电台股_2330.TW": "台积电 / TWD",
}
LABELS = {
    "entity_id": "主体",
    "period_end": "期末",
    "period_type": "期间（Q3为累计）",
    "revenue": "收入",
    "gross_margin": "毛利率",
    "operating_profit": "营业利润",
    "operating_margin": "营业利润率",
    "net_income": "归母净利",
    "cfo": "经营现金流",
    "cfo_continuing": "持续经营CFO",
    "capex_cash": "投资设备支出",
    "gross_equipment_cash": "设备及已披露租赁本金",
    "cash_after_equipment": "持续CFO减设备及已知租赁本金",
    "cash_after_equipment_sbc": "再减股份支付（经济成本代理）",
    "cash_after_equipment_interest": "再调整收到/支付利息",
    "equity_parent": "归母权益",
    "roe_average": "平均权益ROE",
    "dividends_paid": "实付股息",
    "buybacks_paid": "回购支出",
    "shares_outstanding": "期末普通股（百万）",
    "sbc": "股份支付",
    "debt_ex_lease": "有息债务账面值（未含租赁）",
    "net_debt_cash_only": "债务减现金（未减短投）",
    "cash": "现金",
    "lease_disclosed": "租赁已披露账面值",
    "price": "价格",
    "quote_date": "报价日",
    "price_date": "观察日",
    "earnings_end": "盈利截止期",
    "share_count_end": "股数核实期末",
    "pe_ttm": "PE TTM",
    "pb_latest": "PB",
    "ps_ttm": "PS TTM",
    "pe_fy": "PE FY",
    "pb_fy": "PB FY",
    "ps_fy": "PS FY",
    "fiscal_end": "财年期末",
    "window": "窗口",
    "start_date": "起点",
    "end_date": "终点",
    "price_return": "价格回报",
    "total_return_reinvested": "股息再投资总回报",
    "benchmark_return": "基准回报",
    "benchmark_basis": "基准口径",
    "scenario": "情景",
    "period": "财年",
    "normalized_nopat": "营业利润按假设税率税后化",
    "gross_equipment_cash_budget": "设备现金预算（非FCF）",
    "margin_shock_profit": "利润率+1pp影响",
    "revenue_shock_profit": "收入+10%贡献影响",
    "capex_ratio_shock_cash": "设备现金率+1pp需求",
    "target_year": "期末年份",
    "equity_value": "普通股条件价值",
    "diluted_shares": "假设稀释股数（百万）",
    "xirr": "税前持有年化回报",
    "threshold_price": "按12%折现的入场上限（假设）",
    "safety_margin": "1减现价/入场上限",
    "target_price": "期末条件价格",
    "total_return": "不再投资累计持有回报",
    "exit_date": "退出日",
    "announcement_date": "指引发布日",
    "target_period": "指引目标期",
    "low_usd_million": "收入下限（百万USD）",
    "high_usd_million": "收入上限",
    "actual_usd_million": "后续同口径收入",
    "distance_from_midpoint": "对中点偏差",
    "status": "核验状态",
    "event_date": "首次业绩公开日",
    "window_days": "前置交易日数",
    "security_return": "股价变动",
    "relative_return": "相对行业/台湾市场偏差",
    "volume_ratio": "对事前60日量比",
    "flagged": "需复核",
    "basis": "方法",
    "segment_id": "业务",
    "revenue_share": "相对合并收入占比",
    "segment_profit": "业务营业利润",
    "segment_margin": "业务营业利润率",
    "share_of_positive_segment_profit": "正利润业务占比（非集团利润占比）",
}
LABELS.update(
    {
        "guide_ratio_low": "利润率下限",
        "guide_ratio_high": "利润率上限",
        "actual_ratio": "实际利润率",
        "guide_eps": "指引USD/股",
        "actual_eps": "实际USD/股",
    }
)
LABELS.update(
    {
        "margin_shock_ratio": "利润率冲击/参考NOPAT",
        "revenue_shock_ratio": "收入冲击/参考NOPAT",
        "capex_cash_to_nopat_ratio": "设备现金冲击/参考NOPAT",
    }
)
PERCENT = {
    "gross_margin",
    "operating_margin",
    "roe_average",
    "price_return",
    "total_return_reinvested",
    "benchmark_return",
    "revenue_share",
    "segment_margin",
    "share_of_positive_segment_profit",
    "distance_from_midpoint",
    "security_return",
    "relative_return",
    "xirr",
    "total_return",
    "safety_margin",
    "margin_shock_ratio",
    "revenue_shock_ratio",
    "capex_cash_to_nopat_ratio",
    "guide_ratio_low",
    "guide_ratio_high",
    "actual_ratio",
}
MULTIPLES = {"pe_ttm", "pb_latest", "ps_ttm", "pe_fy", "pb_fy", "ps_fy", "volume_ratio"}
parts = [
    '<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>Intel、AMD、台积电研究结果底表</title><style>body{font:15px/1.7 system-ui,sans-serif;color:#172329;max-width:1500px;margin:40px auto;padding:0 24px}h1,h2{line-height:1.4}section{margin:40px 0}.scroll{overflow-x:auto}table{border-collapse:collapse;font-size:13px;white-space:nowrap}td,th{border:1px solid #d4dce0;padding:6px 10px;text-align:right}td:first-child,th:first-child{text-align:left}th{background:#edf2f4}tr:nth-child(even){background:#fafcfc}nav a{display:inline-block;margin:4px 14px 4px 0}p{max-width:1000px}</style><h1>Intel、AMD、台积电：最终结果底表</h1><p>研究截止日2026-10-30。金额为百万本币（Intel、AMD：USD；台积电：TWD），股数百万股；跨币种金额不相加。Q3表示年初至九月底累计；独立季度另见正文。空白即未披露或不适用，不能视为零。价格为10月30日冻结观察快照；历史收益截至10月29日。所有表从已声明schema的最终结果读取，无新增计算。</p><nav>'
]
sections = []


def table(anchor, title, frame, note):
    parts.append(f'<a href="#{anchor}">{title}</a>')
    headers = frame.columns
    body = (
        f'<section id="{anchor}"><h2>{title}</h2><p>{escape(note)}</p><div class="scroll"><table><thead><tr>'
        + "".join("<th>" + escape(LABELS.get(k, k)) + "</th>" for k in headers)
        + "</tr></thead><tbody>"
    )
    for row in frame.iter_rows(named=True):
        cells = []
        for k, v in row.items():
            if v is None:
                t = "—"
            elif isinstance(v, bool):
                t = "是" if v else "否"
            elif isinstance(v, float):
                t = f"{v:.1%}" if k in PERCENT else f"{v:.2f}x" if k in MULTIPLES else f"{v:,.2f}"
            else:
                t = NAMES.get(str(v), str(v))
            cells.append("<td>" + escape(t) + "</td>")
        body += "<tr>" + "".join(cells) + "</tr>"
    sections.append(body + "</tbody></table></div></section>")


def read(name, scenario="base"):
    return read_result(ROOT / "results" / scenario / (name + ".csv"))


f = read("financial_summary")
for label, e in [
    ("Intel", "issuer:英特尔_INTC"),
    ("AMD", "issuer:超威半导体_AMD"),
    ("TSMC", "issuer:台积电_2330"),
]:
    company = f.filter((pl.col("entity_id") == e) & (pl.col("period_end").dt.year() >= 2021))
    table(
        label + "-financial",
        label + " 财务与资本配置",
        company.select(
            "entity_id",
            "period_end",
            "period_type",
            "revenue",
            "gross_margin",
            "operating_profit",
            "operating_margin",
            "net_income",
            "roe_average",
            "cfo",
            "cfo_continuing",
            "capex_cash",
            "gross_equipment_cash",
            "cash_after_equipment",
            "cash_after_equipment_sbc",
            "cash_after_equipment_interest",
            "dividends_paid",
            "buybacks_paid",
            "sbc",
            "shares_outstanding",
            "equity_parent",
            "cash",
            "debt_ex_lease",
            "lease_disclosed",
        ),
        "现金指标不是可分配给普通股的完整FCF。Intel含融资设备付款与融资租赁本金；台积电完整年度/H1含IFRS租赁本金，Q3简表未拆出租赁本金；其利息收付按原现金流分类另列。减SBC是机会成本代理，不是当期再次付现。AMD2025持续经营CFO减合并设备支出为保守代理。",
    )
table(
    "common-half",
    "共同半年窗口",
    f.filter(pl.col("period_type") == "H1").select(
        "entity_id",
        "period_end",
        "revenue",
        "operating_margin",
        "net_income",
        "cfo_continuing",
        "gross_equipment_cash",
        "cash_after_equipment",
        "shares_outstanding",
    ),
    "共同2025H1/2026H1，不将AMD半年与另两家公司九个月作增速排名。",
)
table(
    "mix",
    "业务结构",
    read("business_mix").filter(pl.col("period_end").dt.year() >= 2024),
    "Intel Foundry含内部收入，不能与产品收入相加求对外收入；eliminations为抵销。AMD集团公司费用含股份支付、收购摊销等；正分部利润占比不是集团净利润占比。台积电单分部；节点只有晶圆收入比例，未披露节点利润。",
)
table(
    "capital-details",
    "融资、收购与债务到期明细",
    read("capital_details"),
    "全部为百万本币原披露值；混合融资不等同普通股无条件募资，少数股东与母公司资金池分开。TSMC debt_contractual和lease_contractual含未来利息，不与账面债务相加。空缺未被填零。",
)
table(
    "market",
    "当前估值",
    read("market_comparison").select(
        "entity_id",
        "price_date",
        "earnings_end",
        "share_count_end",
        "price",
        "market_cap",
        "pe_ttm",
        "pb_latest",
        "ps_ttm",
    ),
    "当前基本股数×观察价格；PE为GAAP/台湾IFRS归母TTM，亏损为空。Intel受托管股衍生损益影响；AMD含摊销；台积电含VIS处置利得，均不可直接当正常盈利倍数。",
)
table(
    "history-value",
    "历史估值参照",
    read("historical_valuation"),
    "仅五个财年期末样本，不是连续历史区间。财年末价配其后披露的该年财务，是事后描述，禁止当作当时可得的回测信号。",
)
table(
    "tsr",
    "历史股东回报",
    read("historical_returns"),
    "原收盘价逐次再投入实际除息日股息，税费为零；无拆股。AMD/Intel用同币种SPY总回报；台积电只有TWII价格指数，不是严格超额TSR。任期不同，不按长短累计数排名能力。",
)
table(
    "guidance",
    "历史收入指引核验",
    read("guidance_check"),
    "每家公司2024–26年年报/半年业绩交流的下一季度收入指引全集（各六次）；只代表这类短期目标，不代表所有战略承诺。AMD2026Q3截至10月30日未公告，不提前判兑现。其他重要目标/变更见管理层记录。全部以百万美元核对，包括台积电原披露美元营业收入。",
)
table(
    "profit-guidance",
    "利润率与每股收益指引核验",
    read("profit_guidance_check"),
    "同一六次固定发布事件：Intel GAAP/non-GAAP毛利率与EPS，AMD non-GAAP毛利率，台积电毛利率与营业利润率。百分比与美元每股分别列；单点展望按原披露精度比较，不能视作统计保证。Intel2024Q3收入达标但毛利/EPS低于指引；2026Q1 GAAP EPS也低于指引。",
)
table(
    "events",
    "披露前价格和成交筛查",
    read("disclosure_screen"),
    "年度/半年各六次，Intel/台积电另补最新Q3，首次公开日前5/10交易日，排除公告当天；相对SOX价格指数（美股）或TWII（台股），偏差绝对值≥5个百分点或日均量≥更早60交易日的1.5倍为线索。市场和行业不能充分分离、亦未排除所有公开新闻；阈值不代表统计显著性或违法。",
)
for sc in ["bear", "base", "bull"]:
    table(
        "economics-" + sc,
        sc + " 经营方向与单因素量级",
        read("scenario_economics", sc),
        "研究者情景，不是市场一致预期。正常化NOPAT不是归母净利；设备预算不是FCF。收入+10%按假设增量贡献率传导，利润率+1pp按假设税率税后化，为算术压力，不是同品涨价弹性。各冲击独立，不能相加。",
    )
    table(
        "value-" + sc,
        sc + " 条件估值",
        read("valuation", sc).select(
            "entity_id",
            "scenario",
            "target_year",
            "equity_value",
            "diluted_shares",
            "price",
            "currency",
        ),
        "2028/2030营业利润×假设EV/EBIT，加当前现金短投、减债务与少数股东账面请求。余额冻结，不另累加预测现金；Intel托管132百万股计股数，不重复扣非现金衍生负债；AMD认股权情景计入0/50%/100%。",
    )
    table(
        "holding-" + sc,
        sc + " 条件持有收益",
        read("returns", sc)
        .filter(pl.col("tax_basis") == "pre_tax")
        .select(
            "entity_id",
            "exit_date",
            "target_price",
            "total_return",
            "xirr",
            "threshold_price",
            "safety_margin",
        ),
        "从10月30日快照价格出发，到期末退出。未来每股股息为自定假设，从2027年末开始；未预测2026余下股息。12%是研究者要求回报，不是客观价值。税后表目前税率参数为零，与税前一致，不代表个人税后结果。",
    )
parts.append("</nav>")
parts.extend(sections)
parts.append("</html>")
(ROOT / "report/industry/结果底表.html").write_text("\n".join(parts))
print("Rendered final tables:", ROOT / "report/industry/结果底表.html")
