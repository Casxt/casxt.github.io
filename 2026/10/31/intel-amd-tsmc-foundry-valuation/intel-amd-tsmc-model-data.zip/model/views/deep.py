"""Cycle-normalized operating, funding and shareholder-value views."""

import math
from datetime import date

import polars as pl
from schemas import register
from study import ISSUERS, LATEST, SECURITIES, SHARE_BASE, STUDY
from views.core import AMOUNTS, COUNTS, PER_UNIT, at, debt, get
from views.market import latest_before, xirr

from mid_term_capital.view_engine import ALL, Field, result_schema, view

YEARS = tuple(range(2026, 2037))
TARGETS = tuple(range(2027, 2032))
CURRENCY_PARAMS = {
    "client_y0",
    "server_y0",
    "other_y0",
    "external_y0",
    "opening_depreciation",
    "opening_amortization",
    "debt_limit",
    "partner_distribution",
    "capex",
    "fab_saving",
    "lease_increment",
    "investment_cash",
    "acquisition_cash",
    "fixed_corp",
}
COUNT_PARAMS = {"capex_life", "capex_lag", "warrant_years"}
MULTIPLE_PARAMS = {"pe", "pb", "ev_ebit", "pr"}
PARAMS = (
    CURRENCY_PARAMS
    | COUNT_PARAMS
    | MULTIPLE_PARAMS
    | {
        "tax",
        "client_margin",
        "server_margin",
        "other_margin",
        "corp_ratio",
        "sbc_ratio",
        "wc_ratio",
        "cash_floor",
        "funding_rate",
        "debt_fraction",
        "issue_discount",
        "max_equity_fraction",
        "payout",
        "dilution",
        "warrant_fraction",
        "yield",
        "terminal_growth",
        "terminal_roic",
        "discount",
        "terminal_asset_recovery",
        "wacc",
        "server_growth",
        "client_growth",
        "other_growth",
        "external_growth",
        "supply_haircut",
        "load_margin",
        "external_margin",
        "amort_decay",
        "remainder_margin",
        "other_asset_recovery",
        "weight_dcf",
        "weight_pe",
        "weight_ev",
        "weight_dividend",
        "buy_low",
        "buy_high",
    }
)


def punit(k):
    return (
        "currency"
        if k in CURRENCY_PARAMS
        else "count"
        if k in COUNT_PARAMS
        else "multiple"
        if k in MULTIPLE_PARAMS
        else "decimal_ratio"
    )


MONEY = [
    "client_revenue",
    "server_revenue",
    "other_revenue",
    "external_revenue",
    "revenue",
    "client_profit",
    "server_profit",
    "other_profit",
    "foundry_profit",
    "corporate_cost",
    "operating_profit",
    "depreciation",
    "amortization",
    "sbc",
    "interest",
    "income_tax",
    "net_income",
    "nopat",
    "capex",
    "change_working_capital",
    "cash_from_operations",
    "free_cash_flow",
    "parent_unlevered_fcf",
    "investment_cash",
    "acquisition_cash",
    "partner_distribution",
    "dividends",
    "cash",
    "debt",
    "equity_parent",
    "ppne",
    "new_debt",
    "equity_raised",
    "unfunded_gap",
    "cumulative_gap",
    "book_other_investments",
    "initial_funding_gap",
    "minimum_cash",
    "retained_cash_change",
    "warrant_proceeds",
    "acquisition_stock_value",
    "cashflow_remaining_period",
    "capex_remaining_period",
    "fcf_remaining_period",
    "net_working_capital",
    "other_net_assets",
    "balance_residual",
]
RATIOS = ["cash_period_fraction", "client_share", "server_share", "operating_margin", "roe", "roic"]
COUNT_COLUMNS = [
    "shares",
    "new_employee_shares",
    "new_warrant_shares",
    "new_deal_shares",
    "new_financing_shares",
]
PER_SHARE = ["eps", "book_value_per_share", "fcf_per_share", "dividend_per_share"]
NUMBERS = MONEY + RATIOS + COUNT_COLUMNS + PER_SHARE


def unit(k):
    return (
        "currency"
        if k in MONEY
        else "count"
        if k in COUNT_COLUMNS or k == "year"
        else "currency_per_unit"
        if k in PER_SHARE
        else "decimal_ratio"
    )


PROJECTION = register(
    "capital_recovery.csv",
    {
        "entity_id": pl.String,
        "scenario": pl.String,
        "year": pl.Int32,
        **{k: pl.Float64 for k in NUMBERS},
    },
    ("entity_id", "scenario", "year"),
    {k: unit(k) for k in ["year"] + NUMBERS},
)
BUY = register(
    "buy_prices.csv",
    {
        "entity_id": pl.String,
        "scenario": pl.String,
        "year": pl.Int32,
        "method": pl.String,
        "price_now": pl.Float64,
        "target_price": pl.Float64,
        "buy_11": pl.Float64,
        "buy_15": pl.Float64,
        "buy_20": pl.Float64,
        "margin_15": pl.Float64,
        "xirr_now": pl.Float64,
        "status": pl.String,
    },
    ("entity_id", "scenario", "year", "method"),
    {
        "year": "count",
        **{
            k: "currency_per_unit"
            for k in ["price_now", "target_price", "buy_11", "buy_15", "buy_20"]
        },
        "margin_15": "decimal_ratio",
        "xirr_now": "decimal_ratio",
    },
)
EVIDENCE = register(
    "valuation_evidence.csv",
    {
        "entity_id": pl.String,
        "scenario": pl.String,
        "year": pl.Int32,
        "method": pl.String,
        "status": pl.String,
        "weight": pl.Float64,
        "multiple": pl.Float64,
        "theoretical_pb": pl.Float64,
        "note": pl.String,
    },
    ("entity_id", "scenario", "year", "method"),
    {
        "year": "count",
        "weight": "decimal_ratio",
        "multiple": "multiple",
        "theoretical_pb": "multiple",
    },
)
REVERSE = register(
    "reverse_valuation.csv",
    {
        "entity_id": pl.String,
        "scenario": pl.String,
        "year": pl.Int32,
        "required_return": pl.Float64,
        "multiple": pl.Float64,
        "required_operating_profit": pl.Float64,
        "projected_operating_profit": pl.Float64,
        "required_margin": pl.Float64,
    },
    ("entity_id", "scenario", "year", "required_return", "multiple"),
    {
        "year": "count",
        "required_return": "decimal_ratio",
        "multiple": "multiple",
        "required_operating_profit": "currency",
        "projected_operating_profit": "currency",
        "required_margin": "decimal_ratio",
    },
)


def build_issuer(short, entity):
    @view(
        name=f"deep.{short}.parameters",
        entity_id=entity,
        source="params",
        schema={
            "year": Field(pl.Int32, "count", "预测年"),
            **{k: Field(pl.Float64, punit(k), "研究假设：" + k) for k in sorted(PARAMS)},
        },
    )
    def parameters(inp):
        return pl.DataFrame(
            [
                {
                    "year": y,
                    **{
                        k: STUDY.params.resolve(entity, "dp_" + k, str(y), STUDY.params.scenario_id)
                        for k in sorted(PARAMS)
                    },
                }
                for y in YEARS
            ],
            schema={"year": pl.Int32, **{k: pl.Float64 for k in sorted(PARAMS)}},
        )

    @view(
        name=f"deep.{short}.projection",
        entity_id=entity,
        inputs=[AMOUNTS, COUNTS, PER_UNIT, parameters],
        schema=PROJECTION,
        lineage={
            k: [
                AMOUNTS.fields.value,
                COUNTS.fields.value,
                PER_UNIT.fields.value,
                *[parameters.fields[p] for p in PARAMS],
            ]
            for k in NUMBERS
        },
    )
    def projection(inp):
        amounts, counts, prices, pars = inp
        end, typ = LATEST[short]
        p0 = pars.row(0, named=True)
        price = latest_before(
            prices, SECURITIES[short], "close_price", STUDY.params.valuation_date
        )["value"]
        cash = get(amounts, entity, "cash", end, typ) + at(
            amounts, entity, "short_investments", end, typ, 0
        )
        deb = debt(amounts, entity, end, typ)
        equity = get(amounts, entity, "equity_parent", end, typ)
        shares = get(counts, entity, "shares_outstanding", *SHARE_BASE[short])
        if short == "intel":
            shares += get(counts, entity, "escrow_unreleased_shares", end, "AS_OF")
        ppne = get(amounts, entity, "ppne", end, typ)
        legacy_ppne = ppne
        vintages = []
        investments = 0.0
        cumulative_gap = 0.0
        prior_revenue = sum(p0[k] for k in ["client_y0", "server_y0", "other_y0", "external_y0"])
        prior_segments = [p0[k] for k in ["client_y0", "server_y0", "other_y0", "external_y0"]]
        base_load = prior_segments[0] + prior_segments[1]
        working_capital = prior_revenue * p0["wc_ratio"]
        other_net_assets = equity + deb - cash - ppne - working_capital
        base_fab_cash = None
        rows = []
        warrant_total = sum(
            at(counts, entity, k, end, "AS_OF", 0)
            for k in ["customer_warrants_openai", "customer_warrants_meta"]
        )
        deal_value = at(
            amounts, entity, "world_labs_acquisition_commitment", "2026-09-28", "AS_OF", 0
        )
        for p in pars.iter_rows(named=True):
            y = p["year"]
            elapsed = y - 2026
            fraction = (0.5 if short == "amd" else 0.25) if y == 2026 else 1.0
            if y == 2026:
                cr, sr, other, ext = prior_segments
            else:
                cr = prior_segments[0] * (1 + p["client_growth"])
                sr = prior_segments[1] * (1 + p["server_growth"])
                other = prior_segments[2] * (1 + p["other_growth"])
                ext = prior_segments[3] * (1 + p["external_growth"])
            revenue = cr + sr + other + ext
            annual_dep = min(
                legacy_ppne / max(fraction, 1e-9),
                legacy_ppne * p["opening_depreciation"] / get(amounts, entity, "ppne", end, typ),
            )
            legacy_ppne = max(0, legacy_ppne - annual_dep * fraction)
            # Actual opening PP&E is a blended vintage; new investment has explicit commissioning lag.
            new_dep = 0.0
            for vintage in vintages:
                if y >= vintage["start"] and vintage["remaining"] > 0:
                    dep = min(vintage["remaining"], vintage["cost"] / p["capex_life"])
                    vintage["remaining"] -= dep
                    new_dep += dep
            effective_capex = p["capex"] * fraction
            current_start = y + int(p["capex_lag"])
            current_dep = effective_capex / p["capex_life"] / 2 if current_start == y else 0
            vintages.append(
                {
                    "start": max(y + 1, current_start),
                    "cost": effective_capex,
                    "remaining": effective_capex - current_dep,
                }
            )
            dep = annual_dep + new_dep + current_dep
            amort = p["opening_amortization"] * (1 - p["amort_decay"]) ** elapsed
            sbc = revenue * p["sbc_ratio"]
            cp = cr * p["client_margin"]
            sp = sr * p["server_margin"]
            op = other * p["other_margin"]
            corp = revenue * p["corp_ratio"] + p["fixed_corp"] + sbc + p["lease_increment"]
            if short == "intel":
                if base_fab_cash is None:
                    y0ebit = (
                        get(amounts, entity, "operating_profit", end, typ)
                        + (revenue - get(amounts, entity, "revenue", end, typ))
                        * p["remainder_margin"]
                    )
                    base_fab_cash = (
                        y0ebit - cp - sp - op + corp + dep + amort - ext * p["external_margin"]
                    )
                foundry = (
                    base_fab_cash
                    + p["fab_saving"]
                    + (cr + sr - base_load) * p["load_margin"]
                    + ext * p["external_margin"]
                    - dep
                )
                ebit = cp + sp + op + foundry - corp - amort
            else:
                foundry = 0.0
                ebit = cp + sp + op - corp - dep - amort
                if y == 2026:
                    ebit = (
                        get(amounts, entity, "operating_profit", end, typ)
                        + (revenue - get(amounts, entity, "revenue", end, typ))
                        * p["remainder_margin"]
                    )
                    corp = cp + sp + op - dep - amort - ebit
            if short == "tsmc" and p["supply_haircut"]:
                ebit -= revenue * p["supply_haircut"]
            d_wc = (
                (revenue - prior_revenue) * p["wc_ratio"]
                if y > 2026
                else revenue * p["wc_ratio"] * fraction * 0.05
            )
            partner = p["partner_distribution"]
            invest = p["investment_cash"]
            acq = p["acquisition_cash"]
            # One-off commitments entered for a year are payments, not annualized rates.
            annual_dividend = (
                max(0, (ebit - deb * p["funding_rate"]) * (1 - p["tax"]) - partner) * p["payout"]
            )
            div = annual_dividend * fraction
            floor = revenue * p["cash_floor"]
            start_cash = cash
            start_equity = equity
            start_debt = deb
            start_shares = shares
            newdeb = 0.0
            raised = 0.0
            # Fixed-point debt/interest solution with hard debt and equity capacity constraints.
            for _ in range(100):
                interest = (start_debt + newdeb / 2) * p["funding_rate"]
                tax = max(0, ebit - interest) * p["tax"]
                net = ebit - interest - tax - partner
                cfo = (net + partner + dep + amort + sbc) * fraction - d_wc
                fcf = cfo - effective_capex - partner * fraction
                before = start_cash + fcf - invest - acq - div
                need = max(0, floor - before)
                candidate = min(need * p["debt_fraction"], max(0, p["debt_limit"] - start_debt))
                if abs(candidate - newdeb) < 1e-6:
                    newdeb = candidate
                    break
                newdeb = candidate
            else:
                raise AssertionError("Funding did not converge")
            interest = (start_debt + newdeb / 2) * p["funding_rate"]
            tax = max(0, ebit - interest) * p["tax"]
            net = ebit - interest - tax - partner
            cfo = (net + partner + dep + amort + sbc) * fraction - d_wc
            fcf = cfo - effective_capex - partner * fraction
            before = start_cash + fcf - invest - acq - div
            need = max(0, floor - before)
            raised = min(
                max(0, need - newdeb),
                start_shares * p["max_equity_fraction"] * price * p["issue_discount"],
            )
            gap = max(0, need - newdeb - raised)
            cash = before + newdeb + raised
            # A floor breach is a disclosed funding shortfall; no fictional additional borrowing.
            cumulative_gap += gap
            if cash < 0:
                # Unpaid operating obligations are shown in the gap, never in cash valuation.
                cash = 0.0
            deb = start_debt + newdeb
            employee = start_shares * p["dilution"] * fraction
            warrants = (
                warrant_total * p["warrant_fraction"] / p["warrant_years"]
                if short == "amd" and y in range(2027, 2027 + int(p["warrant_years"]))
                else 0
            )
            control = (
                at(counts, entity, "government_conditional_warrants", end, "AS_OF", 0)
                if short == "intel"
                and STUDY.params.scenario_id == "capital_disruption"
                and y == 2028
                else 0
            )
            warrants += control
            warrant_cash = control * at(
                prices, entity, "government_warrant_strike", end, "AS_OF", 0
            )
            deal_shares = deal_value / price if short == "amd" and y == 2026 else 0
            deal_stock = deal_value if deal_shares else 0
            financing_shares = raised / (price * p["issue_discount"])
            shares = start_shares + employee + warrants + deal_shares + financing_shares
            cash += warrant_cash
            equity = (
                start_equity
                + net * fraction
                - div
                + sbc * fraction
                + raised
                + deal_stock
                + warrant_cash
            )
            investments += invest + acq + deal_stock
            ppne = max(0, ppne + effective_capex - dep * fraction)
            nopat = ebit - max(0, ebit) * p["tax"]
            ufcf = (nopat + dep + amort + sbc - partner) * fraction - effective_capex - d_wc
            ic = max(1, (start_equity + start_debt - start_cash + equity + deb - cash) / 2)
            r = {
                "entity_id": entity,
                "scenario": STUDY.params.scenario_id,
                "year": y,
                "cash_period_fraction": fraction,
                "client_revenue": cr,
                "server_revenue": sr,
                "other_revenue": other,
                "external_revenue": ext,
                "revenue": revenue,
                "client_profit": cp,
                "server_profit": sp,
                "other_profit": op,
                "foundry_profit": foundry,
                "corporate_cost": corp,
                "operating_profit": ebit,
                "depreciation": dep,
                "amortization": amort,
                "sbc": sbc,
                "interest": interest,
                "income_tax": tax,
                "net_income": net,
                "nopat": nopat,
                "capex": effective_capex,
                "change_working_capital": d_wc,
                "cash_from_operations": cfo,
                "free_cash_flow": fcf,
                "parent_unlevered_fcf": ufcf,
                "investment_cash": invest,
                "acquisition_cash": acq,
                "partner_distribution": partner * fraction,
                "dividends": div,
                "cash": cash,
                "debt": deb,
                "equity_parent": equity,
                "ppne": ppne,
                "new_debt": newdeb,
                "equity_raised": raised,
                "unfunded_gap": gap,
                "cumulative_gap": cumulative_gap,
                "book_other_investments": investments,
                "initial_funding_gap": need,
                "minimum_cash": floor,
                "retained_cash_change": cash - start_cash,
                "warrant_proceeds": warrant_cash,
                "acquisition_stock_value": deal_stock,
                "shares": shares,
                "new_employee_shares": employee,
                "new_warrant_shares": warrants,
                "new_deal_shares": deal_shares,
                "new_financing_shares": financing_shares,
                "eps": net / ((shares + start_shares) / 2),
                "book_value_per_share": equity / shares,
                "fcf_per_share": fcf / shares,
                "dividend_per_share": div / shares,
                "client_share": cr / revenue,
                "server_share": sr / revenue,
                "operating_margin": ebit / revenue,
                "roe": net / max(1, (equity + start_equity) / 2),
                "roic": nopat / ic,
            }
            working_capital += d_wc
            other_net_assets -= amort * fraction
            residual = cash + ppne + working_capital + investments + other_net_assets - deb - equity
            if cumulative_gap < 1e-4:
                assert abs(residual) < 1e-5, f"Balance sheet mismatch: {short}/{y}/{residual}"
            r.update(
                cashflow_remaining_period=cfo,
                capex_remaining_period=effective_capex,
                fcf_remaining_period=fcf,
                net_working_capital=working_capital,
                other_net_assets=other_net_assets,
                balance_residual=residual,
            )
            if y == 2026:
                actual_cfo = get(amounts, entity, "cfo", end, typ)
                actual_capex = (
                    get(amounts, entity, "capex_cash", end, typ)
                    + at(amounts, entity, "financing_capex_cash", end, typ, 0)
                    + at(amounts, entity, "finance_lease_paid", end, typ, 0)
                )
                actual_partner = at(amounts, entity, "partner_distributions", end, typ, 0)
                r["cash_from_operations"] = actual_cfo + cfo
                r["capex"] = actual_capex + effective_capex
                r["free_cash_flow"] = actual_cfo - actual_capex - actual_partner + fcf
                r["fcf_per_share"] = r["free_cash_flow"] / shares
            assert math.isclose(revenue, cr + sr + other + ext, abs_tol=1e-6)
            assert math.isclose(
                shares,
                start_shares + employee + warrants + deal_shares + financing_shares,
                abs_tol=1e-8,
            )
            assert math.isclose(
                equity,
                start_equity
                + net * fraction
                - div
                + sbc * fraction
                + raised
                + deal_stock
                + warrant_cash,
                abs_tol=1e-5,
            )
            assert all(math.isfinite(r[k]) for k in NUMBERS)
            rows.append(r)
            prior_revenue = revenue
            prior_segments = [cr, sr, other, ext]
        return pl.DataFrame(rows, schema={k: f.dtype for k, f in PROJECTION.items()})

    return parameters, projection


ISSUER = {s: build_issuer(s, e) for s, e in ISSUERS.items()}


@view(
    name="deep.cross.projection",
    entity_id=ALL,
    inputs=[v[1] for v in ISSUER.values()],
    schema=PROJECTION,
    lineage={k: [v[1].fields[k] for v in ISSUER.values()] for k in NUMBERS},
)
def projection(inp):
    return pl.concat(inp)


F_FIELDS = {
    k: Field(t, "currency" if k == "value" else None, "预测金额：" + k)
    for k, t in result_schema.FORECAST_SCHEMA.items()
}


@view(
    name="deep.cross.forecast",
    entity_id=ALL,
    inputs=[projection],
    schema=F_FIELDS,
    lineage={"value": [projection.fields[k] for k in MONEY]},
)
def forecast(inp):
    rows = []
    for r in inp[0].iter_rows(named=True):
        for k in MONEY:
            rows.append(
                [
                    r["entity_id"],
                    r["scenario"],
                    str(r["year"]),
                    "consolidated",
                    k,
                    "estimate" if r["year"] == 2026 else "forecast",
                    "explicit"
                    if r["year"] <= 2031 or r["year"] in [2033, 2036]
                    else "interpolated",
                    r[k],
                ]
            )
    return pl.DataFrame(rows, schema=result_schema.FORECAST_SCHEMA, orient="row")


@view(
    name="deep.cross.history",
    entity_id=ALL,
    inputs=[AMOUNTS],
    schema=F_FIELDS,
    lineage={"value": AMOUNTS.fields.value},
)
def history(inp):
    rows = []
    for r in (
        inp[0]
        .filter(
            pl.col("entity_id").is_in(list(ISSUERS.values()))
            & (pl.col("period_type") == "FY")
            & (pl.col("period_end") < date(2026, 1, 1))
        )
        .iter_rows(named=True)
    ):
        m = {"cfo": "cash_from_operations", "capex_cash": "capex", "debt_long": "debt_long"}.get(
            r["metric_id"], r["metric_id"]
        )
        if m not in MONEY:
            continue
        rows.append(
            [
                r["entity_id"],
                STUDY.params.scenario_id,
                str(r["period_end"].year),
                "consolidated",
                m,
                "actual",
                "explicit",
                r["value"],
            ]
        )
    return pl.DataFrame(rows, schema=result_schema.HISTORY_SCHEMA, orient="row")


V_FIELDS = {
    k: Field(
        t,
        "currency"
        if k == "equity_value"
        else "count"
        if k in ["target_year", "diluted_shares"]
        else "currency_per_unit"
        if k == "price"
        else "multiple"
        if k == "terminal_pb"
        else None,
        "估值字段：" + k,
    )
    for k, t in result_schema.VALUATION_SCHEMA.items()
}


def dividend_flows(records, after_year, through_year):
    """Quarterly payments at quarter-end; zero-payout issuers contribute no flows."""
    flows = []
    for r in records:
        if after_year < r["year"] <= through_year and r["dividend_per_share"] > 0:
            flows.extend(
                (date(r["year"], m, d), r["dividend_per_share"] / 4)
                for m, d in [(3, 31), (6, 30), (9, 30), (12, 31)]
            )
    return flows


def method_values(records, pars, year, short):
    """Value actual distributions and terminal residual equity, with retained cash once."""
    r = next(x for x in records if x["year"] == year)
    p = next(x for x in pars if x["year"] == year)
    terminal = records[-1]
    pt = pars[-1]
    nr = r["partner_distribution"] / (1 - p["tax"])
    cash_adjust = (
        r["cash"]
        - r["minimum_cash"]
        - r["debt"]
        + r["book_other_investments"] * p["other_asset_recovery"]
    )
    normalized_parent_ebit = r["operating_profit"] - nr
    earnings = r["net_income"]
    vals = {
        "PE": max(
            0,
            earnings * p["pe"]
            + max(0, r["cash"] - r["minimum_cash"])
            + r["book_other_investments"] * p["other_asset_recovery"],
        )
        / r["shares"]
        if earnings > 0
        else None,
        "PB": max(0, r["equity_parent"] * p["pb"]) / r["shares"]
        if r["equity_parent"] > 0
        else None,
        "Dividend": r["dividend_per_share"] / p["yield"] if r["dividend_per_share"] > 0 else None,
        "EV_EBIT": max(0, normalized_parent_ebit * p["ev_ebit"] + cash_adjust) / r["shares"]
        if normalized_parent_ebit > 0
        else None,
        "PR": max(0, earnings * (p["pr"] * r["roe"] * 100)) / r["shares"]
        if earnings > 0 and r["roe"] > 0
        else None,
    }
    # SOTP is deliberately low-confidence: public segment profits lack complete standalone costs.
    if short == "intel":
        parts = (r["client_profit"] + r["server_profit"] + r["other_profit"]) * p["pe"] + (
            r["foundry_profit"] - r["amortization"] - r["corporate_cost"] - nr
        ) * p["ev_ebit"]
    else:
        parts = (
            r["client_profit"]
            + r["server_profit"]
            + r["other_profit"]
            - r["corporate_cost"]
            - r["depreciation"]
            - r["amortization"]
            - nr
        ) * p["ev_ebit"]
    vals["SOTP"] = max(0, parts + cash_adjust) / r["shares"]
    terminal_parent_nopat = terminal["nopat"] - terminal["partner_distribution"]
    owner_earnings = terminal_parent_nopat * (1 - pt["terminal_growth"] / pt["terminal_roic"])
    term_cash = (
        terminal["cash"]
        - terminal["minimum_cash"]
        - terminal["debt"]
        + terminal["book_other_investments"] * pt["other_asset_recovery"]
    )
    terminal_pbs = {}
    for method, rate, book in [
        ("DCF_steady", p["discount"], False),
        ("DCF_book", p["discount"], True),
        ("DCF_wacc", p["wacc"], False),
    ]:
        if rate <= pt["terminal_growth"]:
            raise AssertionError("Terminal growth exceeds discount rate")
        # Cash/financing and all interim investment already flow through terminal cash and shares.
        # Book-full-return is a policy case; asset-recovery stress is shown separately below.
        te = (
            terminal["equity_parent"]
            if book
            else owner_earnings * (1 + pt["terminal_growth"]) / (rate - pt["terminal_growth"])
            + term_cash
        )
        te = max(0, te)
        target_day = date(year, 12, 31)
        tv = (
            te
            / terminal["shares"]
            / (1 + rate) ** ((date(2036, 12, 31) - target_day).days / 365.25)
        )
        div = sum(
            v / (1 + rate) ** ((d - target_day).days / 365.25)
            for d, v in dividend_flows(records, year, 2036)
        )
        vals[method] = tv + div
        terminal_pbs[method] = (
            te / terminal["equity_parent"] if terminal["equity_parent"] > 0 else None
        )
    te = max(0, terminal["equity_parent"] * p["terminal_asset_recovery"])
    vals["DCF_book_haircut"] = te / terminal["shares"] / (1 + p["discount"]) ** (2036 - year) + sum(
        v / (1 + p["discount"]) ** ((d - date(year, 12, 31)).days / 365.25)
        for d, v in dividend_flows(records, year, 2036)
    )
    terminal_pbs["DCF_book_haircut"] = p["terminal_asset_recovery"]
    # Future unresolved funding or control transfer invalidates the continuous-owner valuation.
    invalid = any(x["cumulative_gap"] > 1e-4 for x in records) or (
        short == "intel" and STUDY.params.scenario_id == "capital_disruption"
    )
    if invalid:
        vals = {k: None for k in vals}
    weights = {
        "DCF_steady": p["weight_dcf"],
        "PE": p["weight_pe"],
        "EV_EBIT": p["weight_ev"],
        "Dividend": p["weight_dividend"],
    }
    assert abs(sum(weights.values()) - 1) < 1e-9
    available = {k: w for k, w in weights.items() if vals[k] is not None}
    total = sum(available.values())
    vals["Fusion"] = sum(vals[k] * w for k, w in available.items()) / total if total else None
    return (
        vals,
        terminal_pbs,
        {k: w / total for k, w in available.items()} if total else {},
        invalid,
    )


def build_security(short, security):
    parameters, projection_view = ISSUER[short]

    @view(
        name=f"deep.{short}.valuation",
        entity_id=security,
        inputs=[projection_view, parameters],
        schema=V_FIELDS,
        lineage={
            k: [
                *[projection_view.fields[n] for n in NUMBERS],
                *[parameters.fields[p] for p in PARAMS],
            ]
            for k in ["equity_value", "diluted_shares", "price", "terminal_pb"]
        },
    )
    def valuation(inp):
        records = list(inp[0].iter_rows(named=True))
        pars = list(inp[1].iter_rows(named=True))
        rows = []
        for year in TARGETS:
            vals, pbs, _, _ = method_values(records, pars, year, short)
            r = next(x for x in records if x["year"] == year)
            for method, price in vals.items():
                rows.append(
                    [
                        security,
                        STUDY.params.scenario_id,
                        STUDY.params.valuation_date,
                        year,
                        method,
                        price * r["shares"] if price is not None else None,
                        r["shares"],
                        price,
                        "TWD" if short == "tsmc" else "USD",
                        pbs.get(method),
                    ]
                )
        return pl.DataFrame(rows, schema=result_schema.VALUATION_SCHEMA, orient="row")

    @view(
        name=f"deep.{short}.evidence",
        entity_id=security,
        inputs=[projection_view, parameters],
        schema=EVIDENCE,
        lineage={
            k: [
                *[projection_view.fields[n] for n in NUMBERS],
                *[parameters.fields[p] for p in PARAMS],
            ]
            for k in ["weight", "multiple", "theoretical_pb"]
        },
    )
    def evidence(inp):
        records = list(inp[0].iter_rows(named=True))
        pars = list(inp[1].iter_rows(named=True))
        rows = []
        for year in TARGETS:
            vals, _pbs, weights, invalid = method_values(records, pars, year, short)
            p = next(x for x in pars if x["year"] == year)
            r = next(x for x in records if x["year"] == year)
            theoretical = (r["roe"] - p["terminal_growth"]) / (p["discount"] - p["terminal_growth"])
            for m, v in vals.items():
                status = (
                    "不适用：资金缺口未解决或控制权边界改变"
                    if invalid
                    else "不适用：盈利或派息条件不满足"
                    if v is None
                    else "低可信度，不纳入融合"
                    if m in ["PB", "PR", "SOTP", "DCF_book", "DCF_book_haircut", "DCF_wacc"]
                    else "条件估值"
                )
                note = (
                    "实际预测分红＋2036剩余权益；留存现金只在期末计一次，新增发行影响期末每股权益"
                    if m.startswith("DCF")
                    else "利润及倍数均为周期情景；不是市场一致预期"
                )
                rows.append(
                    [
                        security,
                        STUDY.params.scenario_id,
                        year,
                        m,
                        status,
                        weights.get(m, 0),
                        p.get(
                            {
                                "PE": "pe",
                                "PB": "pb",
                                "PR": "pr",
                                "EV_EBIT": "ev_ebit",
                                "Dividend": "yield",
                            }.get(m, "")
                        ),
                        theoretical if m == "PB" else None,
                        note,
                    ]
                )
        return pl.DataFrame(rows, schema={k: f.dtype for k, f in EVIDENCE.items()}, orient="row")

    @view(
        name=f"deep.{short}.buy_prices",
        entity_id=security,
        inputs=[valuation, projection_view, PER_UNIT, parameters],
        schema=BUY,
        lineage={
            k: [
                valuation.fields.price,
                projection_view.fields.dividend_per_share,
                PER_UNIT.fields.value,
                parameters.fields.discount,
                parameters.fields.buy_low,
                parameters.fields.buy_high,
            ]
            for k in [
                "price_now",
                "target_price",
                "buy_11",
                "buy_15",
                "buy_20",
                "margin_15",
                "xirr_now",
            ]
        },
    )
    def buy_prices(inp):
        vals, proj, quotes, policy = inp
        rates = policy.row(0, named=True)
        assert (rates["discount"], rates["buy_low"], rates["buy_high"]) == (0.11, 0.15, 0.20)
        records = list(proj.iter_rows(named=True))
        start = STUDY.params.valuation_date
        current = latest_before(quotes, security, "close_price", start)["value"]
        rows = []
        for v in vals.iter_rows(named=True):
            y = v["target_year"]
            target = v["price"]
            buys = {}
            irr = None
            if target is not None:
                flows = dividend_flows(records, 2026, y) + [(date(y, 12, 31), target)]
                for rate in [rates["discount"], rates["buy_low"], rates["buy_high"]]:
                    value = sum(c / (1 + rate) ** ((d - start).days / 365.25) for d, c in flows)
                    buys[rate] = value
                    if value > 0:
                        assert abs(xirr([(start, -value)] + flows) - rate) < 1e-8
                if sum(c for _, c in flows) > 0:
                    irr = xirr([(start, -current)] + flows)
                else:
                    irr = -1
            rows.append(
                [
                    security,
                    STUDY.params.scenario_id,
                    y,
                    v["method"],
                    current,
                    target,
                    buys.get(0.11),
                    buys.get(0.15),
                    buys.get(0.20),
                    1 - current / buys[0.15] if buys.get(0.15) else None,
                    irr,
                    "不适用" if target is None else "条件估值；税前原币",
                ]
            )
        return pl.DataFrame(rows, schema={k: f.dtype for k, f in BUY.items()}, orient="row")

    @view(
        name=f"deep.{short}.reverse",
        entity_id=security,
        inputs=[projection_view, parameters, PER_UNIT],
        schema=REVERSE,
        lineage={
            k: [
                projection_view.fields.shares,
                projection_view.fields.revenue,
                projection_view.fields.cash,
                projection_view.fields.debt,
                projection_view.fields.operating_profit,
                *[parameters.fields[p] for p in PARAMS],
                PER_UNIT.fields.value,
            ]
            for k in [
                "required_return",
                "multiple",
                "required_operating_profit",
                "projected_operating_profit",
                "required_margin",
            ]
        },
    )
    def reverse(inp):
        proj, pars, quotes = inp
        records = list(proj.iter_rows(named=True))
        start = STUDY.params.valuation_date
        current = latest_before(quotes, security, "close_price", start)["value"]
        rows = []
        for r in records:
            if r["year"] not in [2028, 2031]:
                continue
            p = pars.filter(pl.col("year") == r["year"]).row(0, named=True)
            for rate in [0, 0.11, 0.15, 0.20]:
                for multiple in (
                    [16, 20, 26]
                    if short == "intel"
                    else [20, 25, 30]
                    if short == "amd"
                    else [15, 20, 25]
                ):
                    horizon = (date(r["year"], 12, 31) - start).days / 365.25
                    div_at_exit = sum(
                        c * (1 + rate) ** ((date(r["year"], 12, 31) - d).days / 365.25)
                        for d, c in dividend_flows(records, 2026, r["year"])
                    )
                    equity = (current * (1 + rate) ** horizon - div_at_exit) * r["shares"]
                    capital = (
                        r["cash"]
                        - r["minimum_cash"]
                        - r["debt"]
                        + r["book_other_investments"] * p["other_asset_recovery"]
                    )
                    req = (equity - capital) / multiple + r["partner_distribution"] / (1 - p["tax"])
                    rows.append(
                        [
                            security,
                            STUDY.params.scenario_id,
                            r["year"],
                            rate,
                            multiple,
                            req,
                            r["operating_profit"],
                            req / r["revenue"],
                        ]
                    )
        return pl.DataFrame(rows, schema={k: f.dtype for k, f in REVERSE.items()}, orient="row")

    return valuation, evidence, buy_prices, reverse


SECURITY = {s: build_security(s, e) for s, e in SECURITIES.items()}


def aggregate(name, index, schema):
    inputs = [v[index] for v in SECURITY.values()]

    @view(
        name="deep.cross." + name,
        entity_id=ALL,
        inputs=inputs,
        schema=schema,
        lineage={
            k: [v.fields[k] for v in inputs]
            for k, f in schema.items()
            if f.unit and k not in ["year", "target_year"]
        },
    )
    def joined(inp):
        return pl.concat(inp)

    return joined


valuation = aggregate("valuation", 0, V_FIELDS)
evidence = aggregate("evidence", 1, EVIDENCE)
buy_prices = aggregate("buy_prices", 2, BUY)
reverse = aggregate("reverse", 3, REVERSE)
R_FIELDS = {
    k: Field(
        t,
        "currency_per_unit"
        if k in ["target_price", "threshold_price"]
        else "decimal_ratio"
        if t == pl.Float64
        else None,
        "收益字段：" + k,
    )
    for k, t in result_schema.RETURNS_SCHEMA.items()
}


@view(
    name="deep.cross.returns",
    entity_id=ALL,
    inputs=[buy_prices, projection],
    schema=R_FIELDS,
    lineage={
        k: [
            buy_prices.fields.target_price,
            buy_prices.fields.buy_11,
            buy_prices.fields.price_now,
            buy_prices.fields.xirr_now,
            projection.fields.dividend_per_share,
        ]
        for k in ["target_price", "total_return", "xirr", "threshold_price", "safety_margin"]
    },
)
def returns(inp):
    prices, proj = inp
    rows = []
    for r in prices.iter_rows(named=True):
        issuer = next(ISSUERS[s] for s, v in SECURITIES.items() if v == r["entity_id"])
        div = proj.filter(
            (pl.col("entity_id") == issuer)
            & (pl.col("year") > 2026)
            & (pl.col("year") <= r["year"])
        )["dividend_per_share"].sum()
        target = r["target_price"]
        total = (target + div) / r["price_now"] - 1 if target is not None else None
        rows.append(
            [
                r["entity_id"],
                r["scenario"],
                STUDY.params.valuation_date,
                date(r["year"], 12, 31),
                r["method"],
                "pre_tax",
                target,
                total,
                r["xirr_now"],
                r["buy_11"],
                1 - r["price_now"] / r["buy_11"] if r["buy_11"] else None,
            ]
        )
    return pl.DataFrame(rows, schema=result_schema.RETURNS_SCHEMA, orient="row")
