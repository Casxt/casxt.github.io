"""Security valuation, conditional holding returns, and actual shareholder returns."""

import math
from datetime import date

import polars as pl
from schemas import EVENTS, GUIDANCE, HIST_VAL, MARKET, PROFIT_GUIDANCE, TSR
from study import ISSUERS, LATEST, SECURITIES, SHARE_BASE, STUDY, TARGET_YEARS, TENURES
from views.core import AMOUNTS, COUNTS, INDEX, ISSUER_VIEWS, PER_UNIT, RATIOS, at, debt, get

from mid_term_capital.view_engine import ALL, Field, result_schema, view

SECURITY_PARAMETERS = {
    "announced_acquisition_issue_price": "currency_per_unit",
    "annual_share_dilution": "decimal_ratio",
    "warrant_fraction": "decimal_ratio",
    "ev_ebit_multiple": "multiple",
    "minority_book_multiple": "multiple",
    "dividend_per_share": "currency_per_unit",
    "discount_rate": "decimal_ratio",
    "dividend_tax_rate": "decimal_ratio",
}


def latest_before(frame, entity, metric, day):
    selected = (
        frame.filter(
            (pl.col("entity_id") == entity)
            & (pl.col("metric_id") == metric)
            & (pl.col("period_end") <= day)
        )
        .sort("period_end")
        .tail(1)
    )
    assert selected.height == 1, f"No quote: {entity}/{metric}/{day}"
    return selected.row(0, named=True)


def reinvested(frame, entity, start, end):
    prices = frame.filter(
        (pl.col("entity_id") == entity)
        & (pl.col("metric_id") == "close_price")
        & (pl.col("period_end") >= start)
        & (pl.col("period_end") <= end)
    ).sort("period_end")
    dividends = {
        r["period_end"]: r["value"]
        for r in frame.filter(
            (pl.col("entity_id") == entity)
            & (pl.col("metric_id") == "cash_dividend_per_share")
            & (pl.col("period_end") > start)
            & (pl.col("period_end") <= end)
        ).iter_rows(named=True)
    }
    wealth = 1.0
    previous = None
    first = None
    last = None
    for r in prices.iter_rows(named=True):
        price = r["value"]
        if previous is not None:
            wealth *= (price + dividends.get(r["period_end"], 0.0)) / previous
        else:
            first = price
        previous = price
        last = price
    assert first and last and wealth > 0, f"TSR domain: {entity}"
    return wealth - 1, last / first - 1


def xirr(flows):
    start = flows[0][0]

    def npv(rate):
        return sum(cash / (1 + rate) ** ((day - start).days / 365.25) for day, cash in flows)

    low, high = -0.999999, 100.0
    assert npv(low) * npv(high) <= 0, "Return root is not bracketed"
    for _ in range(160):
        mid = (low + high) / 2
        if npv(mid) > 0:
            low = mid
        else:
            high = mid
    return (low + high) / 2


def build_security(short, security):
    issuer = ISSUERS[short]
    forecast = ISSUER_VIEWS[short][0]

    @view(
        name=f"{short}_security.assumptions",
        entity_id=security,
        source="params",
        schema={p: Field(pl.Float64, u, "证券参数：" + p) for p, u in SECURITY_PARAMETERS.items()},
    )
    def assumptions(inp):
        """Resolve security parameters without falling back to the issuer."""
        return pl.DataFrame(
            [
                {
                    p: STUDY.params.resolve(security, p, "ALL", STUDY.params.scenario_id)
                    for p in SECURITY_PARAMETERS
                }
            ],
            schema={p: pl.Float64 for p in SECURITY_PARAMETERS},
        )

    val_fields = {
        k: Field(
            t,
            "currency"
            if k == "equity_value"
            else "count"
            if k in ["diluted_shares", "target_year"]
            else "currency_per_unit"
            if k == "price"
            else "multiple"
            if k == "terminal_pb"
            else None,
            "条件估值字段：" + k,
        )
        for k, t in result_schema.VALUATION_SCHEMA.items()
    }

    @view(
        name=f"{short}_security.valuation",
        entity_id=security,
        inputs=[forecast, AMOUNTS, COUNTS, assumptions],
        schema=val_fields,
        lineage={
            k: [
                forecast.fields.value,
                AMOUNTS.fields.value,
                COUNTS.fields.value,
                *[assumptions.fields[p] for p in SECURITY_PARAMETERS],
            ]
            for k in ["equity_value", "diluted_shares", "price", "terminal_pb"]
        },
    )
    def valuation(inp):
        """Value conditional operating earnings and deduct other capital claims once."""
        projection, amounts, counts, pars = inp
        p = pars.row(0, named=True)
        end, typ = LATEST[short]
        shares = get(counts, issuer, "shares_outstanding", *SHARE_BASE[short])
        if short == "intel":
            # Include all unreleased government shares; do not also deduct their
            # non-cash derivative liability. The separate control-loss warrants
            # are outside these continuing-control scenarios.
            shares += get(counts, issuer, "escrow_unreleased_shares", end, "AS_OF")
        elif short == "amd":
            warrants = sum(
                get(counts, issuer, m, end, "AS_OF")
                for m in ["customer_warrants_openai", "customer_warrants_meta"]
            )
            shares += warrants * p["warrant_fraction"]
            # A separate announced deal must not disappear into generic employee
            # dilution. This fixed issue-price stress is not the unknown closing VWAP.
            issue_price = p["announced_acquisition_issue_price"]
            assert issue_price > 0, "AMD acquisition issue-price stress must be positive"
            shares += (
                get(amounts, issuer, "world_labs_acquisition_commitment", "2026-09-28", "AS_OF")
                / issue_price
            )
        debt_value = debt(amounts, issuer, end, typ)
        assert debt_value is not None, f"Debt missing: {short}"
        cash = get(amounts, issuer, "cash", end, typ)
        investments = at(amounts, issuer, "short_investments", end, typ, 0.0)
        minority = at(amounts, issuer, "nci_equity", end, typ)
        if minority is None:
            group = at(amounts, issuer, "equity_group", end, typ)
            parent = get(amounts, issuer, "equity_parent", end, typ)
            minority = group - parent if group is not None else 0.0
        rows = []
        for year in TARGET_YEARS:
            profit = projection.filter(
                (pl.col("period") == str(year)) & (pl.col("metric_id") == "operating_profit")
            )["value"].item()
            equity = (
                profit * p["ev_ebit_multiple"]
                - debt_value
                + cash
                + investments
                - minority * p["minority_book_multiple"]
            )
            # A going-concern equity claim has a zero lower bound; no liquidation
            # recovery or future refinancing is assumed by this estimate.
            equity = max(0.0, equity)
            future_shares = shares * (1 + p["annual_share_dilution"]) ** (
                year - STUDY.params.valuation_date.year
            )
            price = equity / future_shares
            assert math.isclose(price * future_shares, equity, rel_tol=1e-9, abs_tol=1e-6), (
                "Valuation identity failed"
            )
            rows.append(
                [
                    security,
                    STUDY.params.scenario_id,
                    STUDY.params.valuation_date,
                    year,
                    "CONDITIONAL_EV_EBIT",
                    equity,
                    future_shares,
                    price,
                    "TWD" if short == "tsmc" else "USD",
                    None,
                ]
            )
        return pl.DataFrame(rows, schema=result_schema.VALUATION_SCHEMA, orient="row")

    return_fields = {
        k: Field(
            t,
            "currency_per_unit"
            if k in ["target_price", "threshold_price"]
            else "decimal_ratio"
            if k in ["total_return", "xirr", "safety_margin"]
            else None,
            "条件收益字段：" + k,
        )
        for k, t in result_schema.RETURNS_SCHEMA.items()
    }

    @view(
        name=f"{short}_security.returns",
        entity_id=security,
        inputs=[valuation, PER_UNIT, assumptions],
        schema=return_fields,
        lineage={
            k: [
                valuation.fields.price,
                PER_UNIT.fields.value,
                *[assumptions.fields[p] for p in SECURITY_PARAMETERS],
            ]
            for k in ["target_price", "total_return", "xirr", "threshold_price", "safety_margin"]
        },
    )
    def returns(inp):
        """Calculate price and dividend returns with explicit cash-flow dates."""
        values, quotes, pars = inp
        p = pars.row(0, named=True)
        current = latest_before(quotes, security, "close_price", STUDY.params.valuation_date)[
            "value"
        ]
        rows = []
        for r in values.iter_rows(named=True):
            exit_day = date(r["target_year"], 12, 31)
            for tax_basis in ["pre_tax", "after_tax"]:
                dividend = p["dividend_per_share"] * (
                    1 - p["dividend_tax_rate"] if tax_basis == "after_tax" else 1
                )
                flows = [(STUDY.params.valuation_date, -current)]
                for y in range(STUDY.params.valuation_date.year + 1, r["target_year"] + 1):
                    if dividend:
                        flows.append((date(y, 12, 31), dividend))
                flows.append((exit_day, r["price"]))
                positive = sum(c for _, c in flows[1:])
                threshold = sum(
                    c
                    / (1 + p["discount_rate"]) ** ((d - STUDY.params.valuation_date).days / 365.25)
                    for d, c in flows[1:]
                )
                rows.append(
                    [
                        security,
                        STUDY.params.scenario_id,
                        STUDY.params.valuation_date,
                        exit_day,
                        r["method"],
                        tax_basis,
                        r["price"],
                        positive / current - 1,
                        xirr(flows) if positive > 0 else -1.0,
                        threshold,
                        1 - current / threshold if threshold > 0 else None,
                    ]
                )
        return pl.DataFrame(rows, schema=result_schema.RETURNS_SCHEMA, orient="row")

    return valuation, returns


SECURITY_VIEWS = {s: build_security(s, e) for s, e in SECURITIES.items()}


def aggregate(name, schema, position):
    views = [v[position] for v in SECURITY_VIEWS.values()]
    fields = {k: Field(t, views[0].fields[k].unit, "共同证券结果：" + k) for k, t in schema.items()}

    @view(
        name="cross." + name,
        entity_id=ALL,
        inputs=views,
        schema=fields,
        lineage={k: [v.fields[k] for v in views] for k, f in fields.items() if f.unit},
    )
    def combined(inp):
        """Concatenate independent security results without aggregating equity pools."""
        return pl.concat(inp)

    return combined


valuation = aggregate("valuation", result_schema.VALUATION_SCHEMA, 0)
returns = aggregate("returns", result_schema.RETURNS_SCHEMA, 1)


@view(
    name="cross.market_comparison",
    entity_id=ALL,
    inputs=[AMOUNTS, COUNTS, PER_UNIT],
    schema=MARKET,
    lineage={
        k: [AMOUNTS.fields.value, COUNTS.fields.value, PER_UNIT.fields.value]
        for k, f in MARKET.items()
        if f.unit
    },
)
def market_comparison(inp):
    """Compute TTM multiples from matched fiscal periods and a dated quote."""
    amounts, counts, quotes = inp
    rows = []
    for short, issuer in ISSUERS.items():
        end, typ = LATEST[short]
        end = date.fromisoformat(end)
        prior = (
            amounts.filter(
                (pl.col("entity_id") == issuer)
                & (pl.col("metric_id") == "revenue")
                & (pl.col("period_type") == typ)
                & (pl.col("period_end").dt.year() == end.year - 1)
            )
            .sort("period_end")
            .tail(1)["period_end"]
            .item()
        )
        fy = (
            amounts.filter(
                (pl.col("entity_id") == issuer)
                & (pl.col("metric_id") == "revenue")
                & (pl.col("period_type") == "FY")
            )
            .sort("period_end")
            .tail(1)["period_end"]
            .item()
        )
        ttm = {
            m: get(amounts, issuer, m, fy, "FY")
            + get(amounts, issuer, m, end, typ)
            - get(amounts, issuer, m, prior, typ)
            for m in ["revenue", "net_income"]
        }
        security = SECURITIES[short]
        shares = get(counts, issuer, "shares_outstanding", *SHARE_BASE[short])
        price = latest_before(quotes, security, "close_price", STUDY.params.valuation_date)["value"]
        market_cap = shares * price
        equity = get(amounts, issuer, "equity_parent", end, typ)
        rows.append(
            [
                security,
                latest_before(quotes, security, "close_price", STUDY.params.valuation_date)[
                    "period_end"
                ],
                end,
                date.fromisoformat(SHARE_BASE[short][0]),
                price,
                shares,
                market_cap,
                ttm["revenue"],
                ttm["net_income"],
                market_cap / ttm["net_income"] if ttm["net_income"] > 0 else None,
                market_cap / equity,
                market_cap / ttm["revenue"],
            ]
        )
    return pl.DataFrame(rows, schema={k: f.dtype for k, f in MARKET.items()}, orient="row")


@view(
    name="cross.historical_returns",
    entity_id=ALL,
    inputs=[PER_UNIT, INDEX],
    schema=TSR,
    lineage={k: [PER_UNIT.fields.value, INDEX.fields.value] for k, f in TSR.items() if f.unit},
)
def historical_returns(inp):
    """Reinvest actual cash dividends on ex-dates within each security only."""
    quotes, indices = inp
    end = date(2026, 10, 29)
    rows = []
    for short, security in SECURITIES.items():
        anchors = {
            "1y": date(2025, 10, 29),
            "3y": date(2023, 10, 29),
            "5y": date(2021, 10, 29),
            "current_ceo": date.fromisoformat(TENURES[short]),
        }
        for label, anchor in anchors.items():
            start = latest_before(quotes, security, "close_price", anchor)["period_end"]
            total, price_return = reinvested(quotes, security, start, end)
            if short == "tsmc":
                before = latest_before(indices, "industry:台湾加权指数", "index_level", start)
                after = latest_before(indices, "industry:台湾加权指数", "index_level", end)
                benchmark = after["value"] / before["value"] - 1
                basis = "TWII price index; excludes dividends; not excess TSR"
            else:
                benchmark, _ = reinvested(quotes, "industry:美股市场", start, end)
                basis = "SPY total return; ex-date reinvestment"
            rows.append(
                [
                    security,
                    label,
                    start,
                    end,
                    "TWD" if short == "tsmc" else "USD",
                    price_return,
                    total,
                    benchmark,
                    basis,
                ]
            )
    return pl.DataFrame(rows, schema={k: f.dtype for k, f in TSR.items()}, orient="row")


@view(
    name="cross.historical_valuation",
    entity_id=ALL,
    inputs=[AMOUNTS, COUNTS, PER_UNIT],
    schema=HIST_VAL,
    lineage={
        k: [AMOUNTS.fields.value, COUNTS.fields.value, PER_UNIT.fields.value]
        for k, f in HIST_VAL.items()
        if f.unit
    },
)
def historical_valuation(inp):
    """Compare fiscal-end prices with subsequently known fiscal accounts, not a backtest."""
    amounts, counts, quotes = inp
    rows = []
    for short, issuer in ISSUERS.items():
        years = amounts.filter(
            (pl.col("entity_id") == issuer)
            & (pl.col("metric_id") == "revenue")
            & (pl.col("period_type") == "FY")
            & (pl.col("period_end").dt.year() >= 2021)
        )
        for r in years.iter_rows(named=True):
            end = r["period_end"]
            sec = SECURITIES[short]
            q = latest_before(quotes, sec, "close_price", end)
            shares = get(counts, issuer, "shares_outstanding", end, "FY")
            cap = q["value"] * shares
            ni = get(amounts, issuer, "net_income", end, "FY")
            equity = get(amounts, issuer, "equity_parent", end, "FY")
            rows.append(
                [
                    sec,
                    end,
                    q["period_end"],
                    q["value"],
                    cap / ni if ni > 0 else None,
                    cap / equity,
                    cap / r["value"],
                ]
            )
    return pl.DataFrame(rows, schema={k: f.dtype for k, f in HIST_VAL.items()}, orient="row")


@view(
    name="cross.guidance_check",
    entity_id=ALL,
    inputs=[AMOUNTS],
    schema=GUIDANCE,
    lineage={k: [AMOUNTS.fields.value] for k, f in GUIDANCE.items() if f.unit},
)
def guidance_check(inp):
    """Match every sampled annual/interim revenue outlook to the same target quarter."""
    amounts = inp[0]
    rows = []
    for r in amounts.filter(
        pl.col("metric_id").str.starts_with("guidance_revenue_usd_low_")
    ).iter_rows(named=True):
        target = r["metric_id"].removeprefix("guidance_revenue_usd_low_")
        high = get(
            amounts, r["entity_id"], "guidance_revenue_usd_high_" + target, r["period_end"], "AS_OF"
        )
        actual = amounts.filter(
            (pl.col("entity_id") == r["entity_id"])
            & (pl.col("metric_id") == "actual_revenue_usd_" + target)
        )
        value = actual["value"].item() if actual.height else None
        status = (
            "未到验证期"
            if value is None
            else "区间内"
            if r["value"] <= value <= high
            else "高于上限"
            if value > high
            else "低于下限"
        )
        rows.append(
            [
                r["entity_id"],
                r["period_end"],
                target,
                r["value"],
                high,
                value,
                value / ((r["value"] + high) / 2) - 1 if value is not None else None,
                status,
            ]
        )
    return pl.DataFrame(rows, schema={k: f.dtype for k, f in GUIDANCE.items()}, orient="row")


SCREEN_PARAMS = {
    "event_return_threshold": "decimal_ratio",
    "event_volume_threshold": "multiple",
    "event_baseline_days": "count",
}


@view(
    name="cross.screen_parameters",
    entity_id=ALL,
    source="params",
    schema={p: Field(pl.Float64, u, "披露筛查参数") for p, u in SCREEN_PARAMS.items()},
)
def screen_parameters(inp):
    """Freeze selection thresholds before screening observed returns."""
    return pl.DataFrame(
        [{p: STUDY.params.resolve(ALL, p, "ALL", STUDY.params.scenario_id) for p in SCREEN_PARAMS}]
    )


@view(
    name="cross.disclosure_screen",
    entity_id=ALL,
    inputs=[PER_UNIT, COUNTS, INDEX, RATIOS, screen_parameters],
    schema=EVENTS,
    lineage={
        k: [
            PER_UNIT.fields.value,
            COUNTS.fields.value,
            INDEX.fields.value,
            RATIOS.fields.value,
            *[screen_parameters.fields[p] for p in SCREEN_PARAMS],
        ]
        for k, f in EVENTS.items()
        if f.unit
    },
)
def disclosure_screen(inp):
    """Select hypotheses using pre-event trading sessions, not legal inferences."""
    quotes, counts, indices, ratios, parameters = inp
    p = parameters.row(0, named=True)
    rows = []
    for event in ratios.filter(pl.col("metric_id") == "earnings_release_event").iter_rows(
        named=True
    ):
        sec = event["entity_id"]
        day = event["period_end"]
        prices = quotes.filter(
            (pl.col("entity_id") == sec)
            & (pl.col("metric_id") == "close_price")
            & (pl.col("period_end") < day)
        ).sort("period_end")
        volumes = counts.filter(
            (pl.col("entity_id") == sec)
            & (pl.col("metric_id") == "trading_volume")
            & (pl.col("period_end") < day)
        ).sort("period_end")
        baseline = (
            volumes.tail(int(p["event_baseline_days"]) + 10)
            .head(int(p["event_baseline_days"]))["value"]
            .mean()
        )
        assert prices.height >= 11 and baseline and baseline > 0, f"Screen data absent {sec}/{day}"
        for window in [5, 10]:
            sample = prices.tail(window + 1)
            start = sample["period_end"].head(1).item()
            end = sample["period_end"].tail(1).item()
            sr = sample["value"].tail(1).item() / sample["value"].head(1).item() - 1
            if sec == SECURITIES["tsmc"]:
                bm = "industry:台湾加权指数"
                before = latest_before(indices, bm, "index_level", start)
                after = latest_before(indices, bm, "index_level", end)
                br = after["value"] / before["value"] - 1
                basis = "TWII price; event date excluded; 60 sessions before last 10 baseline"
            else:
                bm = "industry:美国半导体指数"
                before = latest_before(indices, bm, "index_level", start)
                after = latest_before(indices, bm, "index_level", end)
                br = after["value"] / before["value"] - 1
                basis = "SOX price; event date excluded; 60 sessions before last 10 baseline"
            vr = volumes.tail(window)["value"].mean() / baseline
            rows.append(
                [
                    sec,
                    day,
                    window,
                    sr,
                    br,
                    sr - br,
                    vr,
                    abs(sr - br) >= p["event_return_threshold"]
                    or vr >= p["event_volume_threshold"],
                    basis,
                ]
            )
    return pl.DataFrame(rows, schema={k: f.dtype for k, f in EVENTS.items()}, orient="row")


@view(
    name="cross.profit_guidance_check",
    entity_id=ALL,
    inputs=[RATIOS, PER_UNIT],
    schema=PROFIT_GUIDANCE,
    lineage={
        k: [RATIOS.fields.value, PER_UNIT.fields.value]
        for k, f in PROFIT_GUIDANCE.items()
        if f.unit
    },
)
def profit_guidance_check(inp):
    """Check margins and EPS separately so revenue success cannot conceal earnings misses."""
    rows = []
    for frame in inp:
        for r in frame.filter(
            pl.col("metric_id").str.starts_with("profit_guidance_low_")
        ).iter_rows(named=True):
            suffix = r["metric_id"].removeprefix("profit_guidance_low_")
            metric, target = suffix.rsplit("_", 1)
            high = get(
                frame, r["entity_id"], "profit_guidance_high_" + suffix, r["period_end"], "AS_OF"
            )
            actual = frame.filter(
                (pl.col("entity_id") == r["entity_id"])
                & (pl.col("metric_id") == "profit_guidance_actual_" + suffix)
            )
            v = actual["value"].item() if actual.height else None
            status = (
                "未到验证期"
                if v is None
                else "区间内/等于目标"
                if r["value"] <= v <= high
                else "高于上限"
                if v > high
                else "低于下限"
            )
            ratio = "margin" in metric
            rows.append(
                [
                    r["entity_id"],
                    r["period_end"],
                    target,
                    metric,
                    r["value"] if ratio else None,
                    high if ratio else None,
                    v if ratio else None,
                    None if ratio else r["value"],
                    None if ratio else v,
                    status,
                ]
            )
    return pl.DataFrame(rows, schema={k: f.dtype for k, f in PROFIT_GUIDANCE.items()}, orient="row")
