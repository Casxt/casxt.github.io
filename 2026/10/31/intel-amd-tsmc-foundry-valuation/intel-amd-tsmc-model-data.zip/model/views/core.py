"""Disclosed financial comparisons and deliberately coarse operating scenarios."""

import math
from datetime import date

import polars as pl
from schemas import CAPITAL, CAPITAL_DETAILS, FINANCIAL, MIX, SCALE
from study import EXPLICIT_YEARS, ISSUERS, LATEST, STUDY

from mid_term_capital.view_engine import ALL, Field, result_schema, view
from mid_term_capital.view_engine.loader import FACT_SCHEMA


def fact_view(name, unit):
    @view(
        name=f"facts.{name}",
        entity_id=ALL,
        source=f"facts/{name}.csv",
        schema={
            k: Field(t, unit if k == "value" else None, "事实字段：" + k)
            for k, t in FACT_SCHEMA.items()
        },
    )
    def raw(inp):
        """Read canonical observations using the shared validating loader."""
        return STUDY.fact_frame(name)

    return raw


AMOUNTS = fact_view("amounts", "currency")
COUNTS = fact_view("counts", "count")
PER_UNIT = fact_view("per_unit", "currency_per_unit")
RATIOS = fact_view("ratios", "decimal_ratio")
INDEX = fact_view("index_levels", "multiple")


def get(frame, entity, metric, end, typ, optional=False):
    end = date.fromisoformat(end) if isinstance(end, str) else end
    selected = frame.filter(
        (pl.col("entity_id") == entity)
        & (pl.col("metric_id") == metric)
        & (pl.col("period_end") == end)
        & (pl.col("period_type") == typ)
    )
    if selected.is_empty() and optional:
        return None
    assert selected.height == 1, f"Fact selection: {entity}/{metric}/{end}/{typ}: {selected.height}"
    return selected["value"].item()


def at(frame, entity, metric, end, typ, default=None):
    value = get(frame, entity, metric, end, typ, optional=True)
    return default if value is None else value


def debt(frame, entity, end, typ):
    short = at(frame, entity, "debt_short", end, typ)
    long = at(frame, entity, "debt_long", end, typ)
    if long is None:
        bonds = at(frame, entity, "debt_bonds_noncurrent", end, typ)
        loans = at(frame, entity, "debt_loans_noncurrent", end, typ)
        if bonds is not None and loans is not None:
            long = bonds + loans
    if short is None or long is None:
        return None
    return short + long


@view(
    name="cross.financial_summary",
    entity_id=ALL,
    inputs=[AMOUNTS, COUNTS],
    schema=FINANCIAL,
    lineage={
        k: [AMOUNTS.fields.value, COUNTS.fields.value] for k, f in FINANCIAL.items() if f.unit
    },
)
def financial_summary(inp):
    """Reconcile reported cash, parent results and average-equity profitability."""
    amounts, counts = inp
    records = []
    periods = (
        amounts.filter(pl.col("entity_id").is_in(list(ISSUERS.values())))
        .select("entity_id", "period_end", "period_type")
        .unique()
    )
    for entity, end, typ in periods.iter_rows():
        r = {k: None for k in FINANCIAL}
        r.update(entity_id=entity, period_end=end, period_type=str(typ))
        for metric in [
            "revenue",
            "operating_profit",
            "net_income",
            "cfo",
            "equity_parent",
            "cash",
            "dividends_paid",
            "buybacks_paid",
            "sbc",
            "acquisitions_paid",
            "inventory",
            "receivables",
            "capex_cash",
        ]:
            r[metric] = at(amounts, entity, metric, end, typ)
        if r["revenue"] is None:
            continue
        gp = at(amounts, entity, "gross_profit", end, typ)
        r["gross_margin"] = gp / r["revenue"] if gp is not None else None
        r["operating_margin"] = (
            r["operating_profit"] / r["revenue"] if r["operating_profit"] is not None else None
        )
        cfo = at(amounts, entity, "cfo_continuing", end, typ, r["cfo"])
        r["cfo_continuing"] = cfo
        if cfo is not None and r["capex_cash"] is not None:
            financing = at(amounts, entity, "financing_capex_cash", end, typ, 0.0)
            leases = at(amounts, entity, "finance_lease_paid", end, typ, 0.0)
            r["gross_equipment_cash"] = r["capex_cash"] + financing + leases
            r["fcf_cfo_less_investing_capex"] = r["cfo"] - r["capex_cash"]
            r["cash_after_equipment"] = cfo - r["gross_equipment_cash"]
            r["cash_after_equipment_sbc"] = (
                r["cash_after_equipment"] - r["sbc"] if r["sbc"] is not None else None
            )
            if entity == ISSUERS["tsmc"]:
                ir = at(amounts, entity, "interest_received_cash", end, typ)
                ip = at(amounts, entity, "interest_paid_cash", end, typ)
                r["cash_after_equipment_interest"] = (
                    r["cash_after_equipment"] + ir - ip
                    if ir is not None and ip is not None
                    else None
                )
            else:
                r["cash_after_equipment_interest"] = r["cash_after_equipment"]
            assert math.isclose(
                cfo,
                r["cash_after_equipment"] + r["gross_equipment_cash"],
                rel_tol=1e-9,
                abs_tol=1e-9,
            ), "Cash definition failed"
        r["debt_ex_lease"] = debt(amounts, entity, end, typ)
        if r["debt_ex_lease"] is not None and r["cash"] is not None:
            r["net_debt_cash_only"] = r["debt_ex_lease"] - r["cash"]
        for m in ["shares_outstanding", "diluted_average_shares"]:
            r[m] = at(counts, entity, m, end, typ)
        if r["net_income"] is not None and r["diluted_average_shares"]:
            r["eps_calculated"] = r["net_income"] / r["diluted_average_shares"]
        if typ == "FY":
            prior = (
                amounts.filter(
                    (pl.col("entity_id") == entity)
                    & (pl.col("metric_id") == "equity_parent")
                    & (pl.col("period_type") == "FY")
                    & (pl.col("period_end") < end)
                )
                .sort("period_end")
                .tail(1)
            )
            if not prior.is_empty() and r["net_income"] is not None:
                r["roe_average"] = r["net_income"] / (
                    (r["equity_parent"] + prior["value"].item()) / 2
                )
        r["lease_disclosed"] = at(amounts, entity, "lease_total", end, typ)
        if r["lease_disclosed"] is None:
            r["lease_disclosed"] = at(amounts, entity, "lease_operating", end, typ)
        assets = at(amounts, entity, "assets", end, typ)
        liabilities = at(amounts, entity, "liabilities", end, typ)
        equity_group = at(amounts, entity, "equity_group", end, typ)
        if all(x is not None for x in [assets, liabilities, equity_group]):
            assert math.isclose(assets, liabilities + equity_group, rel_tol=1e-9, abs_tol=1e-6), (
                f"Balance sheet failed: {entity}/{end}"
            )
        records.append(r)
    return pl.DataFrame(records, schema={k: f.dtype for k, f in FINANCIAL.items()})


@view(
    name="cross.business_mix",
    entity_id=ALL,
    inputs=[AMOUNTS],
    schema=MIX,
    lineage={k: [AMOUNTS.fields.value] for k, f in MIX.items() if f.unit},
)
def business_mix(inp):
    """Keep internal and legacy segment scopes visible instead of merging them."""
    f = inp[0]
    rows = []
    for r in f.filter(pl.col("metric_id").str.starts_with("segment_revenue_")).iter_rows(
        named=True
    ):
        seg = r["metric_id"].removeprefix("segment_revenue_")
        if seg.endswith("_q3") or seg.startswith(("altera_", "foundry_external")):
            continue
        eid, end, typ = r["entity_id"], r["period_end"], r["period_type"]
        op = at(f, eid, "segment_profit_" + seg, end, typ)
        total = get(f, eid, "revenue", end, typ)
        positive = f.filter(
            (pl.col("entity_id") == eid)
            & (pl.col("period_end") == end)
            & (pl.col("period_type") == typ)
            & pl.col("metric_id").str.starts_with("segment_profit_")
            & ~pl.col("metric_id").str.contains("corporate|eliminations|_q3")
            & (pl.col("value") > 0)
        )["value"].sum()
        rows.append(
            [
                eid,
                end,
                str(typ),
                seg,
                r["value"],
                op,
                r["value"] / total,
                op / r["value"] if op is not None and r["value"] > 0 else None,
                op / positive if op is not None and op > 0 and positive > 0 else None,
            ]
        )
    return pl.DataFrame(rows, schema={k: f.dtype for k, f in MIX.items()}, orient="row")


OPERATING_PARAMETERS = {
    "remaining_revenue": "currency",
    "revenue_growth": "decimal_ratio",
    "operating_margin": "decimal_ratio",
    "normalized_tax": "decimal_ratio",
    "gross_capex_ratio": "decimal_ratio",
    "sensitivity_margin_shock": "decimal_ratio",
    "sensitivity_revenue_shock": "decimal_ratio",
    "incremental_margin": "decimal_ratio",
}


def build_issuer(short, entity):
    @view(
        name=f"{short}.assumptions",
        entity_id=entity,
        source="params",
        schema={
            "period": Field(pl.String, desc="预测财年"),
            **{p: Field(pl.Float64, u, "参数：" + p) for p, u in OPERATING_PARAMETERS.items()},
        },
    )
    def assumptions(inp):
        """Resolve the explicit issuer assumptions for each year and scenario."""
        scenario = STUDY.params.scenario_id
        rows = []
        for y in EXPLICIT_YEARS:
            r = {"period": str(y)}
            for p in OPERATING_PARAMETERS:
                r[p] = STUDY.params.resolve(
                    entity, p, str(2026 if p == "remaining_revenue" else y), scenario
                )
            rows.append(r)
        return pl.DataFrame(
            rows, schema={"period": pl.String, **{p: pl.Float64 for p in OPERATING_PARAMETERS}}
        )

    fields = {
        k: Field(t, "currency" if k == "value" else None, "预测字段：" + k)
        for k, t in result_schema.FORECAST_SCHEMA.items()
    }

    @view(
        name=f"{short}.forecast",
        entity_id=entity,
        inputs=[AMOUNTS, assumptions],
        schema=fields,
        lineage={
            "value": [AMOUNTS.fields.value, *[assumptions.fields[p] for p in OPERATING_PARAMETERS]]
        },
    )
    def forecast(inp):
        """Add the current-year remainder to actuals, then project broad economics."""
        amounts, pars = inp
        end, typ = LATEST[short]
        year_revenue = get(amounts, entity, "revenue", end, typ)
        year_profit = get(amounts, entity, "operating_profit", end, typ)
        rows = []
        revenue = None
        for p in pars.sort("period").iter_rows(named=True):
            year = int(p["period"])
            if year == min(EXPLICIT_YEARS):
                revenue = year_revenue + p["remaining_revenue"]
                profit = year_profit + p["remaining_revenue"] * p["operating_margin"]
            else:
                revenue *= 1 + p["revenue_growth"]
                profit = revenue * p["operating_margin"]
            assert revenue > 0, f"Revenue domain failed: {short}/{year}"
            for m, v in [("revenue", revenue), ("operating_profit", profit)]:
                rows.append(
                    [
                        entity,
                        STUDY.params.scenario_id,
                        str(year),
                        "consolidated",
                        m,
                        "estimate" if year == min(EXPLICIT_YEARS) else "forecast",
                        "explicit",
                        v,
                    ]
                )
        return pl.DataFrame(rows, schema=result_schema.FORECAST_SCHEMA, orient="row")

    @view(
        name=f"{short}.economics",
        entity_id=entity,
        inputs=[forecast, assumptions],
        schema=CAPITAL,
        lineage={
            k: [forecast.fields.value, *[assumptions.fields[p] for p in OPERATING_PARAMETERS]]
            for k, f in CAPITAL.items()
            if f.unit
        },
    )
    def economics(inp):
        """Expose tax-normalized operating earnings and the investment burden."""
        projection, pars = inp
        rows = []
        for p in pars.iter_rows(named=True):
            v = {
                r["metric_id"]: r["value"]
                for r in projection.filter(pl.col("period") == p["period"]).iter_rows(named=True)
            }
            revenue, profit = v["revenue"], v["operating_profit"]
            nopat = profit - max(profit, 0) * p["normalized_tax"]
            rows.append(
                [
                    entity,
                    STUDY.params.scenario_id,
                    p["period"],
                    revenue,
                    profit,
                    nopat,
                    revenue * p["gross_capex_ratio"],
                    revenue * p["sensitivity_margin_shock"] * (1 - p["normalized_tax"]),
                    revenue
                    * p["sensitivity_revenue_shock"]
                    * p["incremental_margin"]
                    * (1 - p["normalized_tax"]),
                    -revenue * p["sensitivity_margin_shock"],
                    revenue * p["sensitivity_margin_shock"] * (1 - p["normalized_tax"]) / nopat
                    if nopat
                    else None,
                    revenue
                    * p["sensitivity_revenue_shock"]
                    * p["incremental_margin"]
                    * (1 - p["normalized_tax"])
                    / nopat
                    if nopat
                    else None,
                    -revenue * p["sensitivity_margin_shock"] / nopat if nopat else None,
                ]
            )
        return pl.DataFrame(rows, schema={k: f.dtype for k, f in CAPITAL.items()}, orient="row")

    return forecast, economics


ISSUER_VIEWS = {short: build_issuer(short, entity) for short, entity in ISSUERS.items()}


@view(
    name="cross.forecast",
    entity_id=ALL,
    inputs=[v[0] for v in ISSUER_VIEWS.values()],
    schema={
        k: Field(t, "currency" if k == "value" else None, "跨公司预测：" + k)
        for k, t in result_schema.FORECAST_SCHEMA.items()
    },
    lineage={"value": [v[0].fields.value for v in ISSUER_VIEWS.values()]},
)
def forecast(inp):
    """Publish the three independent issuer forecasts in the framework shape."""
    return pl.concat(inp)


@view(
    name="cross.economics",
    entity_id=ALL,
    inputs=[v[1] for v in ISSUER_VIEWS.values()],
    schema=CAPITAL,
    lineage={
        k: [v[1].fields[k] for v in ISSUER_VIEWS.values()] for k, f in CAPITAL.items() if f.unit
    },
)
def economics(inp):
    """Publish final scenario economics and single-factor sensitivities."""
    return pl.concat(inp)


@view(
    name="cross.history",
    entity_id=ALL,
    inputs=[AMOUNTS],
    schema={
        k: Field(t, "currency" if k == "value" else None, "历史字段：" + k)
        for k, t in result_schema.HISTORY_SCHEMA.items()
    },
    lineage={"value": [AMOUNTS.fields.value]},
)
def history(inp):
    """Project only the two forecast metrics and preserve native fiscal labels."""
    return (
        inp[0]
        .filter(
            pl.col("entity_id").is_in(list(ISSUERS.values()))
            & (pl.col("period_type") == "FY")
            & (pl.col("period_end").dt.year() >= 2021)
            & pl.col("metric_id").is_in(["revenue", "operating_profit"])
        )
        .select(
            "entity_id",
            pl.lit("fact").alias("scenario"),
            pl.col("period_end").dt.year().cast(pl.String).alias("period"),
            pl.lit("consolidated").alias("segment_id"),
            "metric_id",
            pl.lit("actual").cast(result_schema.BASIS).alias("basis"),
            pl.lit("explicit").cast(result_schema.NODE).alias("node_type"),
            "value",
        )
    )


@view(
    name="cross.diagnostics_parameters",
    entity_id=ALL,
    source="params",
    schema={"diagnostic_threshold": Field(pl.Float64, "multiple", "量级诊断参考值")},
)
def diagnostics_parameters(inp):
    """Expose the global diagnostic assumption as a declared lineage leaf."""
    return pl.DataFrame(
        {
            "diagnostic_threshold": [
                STUDY.params.resolve(ALL, "diagnostic_threshold", "ALL", STUDY.params.scenario_id)
            ]
        }
    )


@view(
    name="cross.scale_check",
    entity_id=ALL,
    inputs=[AMOUNTS, diagnostics_parameters],
    schema=SCALE,
    lineage={
        k: [AMOUNTS.fields.value, diagnostics_parameters.fields.diagnostic_threshold]
        for k, f in SCALE.items()
        if f.unit
    },
)
def scale_check(inp):
    """Show material amounts against revenue without asserting business plausibility."""
    f = inp[0]
    threshold = inp[1]["diagnostic_threshold"].item()
    base = f.filter(pl.col("metric_id") == "revenue").select(
        "entity_id", "period_end", "period_type", pl.col("value").alias("scale")
    )
    selected = f.filter(
        pl.col("entity_id").is_in(list(ISSUERS.values()))
        & ~pl.col("metric_id").is_in(["revenue", "semiconductor_sales_usd"])
    )
    joined = selected.join(
        base, on=["entity_id", "period_end", "period_type"], how="inner", validate="m:1"
    )
    assert joined.height <= selected.height, "Scale join expanded rows"
    return joined.select(
        "entity_id",
        "metric_id",
        "period_end",
        pl.col("period_type").cast(pl.String),
        "value",
        "scale",
        pl.lit("revenue").alias("scale_metric_id"),
        (pl.col("value") / pl.col("scale")).alias("ratio"),
        pl.lit(threshold).alias("threshold"),
        ((pl.col("value") / pl.col("scale")).abs() > threshold).alias("exceeded"),
    )


@view(
    name="cross.capital_details",
    entity_id=ALL,
    inputs=[AMOUNTS],
    schema=CAPITAL_DETAILS,
    lineage={"value": [AMOUNTS.fields.value]},
)
def capital_details(inp):
    """Expose funding, acquisitions and contractual claims with their original scope."""
    return (
        inp[0]
        .filter(
            pl.col("entity_id").is_in(list(ISSUERS.values()))
            & (pl.col("period_end").dt.year() >= 2021)
            & (
                pl.col("metric_id").str.contains(
                    "proceeds|acquisitions_paid|acquisition_xilinx|partner_contributions|partner_distributions|ireland_nci|debt_due|debt_contractual|lease_contractual|commitment|disclosed_2026_gross_capex|disclosed_2027_nci|disclosed_2028_nci|finance_lease_paid|financing_capex"
                )
            )
        )
        .with_columns(pl.col("period_type").cast(pl.String))
        .select(list(CAPITAL_DETAILS))
    )
