"""Single registry of disclosed metrics and canonical units."""

from mid_term_capital.view_engine.loader import FactSpec

FACT_FILES = {
    "amounts": ("facts/amounts.csv", "currency"),
    "counts": ("facts/counts.csv", "count"),
    "ratios": ("facts/ratios.csv", "decimal_ratio"),
    "per_unit": ("facts/per_unit.csv", "currency_per_unit"),
    "index_levels": ("facts/index_levels.csv", "multiple"),
}

FACTS = {
    "world_labs_acquisition_commitment": FactSpec(
        "currency",
        "Announced approximately USD8200m all-stock purchase price; signed September 26, disclosed September 28, 2026; not cash paid, shares unknown until closing VWAP",
    ),
    "meta_equity_investment_commitment": FactSpec(
        "currency",
        "October 27, 2026 release: AMD will invest USD1000m in Meta equity offering; not sales or confirmed cash payment; overlap with other commitments not disclosed",
    ),
    "disclosed_2026_gross_capex_outlook": FactSpec(
        "currency",
        "Prepared remarks p7: 2026 gross capital expenditures outlook, USD million; additions/accrual capital measure, not investing cash or achieved result",
    ),
    "disclosed_q4_fab28_revenue_impact": FactSpec(
        "currency",
        "Prepared remarks p6–7: approximately $300m revenue headwind from Fab28 already included in Q4 revenue guidance; not total accident loss",
    ),
    "disclosed_2027_nci_income_outlook": FactSpec(
        "currency",
        "Prepared remarks p7: approximate 2027 non-controlling-interest earnings claim; not NCI book equity or cash payout",
    ),
    "disclosed_2028_nci_income_outlook": FactSpec(
        "currency",
        "Prepared remarks p7: approximate 2028 non-controlling-interest earnings claim; not NCI book equity or cash payout",
    ),
    "substrate_funding_commitment_low": FactSpec(
        "currency",
        "10-Q Note14: estimated total funding under two subsequent substrate supply agreements, low bound, USD million; terms not fully final",
    ),
    "substrate_funding_commitment_high": FactSpec(
        "currency",
        "10-Q Note14: estimated total funding under same agreements, high bound; do not add low/high together",
    ),
    "substrate_commitment_paid_by_2027": FactSpec(
        "currency",
        "10-Q Note14/MD&A Funding Requirements: approximately payable by end-2027; subset of 5.3–6.1bn, do not add again",
    ),
    "classiq_acquisition_base_commitment": FactSpec(
        "currency",
        "10-Q Subsequent Events/Funding Requirements: proposed Classiq purchase approx $1.9bn, expected H1 2027 close, can settle cash or common stock, not completed cash acquisition",
    ),
    "classiq_acquisition_contingent_commitment": FactSpec(
        "currency",
        "10-Q proposed Classiq: up to $350m contingent consideration for performance milestones; not paid or guaranteed",
    ),
    "disclosed_pc_tam_growth_2026": FactSpec(
        "decimal_ratio",
        "Prepared remarks p6: management estimated whole-market PC unit TAM 2026 decline approximately12%; not Intel revenue or actual result",
    ),
    "disclosed_pc_tam_growth_2027": FactSpec(
        "decimal_ratio",
        "Prepared remarks p6: planning whole-market PC unit TAM 2027 decline roughly10%; not Intel revenue or actual result",
    ),
    "disclosed_fab28_q4_margin_impact": FactSpec(
        "decimal_ratio",
        "Prepared remarks p6: roughly200bp gross-margin headwind already included Q4 outlook; not an independently additive second shock",
    ),
    "disclosed_q4_diluted_shares_outlook": FactSpec(
        "count",
        "Prepared remarks p7: Q4 fully diluted weighted shares outlook5.44bn; not current issued shares",
    ),
    "investment_commitment_after_h1": FactSpec(
        "currency", "未来承诺上限或未折现租赁支付，非当期现金/账面债务；百万美元"
    ),
    "lease_contractual_future_data_center": FactSpec(
        "currency", "未来承诺上限或未折现租赁支付，非当期现金/账面债务；百万美元"
    ),
    "lease_contractual_not_commenced": FactSpec(
        "currency", "未来承诺上限或未折现租赁支付，非当期现金/账面债务；百万美元"
    ),
    "profit_guidance_low_gaap_gross_margin_2024q1": FactSpec(
        "decimal_ratio", "profit_guidance_low_gaap_gross_margin_2024q1"
    ),
    "profit_guidance_high_gaap_gross_margin_2024q1": FactSpec(
        "decimal_ratio", "profit_guidance_high_gaap_gross_margin_2024q1"
    ),
    "profit_guidance_actual_gaap_gross_margin_2024q1": FactSpec(
        "decimal_ratio", "profit_guidance_actual_gaap_gross_margin_2024q1"
    ),
    "profit_guidance_low_non_gaap_gross_margin_2024q1": FactSpec(
        "decimal_ratio", "profit_guidance_low_non_gaap_gross_margin_2024q1"
    ),
    "profit_guidance_high_non_gaap_gross_margin_2024q1": FactSpec(
        "decimal_ratio", "profit_guidance_high_non_gaap_gross_margin_2024q1"
    ),
    "profit_guidance_actual_non_gaap_gross_margin_2024q1": FactSpec(
        "decimal_ratio", "profit_guidance_actual_non_gaap_gross_margin_2024q1"
    ),
    "profit_guidance_low_gaap_eps_2024q1": FactSpec(
        "currency_per_unit", "profit_guidance_low_gaap_eps_2024q1"
    ),
    "profit_guidance_high_gaap_eps_2024q1": FactSpec(
        "currency_per_unit", "profit_guidance_high_gaap_eps_2024q1"
    ),
    "profit_guidance_actual_gaap_eps_2024q1": FactSpec(
        "currency_per_unit", "profit_guidance_actual_gaap_eps_2024q1"
    ),
    "profit_guidance_low_non_gaap_eps_2024q1": FactSpec(
        "currency_per_unit", "profit_guidance_low_non_gaap_eps_2024q1"
    ),
    "profit_guidance_high_non_gaap_eps_2024q1": FactSpec(
        "currency_per_unit", "profit_guidance_high_non_gaap_eps_2024q1"
    ),
    "profit_guidance_actual_non_gaap_eps_2024q1": FactSpec(
        "currency_per_unit", "profit_guidance_actual_non_gaap_eps_2024q1"
    ),
    "profit_guidance_low_gaap_gross_margin_2024q3": FactSpec(
        "decimal_ratio", "profit_guidance_low_gaap_gross_margin_2024q3"
    ),
    "profit_guidance_high_gaap_gross_margin_2024q3": FactSpec(
        "decimal_ratio", "profit_guidance_high_gaap_gross_margin_2024q3"
    ),
    "profit_guidance_actual_gaap_gross_margin_2024q3": FactSpec(
        "decimal_ratio", "profit_guidance_actual_gaap_gross_margin_2024q3"
    ),
    "profit_guidance_low_non_gaap_gross_margin_2024q3": FactSpec(
        "decimal_ratio", "profit_guidance_low_non_gaap_gross_margin_2024q3"
    ),
    "profit_guidance_high_non_gaap_gross_margin_2024q3": FactSpec(
        "decimal_ratio", "profit_guidance_high_non_gaap_gross_margin_2024q3"
    ),
    "profit_guidance_actual_non_gaap_gross_margin_2024q3": FactSpec(
        "decimal_ratio", "profit_guidance_actual_non_gaap_gross_margin_2024q3"
    ),
    "profit_guidance_low_gaap_eps_2024q3": FactSpec(
        "currency_per_unit", "profit_guidance_low_gaap_eps_2024q3"
    ),
    "profit_guidance_high_gaap_eps_2024q3": FactSpec(
        "currency_per_unit", "profit_guidance_high_gaap_eps_2024q3"
    ),
    "profit_guidance_actual_gaap_eps_2024q3": FactSpec(
        "currency_per_unit", "profit_guidance_actual_gaap_eps_2024q3"
    ),
    "profit_guidance_low_non_gaap_eps_2024q3": FactSpec(
        "currency_per_unit", "profit_guidance_low_non_gaap_eps_2024q3"
    ),
    "profit_guidance_high_non_gaap_eps_2024q3": FactSpec(
        "currency_per_unit", "profit_guidance_high_non_gaap_eps_2024q3"
    ),
    "profit_guidance_actual_non_gaap_eps_2024q3": FactSpec(
        "currency_per_unit", "profit_guidance_actual_non_gaap_eps_2024q3"
    ),
    "profit_guidance_low_gaap_gross_margin_2025q1": FactSpec(
        "decimal_ratio", "profit_guidance_low_gaap_gross_margin_2025q1"
    ),
    "profit_guidance_high_gaap_gross_margin_2025q1": FactSpec(
        "decimal_ratio", "profit_guidance_high_gaap_gross_margin_2025q1"
    ),
    "profit_guidance_actual_gaap_gross_margin_2025q1": FactSpec(
        "decimal_ratio", "profit_guidance_actual_gaap_gross_margin_2025q1"
    ),
    "profit_guidance_low_non_gaap_gross_margin_2025q1": FactSpec(
        "decimal_ratio", "profit_guidance_low_non_gaap_gross_margin_2025q1"
    ),
    "profit_guidance_high_non_gaap_gross_margin_2025q1": FactSpec(
        "decimal_ratio", "profit_guidance_high_non_gaap_gross_margin_2025q1"
    ),
    "profit_guidance_actual_non_gaap_gross_margin_2025q1": FactSpec(
        "decimal_ratio", "profit_guidance_actual_non_gaap_gross_margin_2025q1"
    ),
    "profit_guidance_low_gaap_eps_2025q1": FactSpec(
        "currency_per_unit", "profit_guidance_low_gaap_eps_2025q1"
    ),
    "profit_guidance_high_gaap_eps_2025q1": FactSpec(
        "currency_per_unit", "profit_guidance_high_gaap_eps_2025q1"
    ),
    "profit_guidance_actual_gaap_eps_2025q1": FactSpec(
        "currency_per_unit", "profit_guidance_actual_gaap_eps_2025q1"
    ),
    "profit_guidance_low_non_gaap_eps_2025q1": FactSpec(
        "currency_per_unit", "profit_guidance_low_non_gaap_eps_2025q1"
    ),
    "profit_guidance_high_non_gaap_eps_2025q1": FactSpec(
        "currency_per_unit", "profit_guidance_high_non_gaap_eps_2025q1"
    ),
    "profit_guidance_actual_non_gaap_eps_2025q1": FactSpec(
        "currency_per_unit", "profit_guidance_actual_non_gaap_eps_2025q1"
    ),
    "profit_guidance_low_gaap_gross_margin_2025q3": FactSpec(
        "decimal_ratio", "profit_guidance_low_gaap_gross_margin_2025q3"
    ),
    "profit_guidance_high_gaap_gross_margin_2025q3": FactSpec(
        "decimal_ratio", "profit_guidance_high_gaap_gross_margin_2025q3"
    ),
    "profit_guidance_actual_gaap_gross_margin_2025q3": FactSpec(
        "decimal_ratio", "profit_guidance_actual_gaap_gross_margin_2025q3"
    ),
    "profit_guidance_low_non_gaap_gross_margin_2025q3": FactSpec(
        "decimal_ratio", "profit_guidance_low_non_gaap_gross_margin_2025q3"
    ),
    "profit_guidance_high_non_gaap_gross_margin_2025q3": FactSpec(
        "decimal_ratio", "profit_guidance_high_non_gaap_gross_margin_2025q3"
    ),
    "profit_guidance_actual_non_gaap_gross_margin_2025q3": FactSpec(
        "decimal_ratio", "profit_guidance_actual_non_gaap_gross_margin_2025q3"
    ),
    "profit_guidance_low_gaap_eps_2025q3": FactSpec(
        "currency_per_unit", "profit_guidance_low_gaap_eps_2025q3"
    ),
    "profit_guidance_high_gaap_eps_2025q3": FactSpec(
        "currency_per_unit", "profit_guidance_high_gaap_eps_2025q3"
    ),
    "profit_guidance_actual_gaap_eps_2025q3": FactSpec(
        "currency_per_unit", "profit_guidance_actual_gaap_eps_2025q3"
    ),
    "profit_guidance_low_non_gaap_eps_2025q3": FactSpec(
        "currency_per_unit", "profit_guidance_low_non_gaap_eps_2025q3"
    ),
    "profit_guidance_high_non_gaap_eps_2025q3": FactSpec(
        "currency_per_unit", "profit_guidance_high_non_gaap_eps_2025q3"
    ),
    "profit_guidance_actual_non_gaap_eps_2025q3": FactSpec(
        "currency_per_unit", "profit_guidance_actual_non_gaap_eps_2025q3"
    ),
    "profit_guidance_low_gaap_gross_margin_2026q1": FactSpec(
        "decimal_ratio", "profit_guidance_low_gaap_gross_margin_2026q1"
    ),
    "profit_guidance_high_gaap_gross_margin_2026q1": FactSpec(
        "decimal_ratio", "profit_guidance_high_gaap_gross_margin_2026q1"
    ),
    "profit_guidance_actual_gaap_gross_margin_2026q1": FactSpec(
        "decimal_ratio", "profit_guidance_actual_gaap_gross_margin_2026q1"
    ),
    "profit_guidance_low_non_gaap_gross_margin_2026q1": FactSpec(
        "decimal_ratio", "profit_guidance_low_non_gaap_gross_margin_2026q1"
    ),
    "profit_guidance_high_non_gaap_gross_margin_2026q1": FactSpec(
        "decimal_ratio", "profit_guidance_high_non_gaap_gross_margin_2026q1"
    ),
    "profit_guidance_actual_non_gaap_gross_margin_2026q1": FactSpec(
        "decimal_ratio", "profit_guidance_actual_non_gaap_gross_margin_2026q1"
    ),
    "profit_guidance_low_gaap_eps_2026q1": FactSpec(
        "currency_per_unit", "profit_guidance_low_gaap_eps_2026q1"
    ),
    "profit_guidance_high_gaap_eps_2026q1": FactSpec(
        "currency_per_unit", "profit_guidance_high_gaap_eps_2026q1"
    ),
    "profit_guidance_actual_gaap_eps_2026q1": FactSpec(
        "currency_per_unit", "profit_guidance_actual_gaap_eps_2026q1"
    ),
    "profit_guidance_low_non_gaap_eps_2026q1": FactSpec(
        "currency_per_unit", "profit_guidance_low_non_gaap_eps_2026q1"
    ),
    "profit_guidance_high_non_gaap_eps_2026q1": FactSpec(
        "currency_per_unit", "profit_guidance_high_non_gaap_eps_2026q1"
    ),
    "profit_guidance_actual_non_gaap_eps_2026q1": FactSpec(
        "currency_per_unit", "profit_guidance_actual_non_gaap_eps_2026q1"
    ),
    "profit_guidance_low_gaap_gross_margin_2026q3": FactSpec(
        "decimal_ratio", "profit_guidance_low_gaap_gross_margin_2026q3"
    ),
    "profit_guidance_high_gaap_gross_margin_2026q3": FactSpec(
        "decimal_ratio", "profit_guidance_high_gaap_gross_margin_2026q3"
    ),
    "profit_guidance_actual_gaap_gross_margin_2026q3": FactSpec(
        "decimal_ratio", "profit_guidance_actual_gaap_gross_margin_2026q3"
    ),
    "profit_guidance_low_non_gaap_gross_margin_2026q3": FactSpec(
        "decimal_ratio", "profit_guidance_low_non_gaap_gross_margin_2026q3"
    ),
    "profit_guidance_high_non_gaap_gross_margin_2026q3": FactSpec(
        "decimal_ratio", "profit_guidance_high_non_gaap_gross_margin_2026q3"
    ),
    "profit_guidance_actual_non_gaap_gross_margin_2026q3": FactSpec(
        "decimal_ratio", "profit_guidance_actual_non_gaap_gross_margin_2026q3"
    ),
    "profit_guidance_low_gaap_eps_2026q3": FactSpec(
        "currency_per_unit", "profit_guidance_low_gaap_eps_2026q3"
    ),
    "profit_guidance_high_gaap_eps_2026q3": FactSpec(
        "currency_per_unit", "profit_guidance_high_gaap_eps_2026q3"
    ),
    "profit_guidance_actual_gaap_eps_2026q3": FactSpec(
        "currency_per_unit", "profit_guidance_actual_gaap_eps_2026q3"
    ),
    "profit_guidance_low_non_gaap_eps_2026q3": FactSpec(
        "currency_per_unit", "profit_guidance_low_non_gaap_eps_2026q3"
    ),
    "profit_guidance_high_non_gaap_eps_2026q3": FactSpec(
        "currency_per_unit", "profit_guidance_high_non_gaap_eps_2026q3"
    ),
    "profit_guidance_actual_non_gaap_eps_2026q3": FactSpec(
        "currency_per_unit", "profit_guidance_actual_non_gaap_eps_2026q3"
    ),
    "profit_guidance_low_gaap_operating_margin_2024q1": FactSpec(
        "decimal_ratio", "profit_guidance_low_gaap_operating_margin_2024q1"
    ),
    "profit_guidance_high_gaap_operating_margin_2024q1": FactSpec(
        "decimal_ratio", "profit_guidance_high_gaap_operating_margin_2024q1"
    ),
    "profit_guidance_actual_gaap_operating_margin_2024q1": FactSpec(
        "decimal_ratio", "profit_guidance_actual_gaap_operating_margin_2024q1"
    ),
    "profit_guidance_low_gaap_operating_margin_2024q3": FactSpec(
        "decimal_ratio", "profit_guidance_low_gaap_operating_margin_2024q3"
    ),
    "profit_guidance_high_gaap_operating_margin_2024q3": FactSpec(
        "decimal_ratio", "profit_guidance_high_gaap_operating_margin_2024q3"
    ),
    "profit_guidance_actual_gaap_operating_margin_2024q3": FactSpec(
        "decimal_ratio", "profit_guidance_actual_gaap_operating_margin_2024q3"
    ),
    "profit_guidance_low_gaap_operating_margin_2025q1": FactSpec(
        "decimal_ratio", "profit_guidance_low_gaap_operating_margin_2025q1"
    ),
    "profit_guidance_high_gaap_operating_margin_2025q1": FactSpec(
        "decimal_ratio", "profit_guidance_high_gaap_operating_margin_2025q1"
    ),
    "profit_guidance_actual_gaap_operating_margin_2025q1": FactSpec(
        "decimal_ratio", "profit_guidance_actual_gaap_operating_margin_2025q1"
    ),
    "profit_guidance_low_gaap_operating_margin_2025q3": FactSpec(
        "decimal_ratio", "profit_guidance_low_gaap_operating_margin_2025q3"
    ),
    "profit_guidance_high_gaap_operating_margin_2025q3": FactSpec(
        "decimal_ratio", "profit_guidance_high_gaap_operating_margin_2025q3"
    ),
    "profit_guidance_actual_gaap_operating_margin_2025q3": FactSpec(
        "decimal_ratio", "profit_guidance_actual_gaap_operating_margin_2025q3"
    ),
    "profit_guidance_low_gaap_operating_margin_2026q1": FactSpec(
        "decimal_ratio", "profit_guidance_low_gaap_operating_margin_2026q1"
    ),
    "profit_guidance_high_gaap_operating_margin_2026q1": FactSpec(
        "decimal_ratio", "profit_guidance_high_gaap_operating_margin_2026q1"
    ),
    "profit_guidance_actual_gaap_operating_margin_2026q1": FactSpec(
        "decimal_ratio", "profit_guidance_actual_gaap_operating_margin_2026q1"
    ),
    "profit_guidance_low_gaap_operating_margin_2026q3": FactSpec(
        "decimal_ratio", "profit_guidance_low_gaap_operating_margin_2026q3"
    ),
    "profit_guidance_high_gaap_operating_margin_2026q3": FactSpec(
        "decimal_ratio", "profit_guidance_high_gaap_operating_margin_2026q3"
    ),
    "profit_guidance_actual_gaap_operating_margin_2026q3": FactSpec(
        "decimal_ratio", "profit_guidance_actual_gaap_operating_margin_2026q3"
    ),
    "lease_contractual_payments": FactSpec("currency", "未折现合同现金流，含利息；百万元"),
    "debt_contractual_bonds_under1": FactSpec("currency", "未折现合同现金流，含利息；百万元"),
    "debt_contractual_bonds_1to3": FactSpec("currency", "未折现合同现金流，含利息；百万元"),
    "debt_contractual_bonds_3to5": FactSpec("currency", "未折现合同现金流，含利息；百万元"),
    "debt_contractual_bonds_over5": FactSpec("currency", "未折现合同现金流，含利息；百万元"),
    "debt_contractual_loans_under1": FactSpec("currency", "未折现合同现金流，含利息；百万元"),
    "debt_contractual_loans_1to3": FactSpec("currency", "未折现合同现金流，含利息；百万元"),
    "debt_contractual_loans_3to5": FactSpec("currency", "未折现合同现金流，含利息；百万元"),
    "debt_contractual_loans_over5": FactSpec("currency", "未折现合同现金流，含利息；百万元"),
    "guidance_revenue_usd_low_2024q1": FactSpec("currency", "guidance_revenue_usd_low_2024q1"),
    "guidance_revenue_usd_high_2024q1": FactSpec("currency", "guidance_revenue_usd_high_2024q1"),
    "earnings_release_event": FactSpec("decimal_ratio", "earnings_release_event"),
    "guidance_revenue_usd_low_2024q3": FactSpec("currency", "guidance_revenue_usd_low_2024q3"),
    "guidance_revenue_usd_high_2024q3": FactSpec("currency", "guidance_revenue_usd_high_2024q3"),
    "guidance_revenue_usd_low_2025q1": FactSpec("currency", "guidance_revenue_usd_low_2025q1"),
    "guidance_revenue_usd_high_2025q1": FactSpec("currency", "guidance_revenue_usd_high_2025q1"),
    "guidance_revenue_usd_low_2025q3": FactSpec("currency", "guidance_revenue_usd_low_2025q3"),
    "guidance_revenue_usd_high_2025q3": FactSpec("currency", "guidance_revenue_usd_high_2025q3"),
    "guidance_revenue_usd_low_2026q1": FactSpec("currency", "guidance_revenue_usd_low_2026q1"),
    "guidance_revenue_usd_high_2026q1": FactSpec("currency", "guidance_revenue_usd_high_2026q1"),
    "guidance_revenue_usd_low_2026q3": FactSpec("currency", "guidance_revenue_usd_low_2026q3"),
    "guidance_revenue_usd_high_2026q3": FactSpec("currency", "guidance_revenue_usd_high_2026q3"),
    "actual_revenue_usd_2024q1": FactSpec("currency", "actual_revenue_usd_2024q1"),
    "actual_revenue_usd_2024q3": FactSpec("currency", "actual_revenue_usd_2024q3"),
    "actual_revenue_usd_2025q1": FactSpec("currency", "actual_revenue_usd_2025q1"),
    "actual_revenue_usd_2025q3": FactSpec("currency", "actual_revenue_usd_2025q3"),
    "actual_revenue_usd_2026q1": FactSpec("currency", "actual_revenue_usd_2026q1"),
    "actual_revenue_usd_2026q3": FactSpec("currency", "actual_revenue_usd_2026q3"),
    "ceo_total_accrued_compensation": FactSpec("currency", "ceo_total_accrued_compensation"),
    "associate_disposal_gain": FactSpec("currency", "associate_disposal_gain"),
    "lease_total": FactSpec("currency", "含流动与非流动的租赁负债总额，百万元"),
    "snapshot_price": FactSpec(
        "currency_per_unit", "2026-10-30时点报价，具体UTC时间在source_locator；美股盘中、台股收盘"
    ),
    "escrow_unreleased_shares": FactSpec("count", "尚未释放的美国政府托管股份，百万股"),
    "government_conditional_warrants": FactSpec(
        "count", "失去代工控制权时可行权的政府认股权证上限，百万股"
    ),
    "government_warrant_strike": FactSpec(
        "currency_per_unit", "有条件政府认股权证行权价，美元每股"
    ),
    "acquisition_xilinx_consideration": FactSpec("currency", "acquisition_xilinx_consideration"),
    "acquisitions_paid": FactSpec("currency", "acquisitions_paid"),
    "advanced_wafer_revenue_share": FactSpec("decimal_ratio", "advanced_wafer_revenue_share"),
    "assets": FactSpec("currency", "assets"),
    "basic_average_shares": FactSpec("count", "basic_average_shares"),
    "buybacks_paid": FactSpec("currency", "公开回购计划实际支出，不含代缴税扣股支出"),
    "capex_cash": FactSpec(
        "currency", "投资活动中购建有形固定资产的现金支出，取正数；融资活动另列"
    ),
    "cash": FactSpec("currency", "cash"),
    "cash_dividend_per_share": FactSpec("currency_per_unit", "除息日每股现金股息"),
    "ceo_bonus_target_payout": FactSpec("decimal_ratio", "ceo_bonus_target_payout"),
    "ceo_cash_bonus": FactSpec("currency", "ceo_cash_bonus"),
    "ceo_total_grant_compensation": FactSpec("currency", "ceo_total_grant_compensation"),
    "cfo": FactSpec("currency", "合并经营现金流；AMD2025含终止经营，另存持续经营口径"),
    "cfo_continuing": FactSpec("currency", "持续经营经营现金流；不能将终止经营现金流外推"),
    "client_asp_growth": FactSpec("decimal_ratio", "client_asp_growth"),
    "client_asp_growth_q2": FactSpec("decimal_ratio", "client_asp_growth_q2"),
    "client_asp_growth_q3": FactSpec("decimal_ratio", "client_asp_growth_q3"),
    "client_unit_growth": FactSpec("decimal_ratio", "client_unit_growth"),
    "client_unit_growth_q2": FactSpec("decimal_ratio", "client_unit_growth_q2"),
    "client_unit_growth_q3": FactSpec("decimal_ratio", "client_unit_growth_q3"),
    "close_price": FactSpec("currency_per_unit", "未分红复权收盘价；指数为价格指数点位"),
    "common_plan_proceeds": FactSpec("currency", "common_plan_proceeds"),
    "customer_warrants_meta": FactSpec("count", "customer_warrants_meta"),
    "customer_warrants_openai": FactSpec("count", "customer_warrants_openai"),
    "debt_bonds_noncurrent": FactSpec("currency", "debt_bonds_noncurrent"),
    "debt_due_1": FactSpec("currency", "debt_due_1"),
    "debt_due_2": FactSpec("currency", "debt_due_2"),
    "debt_due_3": FactSpec("currency", "debt_due_3"),
    "debt_due_4": FactSpec("currency", "debt_due_4"),
    "debt_due_5": FactSpec("currency", "debt_due_5"),
    "debt_due_after5": FactSpec("currency", "debt_due_after5"),
    "debt_loans_noncurrent": FactSpec("currency", "debt_loans_noncurrent"),
    "debt_long": FactSpec("currency", "非流动有息负债账面值，不含流动部分和经营租赁"),
    "debt_short": FactSpec("currency", "流动有息负债账面值"),
    "diluted_average_shares": FactSpec("count", "稀释加权平均股数，百万股，亏损期反稀释股份被排除"),
    "dividends_paid": FactSpec("currency", "期间实际支付普通股现金股息，取正数"),
    "equity_group": FactSpec("currency", "合并净资产，含少数股东"),
    "equity_parent": FactSpec("currency", "归母净资产，期末"),
    "equity_parent_sec": FactSpec("currency", "equity_parent_sec"),
    "equity_warrants_escrow_proceeds": FactSpec("currency", "equity_warrants_escrow_proceeds"),
    "escrow_fair_value_loss": FactSpec("currency", "escrow_fair_value_loss"),
    "escrow_liability": FactSpec("currency", "escrow_liability"),
    "finance_lease_paid": FactSpec("currency", "finance_lease_paid"),
    "financing_capex_cash": FactSpec("currency", "financing_capex_cash"),
    "goodwill": FactSpec("currency", "goodwill"),
    "gross_profit": FactSpec("currency", "合并毛利润，期内累计"),
    "gross_profit_q2": FactSpec("currency", "gross_profit_q2"),
    "gross_profit_q3": FactSpec("currency", "gross_profit_q3"),
    "income_tax": FactSpec("currency", "income_tax"),
    "index_level": FactSpec("multiple", "价格指数收盘点位，无股息"),
    "intangible_capex_cash": FactSpec("currency", "intangible_capex_cash"),
    "interest_expense": FactSpec("currency", "interest_expense"),
    "interest_paid_cash": FactSpec("currency", "interest_paid_cash"),
    "interest_received_cash": FactSpec("currency", "interest_received_cash"),
    "inventory": FactSpec("currency", "inventory"),
    "ireland_nci_purchase": FactSpec("currency", "ireland_nci_purchase"),
    "lease_noncurrent": FactSpec("currency", "lease_noncurrent"),
    "lease_operating": FactSpec("currency", "lease_operating"),
    "lease_operating_current": FactSpec("currency", "lease_operating_current"),
    "lease_operating_noncurrent": FactSpec("currency", "lease_operating_noncurrent"),
    "liabilities": FactSpec("currency", "liabilities"),
    "nci_equity": FactSpec("currency", "nci_equity"),
    "net_income": FactSpec("currency", "归属于发行人普通股股东的GAAP或台湾IFRS利润，期内累计"),
    "net_income_group": FactSpec("currency", "合并净利润，含少数股东，不与归母重复相加"),
    "net_income_nci": FactSpec("currency", "少数股东损益，保留正负号"),
    "net_income_q2": FactSpec("currency", "net_income_q2"),
    "net_income_q3": FactSpec("currency", "net_income_q3"),
    "net_income_sec": FactSpec("currency", "net_income_sec"),
    "node2_wafer_share_q3": FactSpec("decimal_ratio", "node2_wafer_share_q3"),
    "node3_wafer_share_q3": FactSpec("decimal_ratio", "node3_wafer_share_q3"),
    "node5_wafer_share_q3": FactSpec("decimal_ratio", "node5_wafer_share_q3"),
    "node7_wafer_share_q3": FactSpec("decimal_ratio", "node7_wafer_share_q3"),
    "operating_profit": FactSpec("currency", "合并营业利润，含已披露重组及摊销"),
    "operating_profit_q2": FactSpec("currency", "operating_profit_q2"),
    "operating_profit_q3": FactSpec("currency", "operating_profit_q3"),
    "partner_contributions": FactSpec("currency", "partner_contributions"),
    "partner_distributions": FactSpec("currency", "partner_distributions"),
    "ppne": FactSpec("currency", "ppne"),
    "pretax_profit": FactSpec("currency", "pretax_profit"),
    "prsu_2022_vested_ratio": FactSpec("decimal_ratio", "prsu_2022_vested_ratio"),
    "public_equity_proceeds": FactSpec("currency", "public_equity_proceeds"),
    "rd": FactSpec("currency", "rd"),
    "receivables": FactSpec("currency", "receivables"),
    "revenue": FactSpec("currency", "合并营业收入，期内累计；季度独立值使用_q3或_q2后缀"),
    "revenue_q2": FactSpec("currency", "revenue_q2"),
    "revenue_q3": FactSpec("currency", "revenue_q3"),
    "sbc": FactSpec("currency", "sbc"),
    "segment_profit_client": FactSpec("currency", "segment_profit_client"),
    "segment_profit_client_gaming": FactSpec("currency", "segment_profit_client_gaming"),
    "segment_profit_client_legacy": FactSpec("currency", "segment_profit_client_legacy"),
    "segment_profit_client_q3": FactSpec("currency", "segment_profit_client_q3"),
    "segment_profit_corporate": FactSpec("currency", "segment_profit_corporate"),
    "segment_profit_datacenter": FactSpec("currency", "segment_profit_datacenter"),
    "segment_profit_datacenter_legacy": FactSpec("currency", "segment_profit_datacenter_legacy"),
    "segment_profit_datacenter_q3": FactSpec("currency", "segment_profit_datacenter_q3"),
    "segment_profit_eliminations": FactSpec("currency", "segment_profit_eliminations"),
    "segment_profit_embedded": FactSpec("currency", "segment_profit_embedded"),
    "segment_profit_foundry": FactSpec("currency", "segment_profit_foundry"),
    "segment_profit_foundry_q3": FactSpec("currency", "segment_profit_foundry_q3"),
    "segment_profit_gaming_legacy": FactSpec("currency", "segment_profit_gaming_legacy"),
    "segment_profit_ifs_legacy": FactSpec("currency", "segment_profit_ifs_legacy"),
    "segment_profit_mobileye_legacy": FactSpec("currency", "segment_profit_mobileye_legacy"),
    "segment_profit_network_legacy": FactSpec("currency", "segment_profit_network_legacy"),
    "segment_profit_other": FactSpec("currency", "segment_profit_other"),
    "segment_profit_other_legacy": FactSpec("currency", "segment_profit_other_legacy"),
    "segment_revenue_altera_external": FactSpec("currency", "segment_revenue_altera_external"),
    "segment_revenue_client": FactSpec("currency", "segment_revenue_client"),
    "segment_revenue_client_gaming": FactSpec("currency", "segment_revenue_client_gaming"),
    "segment_revenue_client_legacy": FactSpec("currency", "segment_revenue_client_legacy"),
    "segment_revenue_client_q3": FactSpec("currency", "segment_revenue_client_q3"),
    "segment_revenue_datacenter": FactSpec("currency", "segment_revenue_datacenter"),
    "segment_revenue_datacenter_legacy": FactSpec("currency", "segment_revenue_datacenter_legacy"),
    "segment_revenue_datacenter_q3": FactSpec("currency", "segment_revenue_datacenter_q3"),
    "segment_revenue_eliminations": FactSpec("currency", "segment_revenue_eliminations"),
    "segment_revenue_embedded": FactSpec("currency", "segment_revenue_embedded"),
    "segment_revenue_foundry": FactSpec("currency", "segment_revenue_foundry"),
    "segment_revenue_foundry_external": FactSpec("currency", "segment_revenue_foundry_external"),
    "segment_revenue_foundry_external_q3": FactSpec(
        "currency", "segment_revenue_foundry_external_q3"
    ),
    "segment_revenue_gaming_legacy": FactSpec("currency", "segment_revenue_gaming_legacy"),
    "segment_revenue_ifs_legacy": FactSpec("currency", "segment_revenue_ifs_legacy"),
    "segment_revenue_mobileye_legacy": FactSpec("currency", "segment_revenue_mobileye_legacy"),
    "segment_revenue_network_legacy": FactSpec("currency", "segment_revenue_network_legacy"),
    "segment_revenue_other": FactSpec("currency", "segment_revenue_other"),
    "segment_revenue_other_legacy": FactSpec("currency", "segment_revenue_other_legacy"),
    "semiconductor_sales_usd": FactSpec("currency", "semiconductor_sales_usd"),
    "server_asp_growth": FactSpec("decimal_ratio", "server_asp_growth"),
    "server_asp_growth_q3": FactSpec("decimal_ratio", "server_asp_growth_q3"),
    "server_unit_growth": FactSpec("decimal_ratio", "server_unit_growth"),
    "shares_outstanding": FactSpec("count", "期末发行在外普通股，百万股"),
    "short_investments": FactSpec("currency", "short_investments"),
    "trading_volume": FactSpec("count", "交易量，百万股；行情商之间有口径差异"),
    "wafer_shipments_q3": FactSpec("count", "wafer_shipments_q3"),
}

# Additional observed disclosures; forecasts retain their stated outlook scope.
FACTS.update(
    {
        "acquisition_amortization": FactSpec(
            "currency", "Cash flow six months amortization of acquisition-related intangibles"
        ),
        "cash_ppe_q3": FactSpec("currency", "FY27Q1 call cash paid for PP&E, single quarter"),
        "depreciation": FactSpec(
            "currency", "Cash flow nine months depreciation; excludes intangible amortization659"
        ),
        "depreciation_amortization_ex_acquisition": FactSpec(
            "currency",
            "Cash flow six months depreciation and amortization427; acquisition intangible amortization1095 separate",
        ),
        "disclosed_capex_outlook": FactSpec(
            "currency", "2026 cash capex outlook, not actual or all server spend"
        ),
        "disclosed_capex_outlook_high": FactSpec(
            "currency", "2026 guidance including lease principal, not realized"
        ),
        "disclosed_capex_outlook_low": FactSpec(
            "currency", "2026 guidance including lease principal, not realized"
        ),
        "finance_lease_commencement_q3": FactSpec(
            "currency",
            "Lease commencement; do not add again to45200; cash capex+commencement not exact same timing reconciliation",
        ),
        "reported_capital_expenditure_q3": FactSpec(
            "currency",
            "FY27Q1 call capital expenditures; quarterly, includes finance lease commencement; not cash PP&E",
        ),
        "reported_cfo_ttm": FactSpec(
            "currency",
            "Official release visible lines53–60; AWS quarterly, CFO/FCF trailing twelve months as metric names state",
        ),
        "reported_fcf_ttm": FactSpec(
            "currency",
            "Official release visible lines53–60; AWS quarterly, CFO/FCF trailing twelve months as metric names state",
        ),
        "segment_profit_aws_q3": FactSpec(
            "currency",
            "Official release visible lines53–60; AWS quarterly, CFO/FCF trailing twelve months as metric names state",
        ),
        "segment_profit_cloud_q3": FactSpec(
            "currency",
            "Q3 release segment table; cloud includes TPU systems and services, not pure recurring service",
        ),
        "segment_revenue_aws_q3": FactSpec(
            "currency",
            "Official release visible lines53–60; AWS quarterly, CFO/FCF trailing twelve months as metric names state",
        ),
        "segment_revenue_cloud_q3": FactSpec(
            "currency",
            "Q3 release segment table; cloud includes TPU systems and services, not pure recurring service",
        ),
    }
)
