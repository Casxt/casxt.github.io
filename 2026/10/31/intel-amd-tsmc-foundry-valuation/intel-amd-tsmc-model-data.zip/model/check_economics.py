"""Check material economic invariants without changing facts or parameters."""

import math
from pathlib import Path

import polars as pl
from study import ISSUERS, STUDY
from views import deep

from mid_term_capital.view_engine.result_schema import read_result


def main():
    root = Path(__file__).resolve().parents[1]
    scenarios = [
        "bear",
        "base",
        "bull",
        "server_plateau",
        "server_downturn",
        "cycle_early",
        "cycle_late",
        "capital_disruption",
    ]
    for s in scenarios:
        p = read_result(root / "results" / s / "capital_recovery.csv")
        v = read_result(root / "results" / s / "valuation.csv")
        b = read_result(root / "results" / s / "buy_prices.csv")
        assert p.height == 33 and v.height == 165 and b.height == 165
        assert p.select(pl.all_horizontal(pl.col(deep.NUMBERS).is_finite()).all()).item()
        assert p.filter((pl.col("cash") < 0) | (pl.col("shares") <= 0)).is_empty()
        assert b.filter(
            (pl.col("buy_20") > pl.col("buy_15") + 1e-8)
            | (pl.col("buy_15") > pl.col("buy_11") + 1e-8)
        ).is_empty()
        assert (
            p["revenue"]
            - p["client_revenue"]
            - p["server_revenue"]
            - p["other_revenue"]
            - p["external_revenue"]
        ).abs().max() < 1e-5
    plateau = read_result(root / "results/server_plateau/capital_recovery.csv")
    down = read_result(root / "results/server_downturn/capital_recovery.csv")
    for e in [ISSUERS["intel"], ISSUERS["amd"]]:
        a = plateau.filter((pl.col("entity_id") == e) & (pl.col("year") == 2028)).row(0, named=True)
        b = down.filter((pl.col("entity_id") == e) & (pl.col("year") == 2028)).row(0, named=True)
        assert math.isclose(a["client_revenue"], b["client_revenue"])
        assert b["server_revenue"] < a["server_revenue"] and b["client_share"] > a["client_share"]
        assert b["operating_profit"] < a["operating_profit"]
    amounts = STUDY.fact_frame("amounts")
    counts = STUDY.fact_frame("counts")
    prices = STUDY.fact_frame("per_unit")
    param_view, projection = deep.ISSUER["intel"]
    pars = param_view.func([])
    base = projection.func([amounts, counts, prices, pars])
    shock = pars.with_columns(
        pl.when(pl.col("year") == 2027)
        .then(pl.col("capex") * 1.2)
        .otherwise(pl.col("capex"))
        .alias("capex")
    )
    stressed = projection.func([amounts, counts, prices, shock])
    select = lambda f, y: f.filter(pl.col("year") == y).row(0, named=True)
    assert select(stressed, 2027)["cash"] < select(base, 2027)["cash"]
    assert select(stressed, 2028)["depreciation"] > select(base, 2028)["depreciation"]
    assert select(stressed, 2028)["operating_profit"] < select(base, 2028)["operating_profit"]
    # Existing terminal cash should enter equity DCF exactly once.
    records = list(base.iter_rows(named=True))
    parameters = list(pars.iter_rows(named=True))
    original = deep.method_values(records, parameters, 2031, "intel")[0]["DCF_steady"]
    changed = [dict(r) for r in records]
    changed[-1]["cash"] += 1000
    revised = deep.method_values(changed, parameters, 2031, "intel")[0]["DCF_steady"]
    from datetime import date

    expected = (
        1000
        / records[-1]["shares"]
        / 1.11 ** ((date(2036, 12, 31) - date(2031, 12, 31)).days / 365.25)
    )
    assert math.isclose(revised - original, expected, rel_tol=1e-8)
    # Force loss of funding access: show a shortfall rather than invent unlimited loans.
    no_funding = pars.with_columns(
        pl.lit(0.0).alias("debt_limit"),
        pl.lit(0.0).alias("max_equity_fraction"),
        (pl.col("capex") * 4).alias("capex"),
    )
    broken = projection.func([amounts, counts, prices, no_funding])
    assert broken["cumulative_gap"].max() > 0
    assert (
        deep.method_values(
            list(broken.iter_rows(named=True)),
            list(no_funding.iter_rows(named=True)),
            2031,
            "intel",
        )[0]["Fusion"]
        is None
    )
    print(
        "PASS: 8 scenarios, 33 issuer-years each, 165 method-year rows each; cyclicality, capex lag, one-time cash valuation and funding limits."
    )


if __name__ == "__main__":
    main()
