"""Reading and validating the fact layer, the parameter layer and the run config.

The engine never imports a research directory; a research root calls
:func:`bind` once with its metric registry and its fact-file map, and views ask
the returned :class:`Research` object for data.

Everything here is lazy: nothing is read until a view first asks for it. All
sources of failure are checked at read time -- schema, primary keys, registered
metric ids, value bounds, entity references, source references, parameter keys.
"""

import importlib
import importlib.util
import sys
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Iterable, Mapping, Sequence

import polars as pl

from mid_term_capital.view_engine import units
from mid_term_capital.view_engine.csvio import read_csv_exact

PERIOD_TYPE = pl.Enum(["Q1", "H1", "Q3", "FY", "AS_OF"])

#: The seven columns every fact file must have, and nothing else.
FACT_SCHEMA: dict[str, pl.DataType] = {
    "entity_id": pl.String,
    "metric_id": pl.String,
    "period_end": pl.Date,
    "period_type": PERIOD_TYPE,
    "value": pl.Float64,
    "source_ids": pl.String,
    "source_locator": pl.String,
}
FACT_KEY = ["entity_id", "metric_id", "period_end", "period_type"]

ENTITY_TYPE = pl.Enum(["issuer", "security", "industry"])

ENTITY_SCHEMA: dict[str, pl.DataType] = {
    "entity_id": pl.String,
    "name": pl.String,
    "entity_type": ENTITY_TYPE,
    "parent_entity_id": pl.String,
    "currency": pl.String,
    "fiscal_year_end": pl.String,
}

SOURCE_SCHEMA: dict[str, pl.DataType] = {
    "source_id": pl.String,
    "source_type": pl.String,
    "title": pl.String,
    "publisher": pl.String,
    "published_date": pl.Date,
    "url": pl.String,
    "file_path": pl.String,
    "file_sha256": pl.String,
    "acquired_date": pl.Date,
}

GAP_SCHEMA: dict[str, pl.DataType] = {
    "entity_id": pl.String,
    "metric_id": pl.String,
    "period_start": pl.Date,
    "period_end": pl.Date,
    "reason": pl.String,
}

PARAM_META_SCHEMA: dict[str, pl.DataType] = {
    "param_id": pl.String,
    "name": pl.String,
    "unit": pl.String,
    "lower_bound": pl.Float64,
    "upper_bound": pl.Float64,
}

PARAMETERS_SCHEMA: dict[str, pl.DataType] = {
    "entity_id": pl.String,
    "param_id": pl.String,
    "period": pl.String,
    "scenario": pl.String,
    "value": pl.Float64,
}
PARAMETERS_KEY = ["entity_id", "param_id", "period", "scenario"]

SCENARIOS_SCHEMA: dict[str, pl.DataType] = {
    "scenario_id": pl.String,
    "param_id": pl.String,
    "scenario": pl.String,
}

RUN_SCHEMA: dict[str, pl.DataType] = {
    "key": pl.String,
    "value": pl.String,
}

#: Resolution order from 《企业分析计算规范》 3.5: exact entity beats ALL, exact
#: period beats ALL, and the entity dimension is compared before the period one.
PARAM_LOOKUP_ORDER = [
    ("exact", "exact"),
    ("exact", "ALL"),
    ("ALL", "exact"),
    ("ALL", "ALL"),
]


class MissingParameter(KeyError):
    """Raised with the complete list of keys that could not be resolved."""

    def __init__(self, missing: Sequence[tuple[str, str, str, str]]):
        self.missing = list(missing)
        detail = ", ".join(
            f"{entity}/{param}/{period}@{scenario}"
            for entity, param, period, scenario in self.missing
        )
        super().__init__(f"{len(self.missing)} parameter key(s) unresolved: {detail}")


@dataclass(frozen=True)
class FactSpec:
    """What a ``metric_id`` means: its unit and a one-line scope note.

    No value range. A hand-written plausibility bound is a number nobody can
    justify, and when it fires it either blocks a legitimate disclosure or gets
    loosened until it catches nothing. Whether a number is possible is a
    question about the business, so it belongs in a view that can be reviewed
    -- an item compared with the entity's own revenue or assets -- not in a
    constant in the loader.
    """

    unit: str
    desc: str

    def __post_init__(self) -> None:
        if not self.desc:
            raise ValueError("metric needs a description")


def _read_csv(path: Path, schema: Mapping[str, pl.DataType], what: str) -> pl.DataFrame:
    """Read one declared table. The header and the error labelling live in csvio."""
    return read_csv_exact(path, schema, what)


def _assert_unique_keys(frame: pl.DataFrame, key: Sequence[str], what: str) -> None:
    nulls = frame.select(key).null_count().sum_horizontal().item()
    if nulls:
        bad = frame.filter(pl.any_horizontal([pl.col(c).is_null() for c in key]))
        raise ValueError(f"{what}: {nulls} null value(s) in primary key {key}\n{bad.head(5)}")
    duplicated = frame.filter(pl.struct(key).is_duplicated())
    if not duplicated.is_empty():
        raise ValueError(
            f"{what}: primary key {key} duplicated on "
            f"{duplicated.select(key).head(5).to_dicts()}"
        )


def read_facts(
    path: Path,
    facts: Mapping[str, FactSpec],
    what: str | None = None,
    unit: str | None = None,
) -> pl.DataFrame:
    """Read one fact file and run every fact-layer check from the spec.

    ``unit`` is the file's single unit. A fact file holds one kind of quantity,
    so its ``value`` column has one truthful unit and can be declared as a
    ``Field``. A metric whose registry unit disagrees with the file is an error,
    not a silent mixture: a column that carries both money and ratios has no
    honest unit at all.
    """
    label = what or path.name
    frame = _read_csv(path, FACT_SCHEMA, label)
    _assert_unique_keys(frame, FACT_KEY, label)

    unregistered = sorted(
        set(frame["metric_id"].unique().to_list()) - set(facts)
    )
    if unregistered:
        raise ValueError(f"{label}: unregistered metric_id(s) {unregistered}")

    if unit is not None:
        mismatched = sorted(
            metric for metric in set(frame["metric_id"].unique().to_list())
            if facts[metric].unit != unit
        )
        if mismatched:
            raise ValueError(
                f"{label}: file is declared unit {unit!r} but these metrics carry "
                f"another unit: "
                f"{[(m, facts[m].unit) for m in mismatched]}"
            )

    missing_source = frame.filter(
        pl.col("value").is_not_null() & pl.col("source_ids").is_null()
    )
    if not missing_source.is_empty():
        raise ValueError(
            f"{label}: {missing_source.height} row(s) have a value but no source_ids: "
            f"{missing_source.select(FACT_KEY).head(5).to_dicts()}"
        )
    stray_source = frame.filter(
        pl.col("value").is_null() & pl.col("source_ids").is_not_null()
    )
    if not stray_source.is_empty():
        raise ValueError(
            f"{label}: {stray_source.height} row(s) have no value but source ids; "
            f"a missing observation must leave the source columns empty: "
            f"{stray_source.select(FACT_KEY).head(5).to_dicts()}"
        )

    return frame


def read_entity_meta(path: Path) -> pl.DataFrame:
    frame = _read_csv(path, ENTITY_SCHEMA, "entity_meta")
    _assert_unique_keys(frame, ["entity_id"], "entity_meta")

    prefixes = frame["entity_id"].str.split(":").list.first()
    mismatched = frame.filter(prefixes != pl.col("entity_type").cast(pl.String))
    if not mismatched.is_empty():
        raise ValueError(
            "entity_meta: entity_id prefix does not match entity_type on "
            f"{mismatched.select('entity_id', 'entity_type').to_dicts()}"
        )

    ids = set(frame["entity_id"].to_list())
    parents = frame.filter(pl.col("entity_type") == "security")["parent_entity_id"]
    if parents.null_count():
        raise ValueError("entity_meta: every security needs a parent_entity_id")
    unknown = sorted(set(parents.to_list()) - ids)
    if unknown:
        raise ValueError(f"entity_meta: security parent(s) not declared: {unknown}")

    wrong_kind = frame.filter(
        (pl.col("entity_type") == "security")
        & (pl.col("parent_entity_id").str.split(":").list.first() != "issuer")
    )
    if not wrong_kind.is_empty():
        raise ValueError(
            "entity_meta: a security may only point at an issuer, got "
            f"{wrong_kind.select('entity_id', 'parent_entity_id').to_dicts()}"
        )

    non_security = frame.filter(
        (pl.col("entity_type") != "security") & pl.col("parent_entity_id").is_not_null()
    )
    if not non_security.is_empty():
        raise ValueError(
            "entity_meta: only security rows may carry a parent, got "
            f"{non_security.select('entity_id').to_dicts()}"
        )
    return frame


def read_sources(path: Path) -> pl.DataFrame:
    frame = _read_csv(path, SOURCE_SCHEMA, "sources")
    _assert_unique_keys(frame, ["source_id"], "sources")
    return frame


def read_data_gaps(path: Path) -> pl.DataFrame:
    frame = _read_csv(path, GAP_SCHEMA, "data_gaps")
    _assert_unique_keys(frame, ["entity_id", "metric_id", "period_start"], "data_gaps")
    return frame


class Parameters:
    """The three parameter tables plus the run config, resolved on demand."""

    def __init__(
        self,
        meta: pl.DataFrame,
        values: pl.DataFrame,
        scenarios: pl.DataFrame,
        run: pl.DataFrame,
    ) -> None:
        self.meta = meta
        self.values = values
        self.scenarios = scenarios
        self.run = run
        self._validate()

        self._specs = {row["param_id"]: row for row in meta.to_dicts()}
        self._by_key = {
            (row["param_id"], row["entity_id"], row["period"], row["scenario"]): row["value"]
            for row in values.to_dicts()
        }
        self._band_override = {
            (row["scenario_id"], row["param_id"]): row["scenario"]
            for row in scenarios.to_dicts()
            if row["param_id"] != "*"
        }
        self._band_default = {
            row["scenario_id"]: row["scenario"]
            for row in scenarios.to_dicts()
            if row["param_id"] == "*"
        }
        self._run = {row["key"]: row["value"] for row in run.to_dicts()}

    def _validate(self) -> None:
        _assert_unique_keys(self.meta, ["param_id"], "parameter_meta")
        _assert_unique_keys(self.values, PARAMETERS_KEY, "parameters")
        _assert_unique_keys(self.scenarios, ["scenario_id", "param_id"], "scenarios")
        _assert_unique_keys(self.run, ["key"], "run")

        known = set(self.meta["param_id"].to_list())
        unknown = sorted(set(self.values["param_id"].to_list()) - known)
        if unknown:
            raise ValueError(f"parameters: param_id not in parameter_meta: {unknown}")

        spec = {
            row["param_id"]: (row["lower_bound"], row["upper_bound"])
            for row in self.meta.to_dicts()
        }
        missing_bounds = sorted(
            param_id
            for param_id, (low, high) in spec.items()
            if low is None or high is None
        )
        if missing_bounds:
            raise ValueError(
                "parameter_meta: every parameter needs both lower_bound and "
                f"upper_bound (规范 3.3); missing for {missing_bounds}"
            )

        for row in self.values.to_dicts():
            low, high = spec[row["param_id"]]
            if low is not None and row["value"] < low:
                raise ValueError(
                    f"parameters: {row['param_id']} = {row['value']} below lower_bound "
                    f"{low} at {row['entity_id']}/{row['period']}/{row['scenario']}"
                )
            if high is not None and row["value"] > high:
                raise ValueError(
                    f"parameters: {row['param_id']} = {row['value']} above upper_bound "
                    f"{high} at {row['entity_id']}/{row['period']}/{row['scenario']}"
                )

        defaults = set(self.scenarios.filter(pl.col("param_id") == "*")["scenario_id"].to_list())
        named = set(self.scenarios["scenario_id"].to_list())
        without_default = sorted(named - defaults)
        if without_default:
            raise ValueError(
                f"scenarios: no explicit '*' default band for {without_default}"
            )

        bands = set(self.scenarios["scenario"].to_list())
        used = set(self.values["scenario"].to_list())
        orphan = sorted(used - bands)
        if orphan:
            raise ValueError(
                f"parameters: value band(s) {orphan} are never mapped by scenarios.csv"
            )

        overrides = set(
            self.scenarios.filter(pl.col("param_id") != "*")["param_id"].to_list()
        )
        unknown_override = sorted(overrides - known)
        if unknown_override:
            raise ValueError(
                f"scenarios: override for unknown param_id {unknown_override}"
            )
        if "valuation_date" not in self._run_raw_keys():
            raise ValueError("run.csv: missing required key 'valuation_date'")

        run_map = {row["key"]: row["value"] for row in self.run.to_dicts()}
        if "scenario_id" not in run_map:
            raise ValueError("run.csv: missing required key 'scenario_id'")
        declared = set(self.scenarios["scenario_id"].to_list())
        if run_map["scenario_id"] not in declared:
            raise ValueError(
                f"run.csv: scenario_id {run_map['scenario_id']!r} is not declared in "
                f"scenarios.csv; declared: {sorted(declared)}"
            )

    def _run_raw_keys(self) -> set[str]:
        return set(self.run["key"].to_list())

    # -- lookups ----------------------------------------------------------

    @property
    def scenario_ids(self) -> list[str]:
        return sorted(self._band_default)

    @property
    def scenario_id(self) -> str:
        """The one scenario this run computes, from ``run.csv``."""
        return self._run["scenario_id"]

    @property
    def results_subdir(self) -> str:
        """Results subdirectory for this run; defaults to the scenario id."""
        return self._run.get("results_dir", self._run["scenario_id"])

    @property
    def valuation_date(self) -> date:
        raw = self._run["valuation_date"]
        return date.fromisoformat(raw)

    def run_value(self, key: str) -> str:
        try:
            return self._run[key]
        except KeyError:
            raise KeyError(
                f"run.csv has no key {key!r}; present: {sorted(self._run)}"
            ) from None

    def spec(self, param_id: str) -> dict:
        try:
            return self._specs[param_id]
        except KeyError:
            raise KeyError(
                f"parameter_meta has no param_id {param_id!r}; "
                f"present: {sorted(self._specs)}"
            ) from None

    def band(self, scenario_id: str, param_id: str) -> str:
        """The value band a parameter takes in a named scenario."""
        override = self._band_override.get((scenario_id, param_id))
        if override is not None:
            return override
        default = self._band_default.get(scenario_id)
        if default is None:
            raise KeyError(
                f"scenarios.csv has no scenario_id {scenario_id!r}; "
                f"present: {sorted(self._band_default)}"
            )
        return default

    def resolve(
        self, entity_id: str, param_id: str, period: str, scenario_id: str
    ) -> float:
        """One parameter value, applying the documented fallback order."""
        band = self.band(scenario_id, param_id)
        for entity_step, period_step in PARAM_LOOKUP_ORDER:
            entity_key = entity_id if entity_step == "exact" else "ALL"
            period_key = period if period_step == "exact" else "ALL"
            value = self._by_key.get((param_id, entity_key, period_key, band))
            if value is not None:
                return value
        raise MissingParameter([(entity_id, param_id, period, scenario_id)])

    def try_resolve(
        self, entity_id: str, param_id: str, period: str, scenario_id: str
    ) -> float | None:
        """Like :meth:`resolve` but None when the keys simply do not resolve.

        Used where a caller enumerates a whole grid and expects most parameter
        and period combinations not to apply. An unknown ``scenario_id`` is a
        configuration error rather than a miss, so it still raises.
        """
        try:
            return self.resolve(entity_id, param_id, period, scenario_id)
        except MissingParameter:
            return None

    def constant(self, param_id: str) -> float:
        """The single value of a study-wide parameter, under ``entity_id = ALL``.

        Used for numbers that describe the study itself rather than an entity --
        how many years to project, for instance. The parameter table still
        carries one row per scenario, because that is how bands work even when
        they are equal; this asserts they really are equal, so a study-wide
        constant cannot quietly become scenario-dependent.
        """
        rows = self.values.filter(
            (pl.col("param_id") == param_id) & (pl.col("entity_id") == "ALL")
        )
        if rows.is_empty():
            raise KeyError(
                f"parameter_meta has no study-wide {param_id!r} under entity ALL; "
                f"present for ALL: "
                f"{sorted(set(self.values.filter(pl.col('entity_id') == 'ALL')['param_id'].to_list()))}"
            )
        distinct = rows["value"].unique().to_list()
        if len(distinct) != 1:
            raise ValueError(
                f"{param_id!r} is meant to be study-wide but takes several values "
                f"across periods or scenarios: {sorted(distinct)}"
            )
        return distinct[0]

    def series(
        self,
        entity_id: str,
        param_id: str,
        periods: Iterable[str],
        scenario_id: str,
    ) -> dict[str, float]:
        """A whole period sequence, failing once with every missing key listed."""
        out: dict[str, float] = {}
        missing: list[tuple[str, str, str, str]] = []
        for period in periods:
            try:
                out[period] = self.resolve(entity_id, param_id, period, scenario_id)
            except MissingParameter:
                missing.append((entity_id, param_id, period, scenario_id))
        if missing:
            raise MissingParameter(missing)
        return out

    def band_table(self, scenario_id: str) -> pl.DataFrame:
        """``param_id -> band`` for one named scenario, defaults filled in.

        A single ``map`` from parameter to value band, so callers never repeat
        the two-step lookup. ``param_id`` becomes the ``scenario`` column name on
        the parameter table; here it is called ``band`` to keep the two apart.
        """
        rows = self.scenarios.filter(pl.col("scenario_id") == scenario_id)
        if rows.is_empty():
            raise KeyError(
                f"scenarios.csv has no scenario_id {scenario_id!r}; "
                f"present: {sorted(self._band_default)}"
            )
        default = rows.filter(pl.col("param_id") == "*")["scenario"]
        if default.is_empty():
            raise ValueError(
                f"scenarios: scenario_id {scenario_id!r} has no explicit '*' default"
            )
        overrides = rows.filter(pl.col("param_id") != "*").select(
            "param_id", pl.col("scenario").alias("band")
        )
        return (
            self.meta.select("param_id")
            .join(overrides, on="param_id", how="left")
            .with_columns(pl.col("band").fill_null(default[0]))
        )

    def wide(self, scenario_id: str) -> pl.DataFrame:
        """Human-readable long-to-wide view of the parameter set."""
        banded = self.values.join(
            self.band_table(scenario_id), left_on=["param_id", "scenario"], right_on=["param_id", "band"], how="inner"
        )
        wide = banded.pivot(
            on="scenario", index=["entity_id", "param_id", "period"], values="value"
        )
        return wide.join(
            self.meta.select("param_id", "name", "unit"), on="param_id", how="left"
        ).sort(["param_id", "entity_id", "period"])


class Research:
    """One research root: its facts, parameters and run config."""

    def __init__(
        self,
        root: Path,
        fact_files: Mapping[str, str],
        facts: Mapping[str, FactSpec],
    ) -> None:
        self.root = Path(root)
        self.fact_files = dict(fact_files)
        self.fact_specs = dict(facts)
        self._frames: dict[str, pl.DataFrame] = {}
        self._entity_meta: pl.DataFrame | None = None
        self._sources: pl.DataFrame | None = None
        self._data_gaps: pl.DataFrame | None = None
        self._params: Parameters | None = None

    # -- paths ------------------------------------------------------------

    @property
    def facts_dir(self) -> Path:
        return self.root / "facts"

    @property
    def params_dir(self) -> Path:
        return self.root / "params"

    @property
    def run_results_dir(self) -> Path:
        """Where this run writes: ``results/<情景子目录>/``."""
        return self.results_dir / self.params.results_subdir

    @property
    def results_dir(self) -> Path:
        return self.root / "results"

    # -- fact layer -------------------------------------------------------

    def fact_frame(self, name: str) -> pl.DataFrame:
        if name not in self._frames:
            if name not in self.fact_files:
                raise KeyError(
                    f"unknown fact file {name!r}; declared: {sorted(self.fact_files)}"
                )
            declared = self.fact_files[name]
            path, unit = (declared if isinstance(declared, tuple) else (declared, None))
            self._frames[name] = read_facts(
                self.root / path, self.fact_specs, what=name, unit=unit
            )
        return self._frames[name]

    def all_facts(self) -> pl.DataFrame:
        """Every fact file stacked, tagged with the file it came from."""
        frames = [
            self.fact_frame(name).with_columns(pl.lit(name).alias("fact_file"))
            for name in sorted(self.fact_files)
        ]
        if not frames:
            raise ValueError(f"{self.root}: no fact files declared")
        return pl.concat(frames, how="vertical")

    @property
    def entity_meta(self) -> pl.DataFrame:
        if self._entity_meta is None:
            self._entity_meta = read_entity_meta(self.facts_dir / "entity_meta.csv")
            declared = set(self._entity_meta["entity_id"].to_list())
            used = set(
                self.all_facts()["entity_id"].unique().to_list()
            ) - {None}
            orphan = sorted(used - declared)
            if orphan:
                raise ValueError(
                    f"facts reference entities missing from entity_meta.csv: {orphan}"
                )
        return self._entity_meta

    @property
    def sources(self) -> pl.DataFrame:
        if self._sources is None:
            self._sources = read_sources(self.facts_dir / "sources.csv")
            used = {
                part
                for field in self.all_facts()["source_ids"].drop_nulls().to_list()
                for part in split_source_ids(field)
            }
            known = set(self._sources["source_id"].to_list())
            unknown = sorted(used - known)
            if unknown:
                raise ValueError(
                    f"facts reference source id(s) missing from sources.csv: {unknown}"
                )
        return self._sources

    @property
    def data_gaps(self) -> pl.DataFrame:
        if self._data_gaps is None:
            self._data_gaps = read_data_gaps(self.facts_dir / "data_gaps.csv")
        return self._data_gaps

    # -- parameter layer --------------------------------------------------

    @property
    def params(self) -> Parameters:
        if self._params is None:
            self._params = Parameters(
                _read_csv(self.params_dir / "parameter_meta.csv", PARAM_META_SCHEMA, "parameter_meta"),
                _read_csv(self.params_dir / "parameters.csv", PARAMETERS_SCHEMA, "parameters"),
                _read_csv(self.params_dir / "scenarios.csv", SCENARIOS_SCHEMA, "scenarios"),
                _read_csv(self.params_dir / "run.csv", RUN_SCHEMA, "run"),
            )
        return self._params

    # -- entities ---------------------------------------------------------

    def entities(self, entity_type: str) -> list[str]:
        frame = self.entity_meta.filter(pl.col("entity_type") == entity_type)
        return sorted(frame["entity_id"].to_list())

    def entity_row(self, entity_id: str) -> dict:
        frame = self.entity_meta.filter(pl.col("entity_id") == entity_id)
        if frame.is_empty():
            raise KeyError(f"entity_meta has no {entity_id!r}")
        return frame.to_dicts()[0]

    def parent_of(self, entity_id: str) -> str:
        row = self.entity_row(entity_id)
        if row["entity_type"] != "security":
            raise ValueError(f"{entity_id!r} is not a security, it has no parent")
        return row["parent_entity_id"]

    def model_dir(self) -> Path:
        """The directory holding this root's ``model/`` package."""
        return self.root / "model"

    def securities_of(self, issuer_id: str) -> list[str]:
        frame = self.entity_meta.filter(pl.col("parent_entity_id") == issuer_id)
        return sorted(frame["entity_id"].to_list())


def import_study(target: str):
    """Import a study module by dotted name or by path to its ``.py`` file.

    A study's ``model/`` directory has to be on ``sys.path`` for the module's own
    ``from study import STUDY`` and ``from views...`` imports to resolve, and it
    is not on ``sys.path`` merely because the repository root is. Accepting a
    path removes the need for the caller to set ``PYTHONPATH``.
    """
    if "/" in target or target.endswith(".py"):
        path = Path(target).resolve()
        if not path.exists():
            raise FileNotFoundError(f"study module not found: {path}")
        directory = str(path.parent)
        if directory not in sys.path:
            sys.path.insert(0, directory)
        spec = importlib.util.spec_from_file_location(path.stem, path)
        if spec is None or spec.loader is None:
            raise ImportError(f"cannot load a module from {path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules.setdefault(path.stem, module)
        spec.loader.exec_module(module)
        return module
    return importlib.import_module(target)


def split_source_ids(field: str) -> list[str]:
    """The source ids cited by one fact row.

    A row may rest on more than one document, so the column is a
    semicolon-separated list rather than a single id.
    """
    return [part.strip() for part in field.split(";") if part.strip()]


_BOUND: dict[Path, Research] = {}


def bind(
    root: str | Path,
    fact_files: Mapping[str, str],
    facts: Mapping[str, FactSpec],
) -> Research:
    """Bind a research root, returning the same object for the same root path."""
    resolved = Path(root).resolve()
    existing = _BOUND.get(resolved)
    if existing is not None:
        return existing
    research = Research(resolved, fact_files, facts)
    _BOUND[resolved] = research
    return research
