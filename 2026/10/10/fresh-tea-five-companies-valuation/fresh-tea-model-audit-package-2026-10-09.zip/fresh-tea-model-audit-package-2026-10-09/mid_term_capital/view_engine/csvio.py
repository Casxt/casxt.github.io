"""Reading a CSV against an exactly declared schema.

Both the fact loader and the result reader need this, and both need the same
two defences, so it lives in one place rather than being reimplemented:

1. **The header is checked by name, first.** ``pl.read_csv(schema=...)`` matches
   columns *by position*. If the file is missing (or has renamed) a column, the
   values to its right shift left and are silently retyped, and the schema the
   reader gets back is the one it asked for -- so a post-read comparison cannot
   detect it. Only reading the header itself can.
2. **Errors name the file.** A bare polars ``ComputeError`` does not say which
   of a dozen CSV files failed.
"""

import csv
from pathlib import Path
from typing import Mapping

import polars as pl

NULL_VALUES = ["", "NA", "N/A", "null"]


def read_csv_exact(
    path: Path, schema: Mapping[str, pl.DataType], what: str
) -> pl.DataFrame:
    """Read ``path`` against ``schema`` or fail naming the file and the columns."""
    if not path.exists():
        raise FileNotFoundError(f"{what}: {path} does not exist")
    try:
        # The stdlib reader, not polars: reading zero rows still makes polars
        # infer dtypes, which fails on a column that mixes "2026" and "ALL".
        with path.open(newline="", encoding="utf-8-sig") as handle:
            header = next(csv.reader(handle))
    except Exception as error:
        raise ValueError(
            f"{what}: cannot read the header of {path}: "
            f"{type(error).__name__}: {error}"
        ) from error

    declared = list(schema)
    if header != declared:
        missing = [column for column in declared if column not in header]
        extra = [column for column in header if column not in schema]
        raise ValueError(
            f"{what}: {path} columns do not match the declared schema; "
            f"missing {missing}, unexpected {extra}, in file order {header}"
        )

    try:
        frame = pl.read_csv(path, schema=dict(schema), null_values=NULL_VALUES)
    except Exception as error:
        raise ValueError(
            f"{what}: cannot read {path}: {type(error).__name__}: {error}"
        ) from error

    if frame.schema != dict(schema) or list(frame.columns) != declared:
        raise ValueError(
            f"{what}: schema mismatch after reading {path}\n"
            f"  declared {dict(schema)}\n  got {frame.schema}"
        )
    return frame
