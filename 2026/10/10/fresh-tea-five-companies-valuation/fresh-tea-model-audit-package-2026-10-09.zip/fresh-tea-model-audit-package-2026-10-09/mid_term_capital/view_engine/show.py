"""Field master table, keyword search and read-only view inspection.

``show.py`` is the replacement for a global field registry: it prints every
declared field of every registered view, can filter that table by keyword, can
show one view's declared schema, lineage and inputs, and can print the parameter
layer as a wide table. It never computes a view and never writes a file. When a
view happens to have been computed earlier in the same process, its frames are
printed as they are; otherwise the tool says so and stops.
"""

import argparse
import sys
import unicodedata
from collections.abc import Mapping, Sequence
from typing import Any

import polars as pl

from mid_term_capital.view_engine import loader
from mid_term_capital.view_engine.view import (
    DEFAULT_REGISTRY,
    Field,
    Registry,
    ViewInstance,
)

DEFAULT_ROW_LIMIT = 40
DEFAULT_SCENARIO = "base"
PARAMS_TARGET = "params"
STUDY_ATTRIBUTE = "STUDY"
MAX_CELL_CHARS = 200


def _display_width(text: str) -> int:
    """Terminal columns a string occupies, counting wide East Asian glyphs twice."""
    return sum(
        2 if unicodedata.east_asian_width(character) in ("W", "F") else 1
        for character in text
    )


def render_field_table(fields: Mapping[str, Field]) -> str:
    """Render an aligned, Markdown-compatible ``column | dtype | unit | desc`` table."""
    headers = ("column", "dtype", "unit", "desc")
    rows = [
        (column, str(field.dtype), field.unit if field.unit else "-", field.desc)
        for column, field in fields.items()
    ]
    widths = [_display_width(header) for header in headers]
    for row in rows:
        for index, value in enumerate(row):
            widths[index] = max(widths[index], _display_width(value))

    def pad(value: str, width: int) -> str:
        return value + " " * (width - _display_width(value))

    def format_row(values: Sequence[str]) -> str:
        padded = " | ".join(
            pad(value, widths[index]) for index, value in enumerate(values)
        )
        return f"| {padded} |"

    lines = [
        format_row(headers),
        "| " + " | ".join("-" * width for width in widths) + " |",
    ]
    lines.extend(format_row(row) for row in rows)
    return "\n".join(lines)


def _first_doc_line(instance: ViewInstance) -> str | None:
    """First non-empty line of a view function's docstring, or None."""
    doc = (instance.__doc__ or "").strip()
    if not doc:
        return None
    return doc.splitlines()[0].strip()


def _matches_keyword(needle: str, column: str, field: Field) -> bool:
    """Whether a column matches a search keyword on name, dtype or description."""
    return (
        needle in column.casefold()
        or needle in str(field.dtype).casefold()
        or needle in field.desc.casefold()
    )


def select_columns(
    registry: Registry, keyword: str | None = None
) -> list[tuple[ViewInstance, list[str]]]:
    """Views to print with their selected columns, sorted by view name.

    Without a keyword every column is selected. With one, a view whose name
    contains the keyword contributes all its columns, and any other view
    contributes only the columns matching on name, dtype or description.
    """
    needle = keyword.casefold() if keyword is not None else None
    selection: list[tuple[ViewInstance, list[str]]] = []
    for name in registry.names():
        instance = registry[name]
        declarations = instance.field_declarations
        if needle is None or needle in name.casefold():
            columns = list(declarations)
        else:
            columns = [
                column
                for column, field in declarations.items()
                if _matches_keyword(needle, column, field)
            ]
        if columns:
            selection.append((instance, columns))
    return selection


def count_columns(selection: Sequence[tuple[ViewInstance, list[str]]]) -> int:
    """Total number of fields in a selection produced by :func:`select_columns`."""
    return sum(len(columns) for _, columns in selection)


def render_master_table(selection: Sequence[tuple[ViewInstance, list[str]]]) -> str:
    """Render the grouped master table for a selection from :func:`select_columns`."""
    blocks: list[str] = []
    for instance, columns in selection:
        declarations = instance.field_declarations
        lines = [f"## {instance.name}"]
        if instance.source:
            lines.append(f"source: {instance.source}")
        doc = _first_doc_line(instance)
        if doc:
            lines.append(doc)
        lines.append("")
        lines.append(
            render_field_table({column: declarations[column] for column in columns})
        )
        blocks.append("\n".join(lines))
    return "\n\n".join(blocks)


def _format_inputs(instance: ViewInstance) -> str:
    """The declared inputs of a view as ``name`` or ``key=name`` text."""
    declared = instance.inputs
    if isinstance(declared, Mapping):
        return ", ".join(f"{key}={value.name}" for key, value in declared.items())
    return ", ".join(upstream.name for upstream in instance.input_list)


def render_view_schema(instance: ViewInstance) -> str:
    """Render one view's field table, declared lineage and declared inputs."""
    lines = [f"## {instance.name}"]
    if instance.source:
        lines.append(f"source: {instance.source}")
    doc = _first_doc_line(instance)
    if doc:
        lines.append(doc)
    inputs = _format_inputs(instance)
    lines.append(f"inputs: {inputs if inputs else '(none)'}")
    lines.append("")
    lines.append(render_field_table(instance.field_declarations))
    lines.append("")
    lines.append("lineage:")
    for column in instance.field_declarations:
        refs = instance.declared_lineage(column)
        if refs is None:
            lines.append(f"  {column} <- (未声明)")
        elif refs:
            upstream = ", ".join(ref.full_name for ref in refs)
            lines.append(f"  {column} <- {upstream}")
        else:
            lines.append(f"  {column} <- (declared, no upstream)")
    return "\n".join(lines)


def format_frame(frame: pl.DataFrame, limit: int | None = None) -> str:
    """Render a frame as text, showing at most ``limit`` rows when one is given."""
    shown = frame if limit is None else frame.head(limit)
    with pl.Config(
        tbl_rows=-1,
        tbl_cols=-1,
        tbl_width_chars=-1,
        fmt_str_lengths=MAX_CELL_CHARS,
    ):
        return str(shown)


def render_view_data(instance: ViewInstance, limit: int = DEFAULT_ROW_LIMIT) -> str:
    """Render a computed view's frame, or explain that it is only declared.

    ``ViewInstance.frame`` raises while a view is uncomputed, so the private
    frame store is checked directly, exactly as ``calculate.py`` does.
    """
    if instance._frame is None:
        return (
            f"{instance.name}: not computed in this process.\n"
            "show.py only inspects registry declarations; run calculate.py first "
            "if you need the data."
        )
    frame = instance._frame
    lines = [f"## {instance.name} [{instance.entity_id}]"]
    lines.append("")
    lines.append(f"rows: {frame.height}")
    if limit is not None and frame.height > limit:
        lines.append(f"showing first {limit} row(s)")
    lines.append(format_frame(frame, limit))
    return "\n".join(lines)


def render_parameters(
    research: loader.Research, scenario_id: str | None = None
) -> str:
    """Render the parameter layer as a wide table for one scenario.

    Defaults to ``base``; when that scenario is absent the first declared
    scenario is used and the fallback is stated in the output.
    """
    parameters = research.params
    available = parameters.scenario_ids
    if not available:
        raise ValueError(f"{research.root}: scenarios.csv declares no scenario")
    requested = scenario_id if scenario_id is not None else DEFAULT_SCENARIO
    chosen = requested
    note: str | None = None
    if chosen not in available:
        if requested != DEFAULT_SCENARIO:
            raise ValueError(
                f"unknown scenario {requested!r}; available: {', '.join(available)}"
            )
        chosen = available[0]
        note = (
            f"scenario {requested!r} not found; using {chosen!r} "
            f"(available: {', '.join(available)})"
        )
    lines = [note] if note else []
    lines.append(f"## {research.root} params --wide ({chosen})")
    lines.append("")
    lines.append(format_frame(parameters.wide(chosen)))
    return "\n".join(lines)


def parse_fact_files(items: Sequence[str]) -> dict[str, str]:
    """Parse repeated ``NAME=PATH`` fact-file declarations into a mapping."""
    mapping: dict[str, str] = {}
    for item in items:
        name, separator, path = item.partition("=")
        if not separator or not name or not path:
            raise ValueError(f"--fact-file expects NAME=PATH, got {item!r}")
        mapping[name] = path
    return mapping


def _import_module(name: str) -> Any:
    """Import a module by name, turning a failed import into a clear error."""
    try:
        return loader.import_study(name)
    except (ImportError, FileNotFoundError) as error:
        raise ValueError(f"cannot import module {name!r}: {error}") from error


def _resolve_research(
    args: argparse.Namespace,
    study_module: Any,
    fact_files: Mapping[str, str],
    parser: argparse.ArgumentParser,
) -> loader.Research:
    """Build the Research object for params mode from ``--research`` or ``--study``."""
    if args.research is not None:
        return loader.bind(args.research, fact_files, {})
    if study_module is None:
        parser.error("params mode needs --study <module> or --research <root>")
    research = getattr(study_module, STUDY_ATTRIBUTE, None)
    if research is None:
        parser.error(
            f"module {args.study!r} has no module-level {STUDY_ATTRIBUTE} attribute"
        )
    if not isinstance(research, loader.Research):
        parser.error(
            f"{args.study}.{STUDY_ATTRIBUTE} must be a loader.Research, "
            f"got {type(research).__name__}"
        )
    return research


def _run_master(registry: Registry) -> int:
    """Print the master table of every declared field."""
    selection = select_columns(registry)
    text = render_master_table(selection)
    if text:
        print(text)
        print("")
    print(f"views: {len(selection)}, fields: {count_columns(selection)}")
    return 0


def _run_search(
    registry: Registry, keyword: str, research: loader.Research | None = None
) -> int:
    """Print matching fields, and matching parameters; exit 1 when nothing matches.

    Parameters are searched too: their Chinese labels live in
    ``parameter_meta.csv`` rather than in any ``Field.desc``, so a field-only
    search would miss the very thing a reader is about to add.
    """
    selection = select_columns(registry, keyword)
    matched = count_columns(selection)
    parameter_rows = search_parameters(research, keyword) if research else []
    if not matched and not parameter_rows:
        print(f"no field or parameter matched {keyword!r}", file=sys.stderr)
        return 1
    if matched:
        print(render_master_table(selection))
        print("")
    if parameter_rows:
        print("## params")
        print("")
        print("| param_id | name | unit | lower_bound | upper_bound |")
        print("| --- | --- | --- | --- | --- |")
        for row in parameter_rows:
            print(
                f"| {row['param_id']} | {row['name']} | {row['unit']} | "
                f"{row['lower_bound']} | {row['upper_bound']} |"
            )
        print("")
    print(
        f"matched: {matched} field(s) in {len(selection)} view(s), "
        f"{len(parameter_rows)} parameter(s)"
    )
    return 0


def search_parameters(
    research: loader.Research, keyword: str
) -> list[dict[str, object]]:
    """Parameter meta rows whose id, label or unit contains the keyword."""
    needle = keyword.casefold()
    rows = []
    for row in research.params.meta.to_dicts():
        haystack = " ".join(
            str(row.get(column, "")) for column in ("param_id", "name", "unit")
        ).casefold()
        if needle in haystack:
            rows.append(row)
    return rows


def _run_view(
    registry: Registry, view_name: str, schema_only: bool, limit: int
) -> int:
    """Print one view's declared schema or its computed frames."""
    if view_name not in registry:
        available = ", ".join(registry.names()) or "(none)"
        print(
            f"error: no view {view_name!r}; registered: {available}",
            file=sys.stderr,
        )
        return 1
    instance = registry[view_name]
    if schema_only:
        print(render_view_schema(instance))
    else:
        print(render_view_data(instance, limit))
    return 0


def build_parser() -> argparse.ArgumentParser:
    """The command-line parser for show.py."""
    parser = argparse.ArgumentParser(
        prog="show.py",
        description=(
            "Inspect the view registry: the field master table, keyword search, "
            "one view's schema or computed data, and the parameter layer."
        ),
    )
    parser.add_argument(
        "target",
        nargs="?",
        default=None,
        metavar="VIEW",
        help="a view name, or 'params' for the parameter layer",
    )
    parser.add_argument(
        "--search",
        default=None,
        metavar="KEYWORD",
        help="filter the master table by keyword (case-insensitive substring)",
    )
    parser.add_argument(
        "--schema",
        action="store_true",
        help="with a view name: print its fields, lineage and inputs",
    )
    parser.add_argument(
        "--wide",
        action="store_true",
        help="with 'params': print the parameter layer as a wide table",
    )
    parser.add_argument(
        "--scenario",
        default=DEFAULT_SCENARIO,
        metavar="ID",
        help=f"parameter scenario for 'params --wide' (default: {DEFAULT_SCENARIO})",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=DEFAULT_ROW_LIMIT,
        metavar="N",
        help=f"max data rows printed for a view (default: {DEFAULT_ROW_LIMIT})",
    )
    parser.add_argument(
        "--study",
        default=None,
        metavar="MODULE",
        help=f"import this module and read its {STUDY_ATTRIBUTE} Research attribute",
    )
    parser.add_argument(
        "--research",
        default=None,
        metavar="ROOT",
        help="research root directory bound without a study module",
    )
    parser.add_argument(
        "--fact-file",
        action="append",
        default=[],
        metavar="NAME=PATH",
        help="fact file for --research, relative to the research root",
    )
    parser.add_argument(
        "--module",
        action="append",
        default=[],
        metavar="MODULE",
        help="extra module to import so its views register",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    """Run the command-line tool; returns the process exit code."""
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        fact_files = parse_fact_files(args.fact_file)
    except ValueError as error:
        parser.error(str(error))
    if args.limit < 1:
        parser.error("--limit must be a positive integer")
    if args.search is not None and args.target is not None:
        parser.error("--search cannot be combined with a view name")
    if args.schema and args.target is None:
        parser.error("--schema needs a view name")
    if args.wide and args.target != PARAMS_TARGET:
        parser.error("--wide is only valid with 'params'")
    if args.target == PARAMS_TARGET and not args.wide:
        parser.error("params mode needs --wide")
    if args.fact_file and args.research is None:
        parser.error("--fact-file needs --research")

    try:
        study_module = _import_module(args.study) if args.study else None
        for module_name in args.module:
            _import_module(module_name)
        registry = DEFAULT_REGISTRY
        if args.search is not None:
            search_research = None
            if args.study is not None or args.research is not None:
                search_research = _resolve_research(
                    args, study_module, fact_files, parser
                )
            return _run_search(registry, args.search, search_research)
        if args.target is None:
            return _run_master(registry)
        if args.target == PARAMS_TARGET:
            research = _resolve_research(args, study_module, fact_files, parser)
            print(render_parameters(research, args.scenario))
            return 0
        return _run_view(registry, args.target, args.schema, args.limit)
    except ValueError as error:
        print(f"error: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
