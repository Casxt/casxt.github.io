"""View instances, field declarations and the registry.

A view is a pure function from polars DataFrames to a polars DataFrame, **bound
to one entity**. The ``@view`` decorator turns the function into a module-level
``ViewInstance`` that declares its name, its entity, its inputs, its output
schema and its field lineage, and registers itself so that ``show.py`` and
``graph.py`` can find it.

One entity per view is what makes the dependency graph mean something. A view
that iterated over a set of entities would have one declared type of upstream
and several actual frames, so nothing in the declaration would say whose profit
it computes, and no edge could be read as "this company's number comes from that
company's filing". Instead the study wraps the same function once per entity:

    def build(entity_id, short):
        @view(name=f"{short}.forecast", entity_id=entity_id, inputs=[...], schema={...})
        def forecast(inp, entity_id):
            ...
        return forecast

    ICBC = build("issuer:工商银行_601398", "工商银行")
    CMB = build("issuer:招商银行_600036", "招商银行")

Two companies, two view instances, one definition. Reuse is reuse of the
function, never of the instance.

This module knows nothing about CSV files or research data; ``loader.py`` does.
"""

import inspect
from contextvars import ContextVar
from dataclasses import dataclass
from typing import Any, Callable, Iterable, Mapping

import polars as pl

UNIT_VOCABULARY = {"decimal_ratio", "currency", "currency_per_unit", "count", "multiple"}
NUMERIC = {pl.Float64, pl.Int64, pl.Int32}

#: ``entity_id`` value for a view that is not about one entity: a fact file, a
#: study-wide parameter table, a cross-entity result table.
ALL = "ALL"

ENTITY_TYPES = {"issuer", "security", "industry"}

# The view whose body is currently executing. ``calculate.py`` sets it around
# each call so that reading another view's frame is checked against ``inputs``.
_CURRENT_VIEW: ContextVar["ViewInstance | None"] = ContextVar("current_view", default=None)


def is_dtype(value: Any) -> bool:
    """True for a polars dtype instance (``pl.Float64()``) or class (``pl.Float64``).

    polars exposes DataType classes built on a ``DataTypeClass`` metaclass, so
    ``isinstance(pl.Float64, pl.DataType)`` is False while ``pl.Float64()`` and
    ``pl.Float64`` compare and hash equal. Declarations may use either form.
    """
    if isinstance(value, pl.DataType):
        return True
    return isinstance(value, type) and issubclass(value, pl.DataType)


def entity_kind(entity_id: str) -> str | None:
    """``issuer`` / ``security`` / ``industry`` / None for ``ALL``."""
    if entity_id == ALL:
        return None
    prefix, separator, _ = entity_id.partition(":")
    if not separator:
        raise ValueError(
            f"entity_id {entity_id!r} must be '<type>:<identifier>' or {ALL!r}"
        )
    if prefix not in ENTITY_TYPES:
        raise ValueError(
            f"entity_id {entity_id!r} has unknown type {prefix!r}; "
            f"expected one of {sorted(ENTITY_TYPES)}"
        )
    return prefix


@dataclass(frozen=True)
class Field:
    """One output column: polars dtype, unit and a one-line scope note."""

    dtype: Any
    unit: str | None = None
    desc: str = ""

    def __post_init__(self) -> None:
        if not is_dtype(self.dtype):
            raise ValueError(f"dtype must be a polars DataType, got {self.dtype!r}")
        if not self.desc:
            raise ValueError(f"field {self.dtype} needs a description")
        if self.dtype in NUMERIC:
            if self.unit not in UNIT_VOCABULARY:
                raise ValueError(
                    f"numeric field needs a unit from {sorted(UNIT_VOCABULARY)}, "
                    f"got {self.unit!r}"
                )
        elif self.unit is not None:
            raise ValueError(
                f"non-numeric field must not declare a unit, got {self.unit!r}"
            )


class Fields:
    """A view's output fields. ``view.fields.revenue`` and ``view.fields["revenue"]`` work."""

    def __init__(self, refs: Mapping[str, "FieldRef"]):
        self._refs = dict(refs)

    def __getattr__(self, name: str) -> "FieldRef":
        if name.startswith("_"):
            raise AttributeError(name)
        try:
            return self._refs[name]
        except KeyError:
            raise AttributeError(
                f"no field {name!r}; available: {sorted(self._refs)}"
            ) from None

    def __getitem__(self, name: str) -> "FieldRef":
        try:
            return self._refs[name]
        except KeyError:
            raise AttributeError(
                f"no field {name!r}; available: {sorted(self._refs)}"
            ) from None

    def __contains__(self, name: object) -> bool:
        return name in self._refs

    def __iter__(self):
        return iter(self._refs)

    def __len__(self) -> int:
        return len(self._refs)

    def items(self):
        return self._refs.items()

    def keys(self):
        return self._refs.keys()

    def values(self):
        return self._refs.values()

    def get(self, name: str, default=None):
        return self._refs.get(name, default)


@dataclass(frozen=True)
class FieldRef:
    """A field together with the view that publishes it."""

    view: "ViewInstance"
    column: str
    field: Field

    @property
    def dtype(self) -> Any:
        return self.field.dtype

    @property
    def unit(self) -> str | None:
        return self.field.unit

    @property
    def desc(self) -> str:
        return self.field.desc

    @property
    def full_name(self) -> str:
        return f"{self.view.name}.{self.column}"

    def __str__(self) -> str:
        return self.full_name


class Registry:
    """``name -> ViewInstance`` lookup, one per research root.

    A research root is a single process, so the module-level default registry is
    the root's registry. Tests build their own to stay isolated.
    """

    def __init__(self) -> None:
        self._views: dict[str, "ViewInstance"] = {}

    def register(self, instance: "ViewInstance") -> None:
        existing = self._views.get(instance.name)
        if existing is not None and existing is not instance:
            raise ValueError(
                f"duplicate view name {instance.name!r}: already registered for "
                f"{existing.entity_id} by "
                f"{existing.func.__module__}.{existing.func.__qualname__}, "
                f"again for {instance.entity_id} by "
                f"{instance.func.__module__}.{instance.func.__qualname__}"
            )
        self._views[instance.name] = instance

    def __getitem__(self, name: str) -> "ViewInstance":
        try:
            return self._views[name]
        except KeyError:
            raise KeyError(
                f"no view {name!r}; registered: {sorted(self._views)}"
            ) from None

    def __contains__(self, name: object) -> bool:
        return name in self._views

    def __iter__(self):
        return iter(self._views.values())

    def names(self) -> list[str]:
        return sorted(self._views)

    def by_entity(self, entity_id: str) -> list["ViewInstance"]:
        return [view for view in self if view.entity_id == entity_id]

    def clear(self) -> None:
        self._views.clear()


DEFAULT_REGISTRY = Registry()


class ViewInstance:
    """A registered view: one definition bound to one entity, plus its frame."""

    def __init__(
        self,
        *,
        name: str,
        func: Callable,
        entity_id: str,
        inputs: Any,
        schema: Mapping[str, Field],
        lineage: Mapping[str, Iterable[FieldRef]] | None,
        source: str | None,
        registry: Registry,
    ) -> None:
        self.name = name
        self.func = func
        self.entity_id = entity_id
        self.kind = entity_kind(entity_id)
        self.source = source
        self.registry = registry
        self._schema = dict(schema)
        self._frame: pl.DataFrame | None = None

        if "." not in name:
            raise ValueError(f"view name {name!r} must be '<topic>.<name>'")
        if not schema:
            raise ValueError(f"{name}: schema must not be empty")

        self.inputs = inputs
        self.input_list: list[ViewInstance] = _normalise_inputs(name, inputs)

        for inst in self.input_list:
            if not isinstance(inst, ViewInstance):
                raise ValueError(
                    f"{name}: inputs must be ViewInstance objects, "
                    f"got {type(inst).__name__}"
                )
            if inst is self:
                raise ValueError(f"{name}: a view cannot be its own input")
        _assert_company_isolation(self)

        self.fields = Fields(
            {column: FieldRef(view=self, column=column, field=field)
             for column, field in self._schema.items()}
        )
        self.lineage = _validate_lineage(name, lineage, self._schema, self.input_list)

    # -- declaration ------------------------------------------------------

    @property
    def schema(self) -> dict[str, pl.DataType]:
        return {column: field.dtype for column, field in self._schema.items()}

    @property
    def field_declarations(self) -> dict[str, Field]:
        return dict(self._schema)

    @property
    def entity_scoped(self) -> bool:
        """True when the view is about one entity rather than the whole study."""
        return self.entity_id != ALL

    def declared_lineage(self, column: str) -> list[FieldRef] | None:
        """Upstream fields declared for ``column``, or None when undeclared."""
        return self.lineage.get(column)

    # -- data -------------------------------------------------------------

    @property
    def frame(self) -> pl.DataFrame:
        """This view's computed frame.

        Reading it from inside another view's body is checked against that
        view's declared ``inputs``: an undeclared read is a hard error, which
        catches both a forgotten dependency and a read of something not yet
        computed.
        """
        reader = _CURRENT_VIEW.get()
        if reader is not None and reader is not self and self not in reader.input_list:
            raise RuntimeError(
                f"{reader.name}: read {self.name}.frame but {self.name} is not "
                f"in its inputs; declared inputs are "
                f"{sorted(i.name for i in reader.input_list)}"
            )
        if self._frame is None:
            raise RuntimeError(f"{self.name}: frame requested before it was computed")
        return self._frame

    @property
    def data_frames(self) -> dict[str, pl.DataFrame]:
        """The frame under its entity key, for tools that walk the registry."""
        return {self.entity_id: self.frame}

    def frame_for(self, entity_id: str | None = None) -> pl.DataFrame:
        """The frame, refusing a request for a different entity."""
        if entity_id is not None and entity_id != self.entity_id:
            raise KeyError(
                f"{self.name} is bound to {self.entity_id}, "
                f"not to {entity_id!r}"
            )
        return self.frame

    def set_frame(self, frame: pl.DataFrame) -> None:
        self._frame = frame

    def forget(self) -> None:
        self._frame = None

    def __repr__(self) -> str:
        state = "computed" if self._frame is not None else "declared"
        return f"<view {self.name} [{self.entity_id}] ({state})>"


def _assert_company_isolation(instance: ViewInstance) -> None:
    """One issuer's view may not read another issuer's view.

    The one cross-entity reference the framework allows -- a security reading
    its own issuer -- cannot be checked here because it needs the entity table;
    ``calculate.py`` checks it once a research root is bound.
    """
    if instance.kind != "issuer":
        return
    for upstream in instance.input_list:
        if upstream.kind == "issuer" and upstream.entity_id != instance.entity_id:
            raise ValueError(
                f"{instance.name} [{instance.entity_id}] reads {upstream.name} "
                f"[{upstream.entity_id}]; a company view must not depend on "
                f"another company's view"
            )


def _normalise_inputs(name: str, inputs: Any) -> list[ViewInstance]:
    if inputs is None:
        return []
    if isinstance(inputs, ViewInstance):
        return [inputs]
    if isinstance(inputs, Mapping):
        return list(inputs.values())
    if isinstance(inputs, (list, tuple)):
        return list(inputs)
    raise ValueError(
        f"{name}: inputs must be a ViewInstance, list, tuple or mapping, "
        f"got {type(inputs).__name__}"
    )


def _validate_lineage(
    name: str,
    lineage: Mapping[str, Iterable[FieldRef]] | None,
    schema: Mapping[str, Field],
    input_list: list[ViewInstance],
) -> dict[str, list[FieldRef]]:
    if lineage is None:
        return {}
    resolved: dict[str, list[FieldRef]] = {}
    for column, refs in lineage.items():
        if column not in schema:
            raise ValueError(
                f"{name}: lineage key {column!r} is not in schema; "
                f"schema columns are {sorted(schema)}"
            )
        if isinstance(refs, FieldRef):
            refs = [refs]
        collected: list[FieldRef] = []
        for ref in refs:
            if not isinstance(ref, FieldRef):
                raise ValueError(
                    f"{name}: lineage[{column!r}] entries must be FieldRef objects, "
                    f"got {type(ref).__name__}"
                )
            owner = ref.view
            if owner not in input_list:
                raise ValueError(
                    f"{name}: lineage[{column!r}] references {owner.name}, which is "
                    f"not in inputs; inputs are "
                    f"{sorted(i.name for i in input_list)}"
                )
            if owner.fields.get(ref.column) is not ref:
                raise ValueError(
                    f"{name}: lineage[{column!r}] references {ref}, which is not the "
                    f"registered field object of {owner.name}"
                )
            collected.append(ref)
        resolved[column] = collected
    return resolved


def takes_entity_param(name: str, func: Callable) -> bool:
    """True when the view function declares the optional ``entity_id`` parameter."""
    params = list(inspect.signature(func).parameters.values())
    positional = [
        p for p in params if p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD)
    ]
    if not positional:
        raise ValueError(f"{name}: view function needs an 'inp' first parameter")
    if positional[0].name != "inp":
        raise ValueError(
            f"{name}: first parameter must be named 'inp', got {positional[0].name!r}"
        )
    if len(positional) == 1:
        return False
    if len(positional) > 2:
        raise ValueError(
            f"{name}: view function takes at most (inp, entity_id), got "
            f"{[p.name for p in positional]}"
        )
    if positional[1].name != "entity_id":
        raise ValueError(
            f"{name}: second parameter must be named 'entity_id', got "
            f"{positional[1].name!r}"
        )
    return True


def view(
    *,
    name: str,
    entity_id: str,
    inputs: Any = None,
    schema: Mapping[str, Field],
    lineage: Mapping[str, Iterable[FieldRef]] | None = None,
    source: str | None = None,
    registry: Registry | None = None,
) -> Callable[[Callable], ViewInstance]:
    """Turn a pure function into a registered :class:`ViewInstance`.

    ``entity_id`` is the one entity this instance is about, or ``ALL`` for a
    view that is not entity-specific (a fact file, a study-wide table). Wrapping
    the same function once per entity is how a study reuses a definition.
    """
    if not entity_id:
        raise ValueError(f"{name}: entity_id is required; use {ALL!r} if not scoped")
    entity_kind(entity_id)

    def decorate(func: Callable) -> ViewInstance:
        takes_entity_param(name, func)
        target = registry if registry is not None else DEFAULT_REGISTRY
        instance = ViewInstance(
            name=name,
            func=func,
            entity_id=entity_id,
            inputs=inputs,
            schema=schema,
            lineage=lineage,
            source=source,
            registry=target,
        )
        instance.__doc__ = func.__doc__
        target.register(instance)
        return instance

    return decorate


def current_view() -> ViewInstance | None:
    """The view whose body is running, if any."""
    return _CURRENT_VIEW.get()


def run_in_view_context(instance: ViewInstance, call: Callable[[], Any]) -> Any:
    """Execute ``call`` as if ``instance``'s body were running."""
    token = _CURRENT_VIEW.set(instance)
    try:
        return call()
    finally:
        _CURRENT_VIEW.reset(token)
