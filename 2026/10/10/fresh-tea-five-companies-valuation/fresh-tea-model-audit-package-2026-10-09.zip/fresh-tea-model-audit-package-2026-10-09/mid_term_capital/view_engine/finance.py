"""Dated shareholder cash flows, with one explicit investment and positive receipts."""
from datetime import date
from math import isfinite

from .units import year_fraction


def present_value(start: date, receipts: list[tuple[date, float]], rate: float) -> float:
    """Discount receipts on actual/365. Rights may be paid after an exit date."""
    if rate <= -1 or not isfinite(rate):
        raise ValueError("discount rate must be finite and greater than -1")
    if not receipts or any(d <= start or not isfinite(v) or v < 0 for d, v in receipts):
        raise ValueError("receipts must be finite, nonnegative and strictly future")
    return sum(v / (1 + rate) ** year_fraction(start, d) for d, v in receipts)


def investment_xirr(start: date, price: float, receipts: list[tuple[date, float]]) -> float:
    """Unique IRR for a positive initial price and nonnegative future receipts.

    Restricting this API to an investment followed by receipts avoids silently
    selecting one of several roots of general cash flows with multiple sign changes.
    """
    if price <= 0 or not isfinite(price):
        raise ValueError("initial price must be finite and positive")
    present_value(start, receipts, 0)
    if not any(v > 0 for _, v in receipts):
        raise ValueError("at least one receipt must be positive")
    lo, hi = -0.999999, 1.0
    while present_value(start, receipts, hi) > price:
        hi = 2 * hi + 1
        if hi > 1e12:
            raise ValueError("IRR exceeds supported bracket")
    if present_value(start, receipts, lo) < price:
        raise ValueError("IRR below supported bracket")
    for _ in range(180):
        mid = (lo + hi) / 2
        if present_value(start, receipts, mid) > price:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2
