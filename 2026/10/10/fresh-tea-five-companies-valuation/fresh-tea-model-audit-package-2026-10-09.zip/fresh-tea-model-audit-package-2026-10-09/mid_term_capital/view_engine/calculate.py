"""Walking the view graph and writing the result layer.

``calculate`` starts from the result-layer views, walks ``inputs`` backwards to
get an execution order, evaluates every view it needs, and writes this run's
``results/<情景子目录>/``.
Nothing is cached on disk, and a run that fails validation produces no result
file at all.
"""

import hashlib
import inspect
import sys
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

import polars as pl

from mid_term_capital.view_engine import loader
from mid_term_capital.view_engine.view import (
    ALL,
    ViewInstance,
    run_in_view_context,
    takes_entity_param,
)


@dataclass(frozen=True)
class ResultTable:
    """One archived result file: which view fills it and what its key is."""

    filename: str
    view: ViewInstance
    key: tuple[str, ...]

    def __post_init__(self) -> None:
        if not self.filename.endswith(".csv"):
            raise ValueError(f"{self.filename!r}: result files are CSV")
        if not self.key:
            raise ValueError(f"{self.filename}: a result table needs a primary key")
        missing = [column for column in self.key if column not in self.view.fields]
        if missing:
            raise ValueError(
                f"{self.filename}: key column(s) {missing} are not published by "
                f"{self.view.name}; it publishes {sorted(self.view.fields)}"
            )


class CalculationError(RuntimeError):
    """A view broke its declared contract while being evaluated."""


def dependency_order(roots: Sequence[ViewInstance]) -> list[ViewInstance]:
    """Depth-first post-order over ``inputs``: dependencies first, no cycles."""
    ordered: list[ViewInstance] = []
    done: set[ViewInstance] = set()
    in_progress: list[ViewInstance] = []

    def visit(instance: ViewInstance) -> None:
        if instance in done:
            return
        if instance in in_progress:
            cycle = in_progress[in_progress.index(instance):] + [instance]
            raise CalculationError(
                "cycle in view inputs: " + " -> ".join(v.name for v in cycle)
            )
        in_progress.append(instance)
        for upstream in instance.input_list:
            visit(upstream)
        in_progress.pop()
        done.add(instance)
        ordered.append(instance)

    for root in roots:
        visit(root)
    return ordered


class Runner:
    """Evaluates views against one research root."""

    def __init__(self, research: loader.Research, log: Callable[[str], None]) -> None:
        self.research = research
        self.log = log
        self.evaluated: list[str] = []

    def check_cross_entity(self, instance: ViewInstance) -> None:
        """Enforce the one allowed security -> issuer reference.

        A security's view may read its own issuer's views; which issuer that is
        only the entity table can say, so the check waits until a root is bound.
        """
        if instance.kind != "security":
            return
        parent = self.research.parent_of(instance.entity_id)
        for upstream in instance.input_list:
            if upstream.kind == "issuer" and upstream.entity_id != parent:
                raise CalculationError(
                    f"{instance.name} [{instance.entity_id}] reads "
                    f"{upstream.name} [{upstream.entity_id}], but its issuer is "
                    f"{parent}"
                )

    def input_value(self, upstream: ViewInstance) -> pl.DataFrame:
        """The frame one input contributes. Every input is already one entity."""
        return upstream.frame

    def call(self, instance: ViewInstance) -> pl.DataFrame:
        declared = instance.inputs
        if isinstance(declared, Mapping):
            argument: Any = {
                key: self.input_value(upstream)
                for key, upstream in declared.items()
            }
        else:
            argument = [self.input_value(upstream) for upstream in instance.input_list]

        def invoke() -> pl.DataFrame:
            if takes_entity_param(instance.name, instance.func):
                return instance.func(argument, instance.entity_id)
            return instance.func(argument)

        try:
            frame = run_in_view_context(instance, invoke)
        except AssertionError as error:
            raise CalculationError(
                f"{instance.name}[{instance.entity_id}]: reconciliation failed: {error}"
            ) from error
        except Exception as error:
            raise CalculationError(
                f"{instance.name}[{instance.entity_id}]: {type(error).__name__}: {error}"
            ) from error
        return self._validate_output(instance, frame)

    def _validate_output(self, instance: ViewInstance, frame: Any) -> pl.DataFrame:
        if isinstance(frame, pl.LazyFrame):
            raise CalculationError(
                f"{instance.name}[{instance.entity_id}]: returned a LazyFrame; views must "
                f"return an eager polars DataFrame"
            )
        if not isinstance(frame, pl.DataFrame):
            raise CalculationError(
                f"{instance.name}[{instance.entity_id}]: returned {type(frame).__name__}, "
                f"expected a polars DataFrame"
            )
        declared = instance.schema
        actual = dict(frame.schema)
        if set(actual) != set(declared):
            missing = sorted(set(declared) - set(actual))
            extra = sorted(set(actual) - set(declared))
            raise CalculationError(
                f"{instance.name}[{instance.entity_id}]: output columns differ from schema; "
                f"missing {missing}, unexpected {extra}"
            )
        for column, dtype in declared.items():
            if actual[column] != dtype:
                raise CalculationError(
                    f"{instance.name}[{instance.entity_id}]: column {column!r} declared "
                    f"{dtype}, got {actual[column]}"
                )
        if frame.height == 0:
            raise CalculationError(
                f"{instance.name}[{instance.entity_id}]: produced an empty frame"
            )
        return frame.select(list(declared))

    def run_view(self, instance: ViewInstance) -> None:
        if instance._frame is not None:
            return
        self.check_cross_entity(instance)
        instance.set_frame(self.call(instance))
        self.evaluated.append(instance.name)


def _sort_columns(instance: ViewInstance, key: Sequence[str]) -> list[str]:
    """Key columns first, then the remaining non-numeric columns, for stable CSV order."""
    rest = [
        column
        for column, field in instance.field_declarations.items()
        if column not in key and field.dtype not in (pl.Float64, pl.Int64, pl.Int32)
    ]
    return list(key) + rest


def _stack(instance: ViewInstance, research: loader.Research) -> pl.DataFrame:
    """A result view's frame. Result tables are ALL-bound and concat their inputs."""
    return instance.frame


def _write_result(log: Callable[[str], None], path: Path, frame: pl.DataFrame) -> None:
    """Write one result file and report its size. The only disk write in a run."""
    frame.write_csv(path)
    log(f"  wrote {path.name}: {frame.height} row(s), {frame.width} column(s)")


def _fact_path(declared) -> str:
    """A fact-file declaration is a path, or a ``(path, unit)`` pair."""
    return declared[0] if isinstance(declared, tuple) else declared


def input_hash(research: loader.Research, tables: Sequence[ResultTable]) -> str:
    """SHA-256 over canonical inputs and code, including view helper modules.

    Function bodies alone miss changes to interpolation, cash-flow solvers and
    other helpers called by a view. Whole study and engine modules are therefore
    part of the fingerprint, alongside provenance metadata.
    """
    digest = hashlib.sha256()
    for declared in sorted(research.fact_files.values(), key=_fact_path):
        digest.update((research.root / _fact_path(declared)).read_bytes())
    for name in ("parameter_meta.csv", "parameters.csv", "scenarios.csv", "run.csv"):
        digest.update((research.params_dir / name).read_bytes())
    for name in ("entity_meta.csv", "sources.csv", "data_gaps.csv"):
        path = research.root / "facts" / name
        if path.is_file():
            digest.update(name.encode())
            digest.update(path.read_bytes())
    for directory in (research.root / "model", Path(__file__).parent):
        for path in sorted(directory.glob("*.py")):
            digest.update(str(path.relative_to(directory)).encode())
            digest.update(path.read_bytes())
    seen: set[str] = set()
    for table in tables:
        for instance in dependency_order([table.view]):
            if instance.name in seen:
                continue
            seen.add(instance.name)
            digest.update(instance.name.encode())
            digest.update(inspect.getsource(instance.func).encode())
    return digest.hexdigest()[:16]


def calculate(
    research: loader.Research,
    tables: Sequence[ResultTable],
    *,
    log: Callable[[str], None] | None = None,
) -> dict[str, pl.DataFrame]:
    """Compute this run's scenario and write it to ``results/<情景子目录>/``.

    Validation happens before the first result file is touched, so a failure
    leaves the previous contents of that subdirectory untouched rather than
    half-overwritten.
    """
    emit = log if log is not None else (lambda message: print(message, file=sys.stdout))

    if not tables:
        raise CalculationError("no result tables requested")
    filenames = [table.filename for table in tables]
    if len(set(filenames)) != len(filenames):
        raise CalculationError(f"duplicate result filenames: {filenames}")

    order = dependency_order([table.view for table in tables])
    emit(f"views to compute ({len(order)}):")
    for instance in order:
        emit(f"  - {instance.name} [{instance.entity_id}]")

    parameters = research.params
    emit(f"scenario: {parameters.scenario_id} -> results/{parameters.results_subdir}/")
    emit(f"declared scenarios: {', '.join(parameters.scenario_ids)}")
    emit(f"parameter rows: {parameters.values.height}")
    emit(f"entities: {len(research.entities('issuer'))} issuer, "
         f"{len(research.entities('security'))} security, "
         f"{len(research.entities('industry'))} industry")

    # Read the three registry files on every run, whether or not a view asks for
    # them. ``sources`` also checks that every cited source id is registered.
    # A view-less file (``data_gaps`` has no view) would otherwise stay unread,
    # and a malformed row in it would hide until someone happened to look.
    emit(f"entity_meta rows: {research.entity_meta.height}")
    emit(f"source rows: {research.sources.height}")
    emit(f"data gap rows: {research.data_gaps.height}")

    runner = Runner(research, emit)
    for instance in order:
        runner.run_view(instance)
    emit(f"computed {len(runner.evaluated)} view(s)")

    results_dir = research.run_results_dir
    results_dir.mkdir(parents=True, exist_ok=True)

    # Prepare and check every table before touching the directory, so a key
    # violation on the last table cannot leave the earlier files overwritten.
    prepared: list[tuple[Path, pl.DataFrame]] = []
    for table in tables:
        frame = _stack(table.view, research)
        _assert_result_key(table, frame)
        _assert_result_scenario(table, frame, parameters.scenario_id)
        prepared.append(
            (results_dir / table.filename,
             frame.sort(_sort_columns(table.view, table.key)))
        )

    outputs: dict[str, pl.DataFrame] = {}
    for path, frame in prepared:
        _write_result(emit, path, frame)
        outputs[path.name] = frame

    produced = set(outputs)
    for existing in sorted(results_dir.glob("*.csv")):
        if existing.name not in produced:
            existing.unlink()
            emit(f"  removed stale result {existing.name}")

    emit(f"input hash: {input_hash(research, tables)}")
    emit(f"generated at: {datetime.now().isoformat(timespec='seconds')}")
    return outputs


def _assert_result_scenario(
    table: ResultTable, frame: pl.DataFrame, scenario_id: str
) -> None:
    """A run writes one scenario; a result carrying another one is a bug.

    ``history_facts`` is the exception: it is scenario-independent and marks
    every row ``fact`` (规范 5.3).
    """
    if "scenario" not in frame.columns:
        return
    seen = set(frame["scenario"].unique().to_list())
    unexpected = sorted(seen - {scenario_id, "fact"})
    if unexpected:
        raise CalculationError(
            f"{table.filename}: carries scenario(s) {unexpected}, but this run "
            f"computes {scenario_id!r} (see run.csv)"
        )


def _assert_result_key(table: ResultTable, frame: pl.DataFrame) -> None:
    key = list(table.key)
    nulls = frame.select(key).null_count().sum_horizontal().item()
    if nulls:
        bad = frame.filter(pl.any_horizontal([pl.col(c).is_null() for c in key]))
        raise CalculationError(
            f"{table.filename}: {nulls} null(s) in primary key {key}\n{bad.head(5)}"
        )
    duplicated = frame.filter(pl.struct(key).is_duplicated())
    if not duplicated.is_empty():
        raise CalculationError(
            f"{table.filename}: primary key {key} duplicated on "
            f"{duplicated.select(key).head(5).to_dicts()}"
        )
