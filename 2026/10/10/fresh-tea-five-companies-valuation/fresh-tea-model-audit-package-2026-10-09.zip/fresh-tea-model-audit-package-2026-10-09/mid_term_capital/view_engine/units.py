"""Unit vocabulary and conversions.

The framework does not verify unit algebra -- view bodies are arbitrary polars
expressions -- so this module only collects the conversions that would otherwise
be scattered through the models as magic numbers. Units themselves are declared
once per field in :class:`view_engine.view.Field`.

Canonical scales used across a research root are declared in its ``README.md``;
for the banking study money is CNY million, shares are millions of shares, and
because both are millions a quotient is directly a per-share amount in CNY.
"""

import math
from datetime import date

#: Unit names accepted by ``Field`` for numeric columns.
DECIMAL_RATIO = "decimal_ratio"
CURRENCY = "currency"
CURRENCY_PER_UNIT = "currency_per_unit"
COUNT = "count"
MULTIPLE = "multiple"

DAYS_PER_YEAR = 365


def decimal_from_percent(percent: float) -> float:
    """Percentage points to a decimal ratio: ``1.29 -> 0.0129``."""
    return percent / 100.0


def percent_from_decimal(ratio: float) -> float:
    """Decimal ratio to percentage points: ``0.0129 -> 1.29``."""
    return ratio * 100.0


def bps_from_decimal(ratio: float) -> float:
    """Decimal ratio to basis points: ``0.0129 -> 129``."""
    return ratio * 10_000.0


def per_share(amount_mn: float, shares_mn: float) -> float:
    """Money in millions over shares in millions, per share in currency units."""
    return amount_mn / shares_mn


def shares_for(amount_mn: float, price: float) -> float:
    """Money in millions over a per-share price, in millions of shares."""
    return amount_mn / price


def year_fraction(start: date, end: date) -> float:
    """Calendar days between two dates over 365.

    Used for part-year periods such as the second half of a fiscal year. Actual
    days, not 30/360: the cash flows are discounted on the same day count.
    """
    return (end - start).days / DAYS_PER_YEAR


def pow_discount(rate: float, years: float) -> float:
    """Discount factor ``1/(1+rate)**years``."""
    return (1.0 + rate) ** (-years)


def safe_div(numerator: float | None, denominator: float | None) -> float | None:
    """Division that yields None instead of raising on a zero denominator.

    None means "not computed" everywhere in this codebase, so a zero
    denominator must not silently become 0 or raise deep inside a projection.
    """
    if numerator is None or denominator is None or denominator == 0:
        return None
    return numerator / denominator


def average_pair(previous: float | None, current: float | None) -> float | None:
    """Average of opening and closing balance, None if either side is missing."""
    if previous is None or current is None:
        return None
    return (previous + current) / 2.0


def isclose(a: float, b: float, rel_tol: float = 1e-9, abs_tol: float = 1e-9) -> bool:
    """Float comparison for reconciliation assertions."""
    return math.isclose(a, b, rel_tol=rel_tol, abs_tol=abs_tol)
