"""Declarative view engine for the company analysis workflow.

A view is a pure polars function that declares its name, the one entity it is
about, its inputs, its output schema and its field lineage. Importing a view
module registers it; ``calculate.py`` walks the declared inputs backwards from
the result tables, evaluates each view once and writes ``results/``.

Only the declaration layer is re-exported here. Loaders, calculation, the result
schemas and the two inspection tools are imported by name where they are used::

    from mid_term_capital.view_engine import ALL, Field, view
    from mid_term_capital.view_engine import calculate, loader, result_schema
"""

from mid_term_capital.view_engine import result_schema, units
from mid_term_capital.view_engine.view import (
    ALL,
    DEFAULT_REGISTRY,
    ENTITY_TYPES,
    UNIT_VOCABULARY,
    Field,
    FieldRef,
    Fields,
    Registry,
    ViewInstance,
    current_view,
    entity_kind,
    run_in_view_context,
    takes_entity_param,
    view,
)

__all__ = [
    "ALL",
    "DEFAULT_REGISTRY",
    "ENTITY_TYPES",
    "UNIT_VOCABULARY",
    "Field",
    "FieldRef",
    "Fields",
    "Registry",
    "ViewInstance",
    "current_view",
    "entity_kind",
    "result_schema",
    "run_in_view_context",
    "takes_entity_param",
    "units",
    "view",
]
