"""The declared schema of the four framework result tables, and how to read them.

These live in the engine rather than in each study because they are the same for
every study, and because a CSV cannot carry its own types: a ``period`` column
holding ``"2026"`` and ``"ALL"`` reads back as an integer unless the reader says
otherwise. Anything that opens a result file must pass the schema from here:

    from mid_term_capital.view_engine import result_schema

    frame = result_schema.read_result(path)

A study whose report cites a table outside the four registers its schema with
:func:`register`, so that every result file in the repository has exactly one
declared schema and no reader has to guess.

``bound`` is deliberately absent from the valuation and return tables. The
framework previously declared it without ever defining it; a column whose
meaning is left open is worse than no column, because two studies would fill it
with two different things.
"""

from pathlib import Path

import polars as pl

from mid_term_capital.view_engine.csvio import read_csv_exact

BASIS = pl.Enum(["actual", "estimate", "forecast"])
NODE = pl.Enum(["explicit", "interpolated"])
TAX_BASIS = pl.Enum(["after_tax", "pre_tax"])

#: Shared by forecast.csv and history_facts.csv so the two cannot drift apart.
PREDICTION_COLUMNS: dict[str, pl.DataType] = {
    "entity_id": pl.String,
    "scenario": pl.String,
    "period": pl.String,
    "segment_id": pl.String,
    "metric_id": pl.String,
    "basis": BASIS,
    "node_type": NODE,
    "value": pl.Float64,
}
PREDICTION_KEY = ("entity_id", "scenario", "period", "segment_id", "metric_id")

FORECAST_SCHEMA = PREDICTION_COLUMNS
HISTORY_SCHEMA = PREDICTION_COLUMNS

VALUATION_SCHEMA: dict[str, pl.DataType] = {
    "entity_id": pl.String,
    "scenario": pl.String,
    "valuation_date": pl.Date,
    "target_year": pl.Int32,
    "method": pl.String,
    "equity_value": pl.Float64,
    "diluted_shares": pl.Float64,
    "price": pl.Float64,
    "currency": pl.String,
    # The steady-state multiple the row used, NULL for methods that do not
    # define one. Declared here because the terminal assumption is the largest
    # single driver of a discounted-dividend value, so a report must be able to
    # cite it from a result table rather than from the model's internals.
    "terminal_pb": pl.Float64,
}
VALUATION_KEY = ("entity_id", "scenario", "valuation_date", "target_year", "method")

RETURNS_SCHEMA: dict[str, pl.DataType] = {
    "entity_id": pl.String,
    "scenario": pl.String,
    "valuation_date": pl.Date,
    "exit_date": pl.Date,
    # A holding return is published once per terminal method, so the method is
    # part of the row identity rather than a duplicate of the valuation's.
    "method": pl.String,
    "tax_basis": TAX_BASIS,
    "target_price": pl.Float64,
    "total_return": pl.Float64,
    "xirr": pl.Float64,
    "threshold_price": pl.Float64,
    "safety_margin": pl.Float64,
}
RETURNS_KEY = (
    "entity_id", "scenario", "valuation_date", "exit_date", "method", "tax_basis"
)

#: Filename -> (schema, primary key) for the four framework tables.
FRAMEWORK_TABLES: dict[str, tuple[dict[str, pl.DataType], tuple[str, ...]]] = {
    "forecast.csv": (FORECAST_SCHEMA, PREDICTION_KEY),
    "history_facts.csv": (HISTORY_SCHEMA, PREDICTION_KEY),
    "valuation.csv": (VALUATION_SCHEMA, VALUATION_KEY),
    "returns.csv": (RETURNS_SCHEMA, RETURNS_KEY),
}

_EXTRA: dict[str, tuple[dict[str, pl.DataType], tuple[str, ...]]] = {}


def register(
    filename: str, schema: dict[str, pl.DataType], key: tuple[str, ...]
) -> None:
    """Declare a study's own result table so it can be read back unambiguously."""
    if not filename.endswith(".csv"):
        raise ValueError(f"{filename!r}: result tables are CSV")
    if filename in FRAMEWORK_TABLES:
        raise ValueError(f"{filename!r} is a framework table; do not re-register it")
    _EXTRA[filename] = (dict(schema), tuple(key))


def tables() -> dict[str, tuple[dict[str, pl.DataType], tuple[str, ...]]]:
    """Every declared result table: the four framework ones plus the registered."""
    return {**FRAMEWORK_TABLES, **_EXTRA}


def read_result(path: str | Path, name: str | None = None) -> pl.DataFrame:
    """Read an archived result table with its declared schema."""
    target = Path(path)
    key = name or target.name
    declared = tables()
    if key not in declared:
        raise KeyError(
            f"no declared schema for {key!r}; declared: {sorted(declared)}"
        )
    return read_csv_exact(target, declared[key][0], key)
