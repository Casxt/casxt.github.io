"""View dependency graph and field lineage graph from registry declarations.

``graph.py`` renders the two inspection graphs defined by the calculation
framework design doc: view level and field level. It reads only declarations
from the registry: never computed frames, never a research root and never a
file. The only file it may write is the ``--out`` target.

At view level the nodes are views plus the file-level ``source`` of a view, and
the edges are ``inputs``. At field level the nodes are ``<view>.<column>`` and
the edges are ``lineage``; a column with no declared lineage conservatively
depends on every field of every input, and those edges are drawn dashed and
labelled ``未声明``.
"""

import argparse
import sys
from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path

from mid_term_capital.view_engine import loader
from mid_term_capital.view_engine.view import (
    DEFAULT_REGISTRY,
    Registry,
    ViewInstance,
)

MERMAID_FORMAT = "mermaid"
DOT_FORMAT = "dot"
MERMAID_DIRECTION = "LR"
DOT_DIRECTION = "LR"
UNDECLARED_EDGE_LABEL = "未声明"
MARKDOWN_SUFFIX = ".md"
DOT_SUFFIX = ".dot"
OUT_SUFFIXES = (MARKDOWN_SUFFIX, DOT_SUFFIX)
UNDECLARED_NODE_NAME = "node"


@dataclass(frozen=True)
class Node:
    """One graph node: a renderer-safe id plus the label to display."""

    node_id: str
    label: str


@dataclass(frozen=True)
class Edge:
    """One directed edge, flagged when it comes from the undeclared rule."""

    source: str
    target: str
    undeclared: bool = False


@dataclass(frozen=True)
class Graph:
    """Nodes and edges ready for rendering."""

    nodes: tuple[Node, ...]
    edges: tuple[Edge, ...]


class _GraphBuilder:
    """Accumulates nodes and edges with unique renderer-safe node ids."""

    def __init__(self) -> None:
        self._ids: dict[str, str] = {}
        self._used: set[str] = set()
        self._nodes: list[Node] = []
        self._edges: list[Edge] = []
        self._edge_keys: set[tuple[str, str, bool]] = set()

    def node(self, label: str) -> str:
        """Return the node id for ``label``, creating the node when it is new."""
        existing = self._ids.get(label)
        if existing is not None:
            return existing
        node_id = _safe_node_id(label, self._used)
        self._ids[label] = node_id
        self._used.add(node_id)
        self._nodes.append(Node(node_id=node_id, label=label))
        return node_id

    def edge(self, source: str, target: str, *, undeclared: bool = False) -> None:
        """Add the edge between two labels unless the same edge already exists."""
        key = (source, target, undeclared)
        if key in self._edge_keys:
            return
        self._edge_keys.add(key)
        self._edges.append(
            Edge(
                source=self.node(source),
                target=self.node(target),
                undeclared=undeclared,
            )
        )

    def graph(self) -> Graph:
        """The accumulated graph."""
        return Graph(tuple(self._nodes), tuple(self._edges))


def _safe_node_id(label: str, used: set[str]) -> str:
    """A Mermaid/DOT-safe node id derived from a label, unique within one graph."""
    cleaned = "".join(
        character
        if character.isascii() and (character.isalnum() or character == "_")
        else "_"
        for character in label
    ).strip("_")
    base = cleaned or UNDECLARED_NODE_NAME
    if base[0].isdigit():
        base = f"n_{base}"
    candidate = base
    suffix = 2
    while candidate in used:
        candidate = f"{base}_{suffix}"
        suffix += 1
    return candidate


def _require_view(registry: Registry, view_name: str) -> ViewInstance:
    """Look a view up, raising a ValueError that lists the available names."""
    if view_name not in registry:
        available = ", ".join(registry.names()) or "(none)"
        raise ValueError(f"no view {view_name!r}; registered: {available}")
    return registry[view_name]


def _require_column(instance: ViewInstance, column: str) -> None:
    """Check a column exists, raising a ValueError that lists the columns."""
    if column not in instance.fields:
        available = ", ".join(instance.field_declarations) or "(none)"
        raise ValueError(
            f"{instance.name} has no field {column!r}; available: {available}"
        )


def _split_field_name(field_name: str) -> tuple[str, str]:
    """Split ``<view>.<column>`` on the last dot."""
    view_name, separator, column = field_name.rpartition(".")
    if not separator or not view_name or not column:
        raise ValueError(f"field must be '<view>.<column>', got {field_name!r}")
    return view_name, column


def _dependency_subtree(instance: ViewInstance) -> list[ViewInstance]:
    """``instance`` plus everything it transitively depends on, sorted by name."""
    found: dict[str, ViewInstance] = {}
    pending = [instance]
    while pending:
        current = pending.pop()
        if current.name in found:
            continue
        found[current.name] = current
        pending.extend(current.input_list)
    return [found[name] for name in sorted(found)]


def _add_undeclared_edges(
    instance: ViewInstance, target: str, builder: _GraphBuilder
) -> None:
    """Conservative rule: an undeclared column depends on all input fields."""
    for upstream in instance.input_list:
        for column in upstream.field_declarations:
            builder.edge(upstream.fields[column].full_name, target, undeclared=True)


def _declare_column(
    instance: ViewInstance, column: str, builder: _GraphBuilder
) -> None:
    """Add one output column's edges from its declaration alone."""
    target = f"{instance.name}.{column}"
    builder.node(target)
    refs = instance.declared_lineage(column)
    if refs is None:
        _add_undeclared_edges(instance, target, builder)
        return
    for ref in refs:
        builder.edge(ref.full_name, target)


def _trace_field(
    instance: ViewInstance, column: str, builder: _GraphBuilder, visited: set[str]
) -> None:
    """Backward-trace one field; undeclared columns stop at the view boundary."""
    target = f"{instance.name}.{column}"
    builder.node(target)
    if target in visited:
        return
    visited.add(target)
    refs = instance.declared_lineage(column)
    if refs is None:
        _add_undeclared_edges(instance, target, builder)
        return
    for ref in refs:
        builder.edge(ref.full_name, target)
        _trace_field(ref.view, ref.column, builder, visited)


def build_view_graph(registry: Registry, view_name: str | None = None) -> Graph:
    """View-level graph: views plus their ``source`` files, edges from inputs.

    With ``view_name`` only that view's dependency subtree is included. Without
    it every registered view is included and the graph is always complete,
    because ``inputs`` is mandatory.
    """
    if view_name is None:
        instances = [registry[name] for name in registry.names()]
    else:
        instances = _dependency_subtree(_require_view(registry, view_name))
    builder = _GraphBuilder()
    for instance in instances:
        builder.node(instance.name)
    for instance in instances:
        if instance.source:
            builder.edge(instance.source, instance.name)
        for upstream in instance.input_list:
            builder.edge(upstream.name, instance.name)
    return builder.graph()


def build_field_graph(
    registry: Registry, field_name: str | None = None, view_name: str | None = None
) -> Graph:
    """Field-level graph over ``<view>.<column>`` nodes and ``lineage`` edges.

    With ``field_name`` the graph is the backward lineage of that one field,
    traced to the leaves. Otherwise it covers every field of ``view_name``'s
    dependency subtree, or every registered view when ``view_name`` is None.
    """
    builder = _GraphBuilder()
    if field_name is not None:
        owner, column = _split_field_name(field_name)
        instance = _require_view(registry, owner)
        _require_column(instance, column)
        _trace_field(instance, column, builder, set())
        return builder.graph()
    if view_name is None:
        instances = [registry[name] for name in registry.names()]
    else:
        instances = _dependency_subtree(_require_view(registry, view_name))
    for instance in instances:
        for column in instance.field_declarations:
            _declare_column(instance, column, builder)
    return builder.graph()


def _mermaid_label(label: str) -> str:
    """Escape a label for a Mermaid double-quoted node string."""
    return (
        label.replace("#", "#35;")
        .replace('"', "#quot;")
        .replace("\\", "#92;")
        .replace("\n", " ")
        .replace("\r", " ")
    )


def _dot_label(label: str) -> str:
    """Escape a label for a DOT double-quoted string."""
    return (
        label.replace("\\", "\\\\")
        .replace('"', '\\"')
        .replace("\n", "\\n")
        .replace("\r", "")
    )


def render_mermaid(graph: Graph) -> str:
    """Render a graph as Mermaid ``graph LR`` text with a dashed-edge legend."""
    lines = [
        f"graph {MERMAID_DIRECTION}",
        "    %% legend: a dashed arrow (-.->) labelled "
        f"{UNDECLARED_EDGE_LABEL} means the column has no",
        "    %% declared lineage, so by the conservative rule it depends on "
        "every field of every input.",
    ]
    for node in graph.nodes:
        lines.append(f'    {node.node_id}["{_mermaid_label(node.label)}"]')
    for edge in graph.edges:
        if edge.undeclared:
            lines.append(
                f"    {edge.source} -.->|{UNDECLARED_EDGE_LABEL}| {edge.target}"
            )
        else:
            lines.append(f"    {edge.source} --> {edge.target}")
    return "\n".join(lines)


def render_dot(graph: Graph) -> str:
    """Render a graph as Graphviz DOT, dashed for undeclared edges."""
    lines = [
        "digraph views {",
        f"    rankdir={DOT_DIRECTION};",
        "    // dashed edges are undeclared in lineage; conservatively the column",
        "    // depends on every field of every input.",
    ]
    for node in graph.nodes:
        lines.append(f'    "{node.node_id}" [label="{_dot_label(node.label)}"];')
    for edge in graph.edges:
        if edge.undeclared:
            lines.append(
                f'    "{edge.source}" -> "{edge.target}" '
                f'[style=dashed, label="{UNDECLARED_EDGE_LABEL}"];'
            )
        else:
            lines.append(f'    "{edge.source}" -> "{edge.target}";')
    lines.append("}")
    return "\n".join(lines)


def _markdown_document(mermaid_text: str, title: str) -> str:
    """Wrap Mermaid text in a fenced block so a ``.md`` export renders."""
    return f"# {title}\n\n```mermaid\n{mermaid_text}\n```"


def build_parser() -> argparse.ArgumentParser:
    """The command-line parser for graph.py."""
    parser = argparse.ArgumentParser(
        prog="graph.py",
        description=(
            "Render the view dependency graph (default) or the field lineage "
            "graph (--field-level) from registry declarations. Writes to stdout "
            "unless --out is given."
        ),
    )
    parser.add_argument(
        "--field-level",
        action="store_true",
        help="render fields instead of views; edges come from lineage",
    )
    parser.add_argument(
        "--view",
        default=None,
        metavar="VIEW",
        help="only the dependency subtree of this view",
    )
    parser.add_argument(
        "--field",
        default=None,
        metavar="VIEW.COLUMN",
        help="only the backward lineage of this one field",
    )
    parser.add_argument(
        "--format",
        choices=(MERMAID_FORMAT, DOT_FORMAT),
        default=None,
        help="output format (default: mermaid, or inferred from --out)",
    )
    parser.add_argument(
        "--out",
        default=None,
        metavar="PATH",
        help="write to this .md or .dot file instead of stdout",
    )
    parser.add_argument(
        "--module",
        "--study",
        dest="modules",
        action="append",
        default=[],
        metavar="MODULE",
        help="import this module so its views register (repeatable)",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    """Run the command-line tool; returns the process exit code."""
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.view is not None and args.field is not None:
        parser.error("--view and --field cannot be combined")
    if args.out is not None and Path(args.out).suffix not in OUT_SUFFIXES:
        parser.error(f"--out must end in {' or '.join(OUT_SUFFIXES)}")
    format_name = args.format
    if format_name is None:
        format_name = (
            DOT_FORMAT
            if args.out is not None and Path(args.out).suffix == DOT_SUFFIX
            else MERMAID_FORMAT
        )
    try:
        for module_name in args.modules:
            loader.import_study(module_name)
    except ImportError as error:
        print(f"error: cannot import module: {error}", file=sys.stderr)
        return 1

    registry = DEFAULT_REGISTRY
    try:
        if args.field is not None:
            graph = build_field_graph(registry, field_name=args.field)
            title = "field lineage graph"
        elif args.field_level:
            graph = build_field_graph(registry, view_name=args.view)
            title = "field lineage graph"
        else:
            graph = build_view_graph(registry, args.view)
            title = "view dependency graph"
    except ValueError as error:
        print(f"error: {error}", file=sys.stderr)
        return 1

    if format_name == DOT_FORMAT:
        text = render_dot(graph)
    else:
        text = render_mermaid(graph)
    if args.out is None:
        print(text)
        return 0
    out_path = Path(args.out)
    if format_name == MERMAID_FORMAT and out_path.suffix == MARKDOWN_SUFFIX:
        text = _markdown_document(text, title)
    out_path.write_text(text + "\n", encoding="utf-8")
    print(f"wrote {out_path}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
