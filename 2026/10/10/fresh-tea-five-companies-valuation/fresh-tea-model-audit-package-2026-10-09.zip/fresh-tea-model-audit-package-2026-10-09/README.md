# 五家现制茶饮公司模型与结果审计包

口径、方法、恒等式和缺口见博客同目录的 `model-output-notes.MD`。

- `model/`：Python 计算代码（Polars + 本地 view_engine），含霸王茶姬专用混合经营分支。报告排版脚本不在包内。
- `facts/`：财务事实、元数据与来源；市场讨论类来源与采集路径已剔除。
- `params/`：参数、情景与运行设置。
- `results/deep_bear|deep_base|deep_bull/`：三情景各 15 张结果表。
- `mid_term_capital/view_engine/`：计算引擎。
- `pyproject.toml`：依赖声明。

复算需要 Python 3 与 Polars。包内不含第三方付费资料、原始帖子评论或个人信息。
