"""Run approved paired scenarios serially through the sole calculation entry."""
from pathlib import Path
import subprocess
import sys
import polars as pl
from mid_term_capital.view_engine.loader import RUN_SCHEMA

ROOT=Path(__file__).resolve().parents[1]
def main():
    for scenario in ['deep_bear','deep_base','deep_bull']:
        pl.DataFrame({'key':['scenario_id','valuation_date'],'value':[scenario,'2026-10-09']},schema=RUN_SCHEMA).write_csv(ROOT/'params/run.csv')
        subprocess.run([sys.executable,str(ROOT/'model/main.py')],check=True)
    pl.DataFrame({'key':['scenario_id','valuation_date'],'value':['deep_base','2026-10-09']},schema=RUN_SCHEMA).write_csv(ROOT/'params/run.csv')
if __name__=='__main__':main()
