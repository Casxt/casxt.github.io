"""Full method coverage, dated exits, and two independently tested buy returns."""
from datetime import date
from math import isclose
import polars as pl
from mid_term_capital.view_engine import view, result_schema
from mid_term_capital.view_engine.finance import present_value, investment_xirr
from deep_study import STUDY, ISSUERS, SECURITIES, get, latest_share_pool
from deep_operating import ISSUER_VIEWS, LEAVES, param, after_rent_ebit, available_assets, combine
from deep_schemas import fields, COVERAGE, BUY, MARKET, HIST_VAL, VALUATION_EVIDENCE, EXTRA

def conversion_rate(key,fx):
    metric='fx_usd_cny' if key=='cha' else 'fx_cny_hkd'
    selected=fx.filter((pl.col('metric_id')==metric)&(pl.col('period_end')<=STUDY.params.valuation_date)).sort('period_end')
    value=selected['value'][-1]
    return 1/value if key=='cha' else value

def ads_ratio(key,security,ratios):
    if key!='cha':return 1.0
    selected=ratios.filter((pl.col('entity_id')==security)&(pl.col('metric_id')=='ads_ordinary_ratio')).sort('period_end')
    return selected['value'][-1]

METHODS=['dcf_steady','dcf_fcff_policy','dcf_fcff_wacc','dcf_dividend_policy','dcf_book_return','PE','PB','DIVIDEND_YIELD','SOTP','PR','blended']
PAYLOAD={**result_schema.VALUATION_SCHEMA,'status':pl.String,'confidence':pl.String,'reason':pl.String}
VALS=[];COVERS=[];RETURNS=[];BUYS=[];MARKETS=[];HISTORIES=[];EVIDENCE=[]
for key,issuer in ISSUERS.items():
    def create(key,issuer):
        security=SECURITIES[key];build=ISSUER_VIEWS[key]['build'];a=ISSUER_VIEWS[key]['amounts'];counts=LEAVES['counts'];quote=LEAVES['quote_usd' if key=='cha' else 'quote_hkd'];fx=LEAVES['fx_usd_cny' if key=='cha' else 'fx_cny_hkd'];ratio=LEAVES['ratios'];currency='USD' if key=='cha' else 'HKD';op_pars=ISSUER_VIEWS[key]['assumptions']
        vids=['discount','wacc','terminal_growth','terminal_roic','pe','pb_premium','pb_peer','dividend_yield','pr','required_high','required_low','dividend_tax','interim_share','weight_dcf','weight_pe']
        @view(name=f'{key}.valuation_assumptions',entity_id=security,source='params/parameters.csv',schema={p:__import__('mid_term_capital.view_engine',fromlist=['Field']).Field(pl.Float64,'multiple' if p in ['pe','pb_peer','pb_premium','pr'] else 'decimal_ratio','deep_'+p) for p in vids})
        def assumptions(inp):return pl.DataFrame([{p:STUDY.params.resolve(security,'deep_'+p,'ALL',STUDY.params.scenario_id) for p in vids}],schema={p:pl.Float64 for p in vids})
        refs=list(build.fields.values())+list(assumptions.fields.values())+list(op_pars.fields.values())
        @view(name=f'{key}.valuation_all_methods',entity_id=security,inputs=[build,assumptions,fx,op_pars,ratio],schema=fields(PAYLOAD,{'diluted_shares':'count','price':'currency_per_unit','terminal_pb':'multiple'}),lineage={k:refs+[fx.fields.value,ratio.fields.value] for k in PAYLOAD})
        def all_methods(inp):
            f,p,fx,operating,ratios=inp;p=p.row(0,named=True);f=f.to_dicts();last=f[-1];g=p['terminal_growth'];r=p['discount'];assert r>g
            conversion=conversion_rate(key,fx);ads=ads_ratio(key,security,ratios)
            # Terminal operating growth requires incremental capital, rather than free growth.
            maintenance=operating.filter(pl.col('year')==2036)['maintenance'].item()*last['revenue']
            # Do not release fixed assets forever through depreciation exceeding replacement.
            maintenance_shortfall=max(maintenance-last['depreciation'],0)
            op_last=operating.filter(pl.col('year')==2036).row(0,named=True)
            cash_attribution=last['cash_earnings_attribution'] if key=='cha' else 1.0
            terminal_fcfe=(last['normal_net_parent']+(op_last['award_expense']-maintenance_shortfall)*cash_attribution)*(1+g)-max(last['normal_net_parent'],0)*(1+g)*g/p['terminal_roic']
            per_share_growth=(1+g)/(1+op_last['share_change'])-1
            terminal_value=terminal_fcfe/(r-per_share_growth)
            rows=[]
            for current in f:
                year=int(current['period']);shares=current['shares_outstanding']/1e6/ads;book=current['equity_parent'];start=date(year,12,31);future=[v for v in f if int(v['period'])>year]
                terminal_date=date(2036,12,31);tail=(terminal_date-start).days/365
                cash=current['net_financial_assets']
                roe=current['roe'] if book>0 else None
                # Negative operating cash is kept in DCF; no zero-clipping of losses.
                ownership=lambda v:current['shares_outstanding']/v['shares_outstanding']
                terminal_ownership=ownership(last)
                dcf=sum(v['fcfe']*ownership(v)/(1+r)**(int(v['period'])-year) for v in future)+terminal_value*terminal_ownership/(1+r)**tail+cash
                ddm=sum(v['dividend']*ownership(v)/(1+r)**(int(v['period'])-year) for v in future)
                # A policy perpetuity uses full sustainable distributions only after 2036.
                ddm+=(terminal_value+last['net_financial_assets'])*terminal_ownership/(1+r)**tail
                book_return=sum(v['dividend']*ownership(v)/(1+r)**(int(v['period'])-year) for v in future)+last['equity_parent']*terminal_ownership/(1+r)**tail
                wacc=p['wacc'];assert wacc>g
                dcf_wacc=sum(v['fcfe']*ownership(v)/(1+wacc)**(int(v['period'])-year) for v in future)+terminal_fcfe/(wacc-per_share_growth)*terminal_ownership/(1+wacc)**tail+cash
                # No debt financing flow is assumed; this is a cash-neutral FCFF comparison.
                theoretical_pb=max((roe-g)/(r-g)+p['pb_premium'],0) if roe is not None else None
                pb_multiple=(theoretical_pb+p['pb_peer'])/2 if theoretical_pb is not None else None
                vals={'dcf_steady':dcf,'dcf_fcff_policy':dcf,'dcf_fcff_wacc':dcf_wacc,'dcf_dividend_policy':ddm,'dcf_book_return':book_return if last['equity_parent']>0 else None,'PE':max(current['normal_net_parent'],0)*p['pe'] if current['normal_net_parent']>0 else None,'PB':book*pb_multiple if book>0 and pb_multiple is not None else None,'DIVIDEND_YIELD':current['dividend']/p['dividend_yield'] if current['dividend']>0 else None,'SOTP':None,'PR':current['normal_net_parent']*p['pr']*roe*100 if current['normal_net_parent']>0 and roe is not None else None}
                # Final dividend earmarked in year-end equity/cash is paid next May.
                # A December buyer receives that claim; a December seller has not received it.
                pending=current['dividend']*(1-p['interim_share'])/(1+r)**((date(year+1,5,31)-start).days/365)
                vals={m:(v+pending if v is not None else None) for m,v in vals.items()}
                weights=[('dcf_steady',p['weight_dcf']),('PE',p['weight_pe'])]
                usable=[(m,w) for m,w in weights if vals[m] is not None and vals[m]>0 and w>0]
                vals['blended']=sum(vals[m]*w for m,w in usable)/sum(w for m,w in usable) if usable else None
                for method in METHODS:
                    value=vals[method];reason='经营与估值同档配对；参数为先验，连续自身/同业倍数未取得';confidence='中'
                    if method=='SOTP':reason='加盟、直营、制造、海外缺可靠分部净利润与资本；供应链为内部环节，不另凑分部价值';confidence='无法判断'
                    if method=='dcf_book_return':reason='2036停止经营并全额按归母账面返还的强条件；期间仅股息，未另加留存现金';confidence='低'
                    if method in ['PB','PR']:reason='高分红/IPO权益使ROE与PB失真；PR为模版政策，非已回测规律';confidence='低'
                    if method=='DIVIDEND_YIELD':reason='正常派息先验；特别股息不永续；无稳定正利润派息则不适用';confidence='低'
                    if method=='dcf_dividend_policy':reason='2027至2036仅正常派息；2036后改为可持续能力分配；留存终值现金未加第二次';confidence='低'
                    if key=='cha':confidence='低';reason+='；直营成本归属、收店回报、半年capex和最新股本受限，非精确目标价'
                    if key=='ny':confidence='低';reason+='；店/总部费用分配及反转缺同批回报，现金不足不假定融资'
                    if method.startswith('dcf_fcff'):reason+='；无净融资、经营利润无净债息的融资中性FCFF近似，古茗融资配对未完全披露，降低可信度';confidence='低'
                    if method=='PE' and value is None:reason='该年正常经营利润非正，不适用PE'
                    status='not_applicable' if value is None else 'low_confidence' if confidence=='低' else 'calculated'
                    if value is not None and value<=0:status='nonpositive_value';reason+='；保留非正权益推论，无有效买入价'
                    price=value*conversion/shares if value is not None else None
                    method_terminal=terminal_fcfe/(wacc-per_share_growth) if method=='dcf_fcff_wacc' else terminal_value
                    terminal_pb=(method_terminal/last['equity_parent'] if last['equity_parent']>0 else None) if method.startswith('dcf_') else None
                    if method=='dcf_book_return':terminal_pb=1.0
                    rows.append([security,STUDY.params.scenario_id,STUDY.params.valuation_date,year,method,value*conversion if value is not None else None,shares,price,currency,terminal_pb,status,confidence,reason])
            return pl.DataFrame(rows,schema=PAYLOAD,orient='row')
        @view(name=f'{key}.valuation',entity_id=security,inputs=[all_methods],schema=fields(result_schema.VALUATION_SCHEMA,{'diluted_shares':'count','price':'currency_per_unit','terminal_pb':'multiple'}),lineage={k:[all_methods.fields[k]] for k in result_schema.VALUATION_SCHEMA})
        def valuation(inp):return inp[0].filter(pl.col('price').is_not_null()).select(list(result_schema.VALUATION_SCHEMA))
        @view(name=f'{key}.valuation_coverage',entity_id=security,inputs=[all_methods],schema=fields(COVERAGE),lineage={k:[all_methods.fields[k]] for k in COVERAGE})
        def coverage(inp):return inp[0].select(list(COVERAGE))

        def receipts(f,exit_date,target,tax,p,fx):
            values=[]
            for v in f:
                year=int(v['period']);dps=v['dividend']/(v['shares_outstanding']/1e6)*fx*(1-tax)
                # Forecast payment dates; do not allocate past dividend rights to a new buyer.
                for ds,portion in [(date(year,8,31),p['interim_share']),(date(year+1,5,31),1-p['interim_share'])]:
                    if STUDY.params.valuation_date<ds<=exit_date:values.append((ds,dps*portion))
            values.append((exit_date,target));return values

        @view(name=f'{key}.returns_build',entity_id=security,inputs=[valuation,build,assumptions,quote,fx,ratio],schema=fields({**result_schema.RETURNS_SCHEMA,'buy_price_high':pl.Float64,'buy_price_low':pl.Float64,'required_return_high':pl.Float64,'required_return_low':pl.Float64}, {**EXTRA['buy_prices.csv'][2],'total_return':'decimal_ratio','xirr':'decimal_ratio','safety_margin':'decimal_ratio','threshold_price':'currency_per_unit'}),lineage={k:list(valuation.fields.values())+list(build.fields.values())+list(assumptions.fields.values())+[quote.fields.value,fx.fields.value,ratio.fields.value] for k in [*result_schema.RETURNS_SCHEMA,'buy_price_high','buy_price_low','required_return_high','required_return_low']})
        def returns_build(inp):
            vals,f,p,q,fx,ratios=inp;p=p.row(0,named=True);f=f.to_dicts();quote_row=q.filter((pl.col('entity_id')==security)&(pl.col('metric_id')=='close_price')&(pl.col('period_end')==STUDY.params.valuation_date))
            close=quote_row['value'].item() if quote_row.height==1 else None;fx=conversion_rate(key,fx)*ads_ratio(key,security,ratios);rows=[]
            for v in vals.to_dicts():
                if v['target_year']==2026:continue
                exit_date=date(v['target_year'],12,31)
                for basis,tax in [('pre_tax',0),('after_tax',p['dividend_tax'])]:
                    target=v['price'];high=low=irr=total=margin=None
                    if target is not None and target>=0:
                        flows=receipts(f,exit_date,target,tax,p,fx)
                        if any(value>0 for ds,value in flows):
                            high=present_value(STUDY.params.valuation_date,flows,p['required_high']);low=present_value(STUDY.params.valuation_date,flows,p['required_low'])
                            assert isclose(investment_xirr(STUDY.params.valuation_date,high,flows),p['required_high'],abs_tol=1e-9)
                            assert isclose(investment_xirr(STUDY.params.valuation_date,low,flows),p['required_low'],abs_tol=1e-9)
                            if close is not None:irr=investment_xirr(STUDY.params.valuation_date,close,flows);total=sum(v for d,v in flows)/close-1;margin=1-close/low
                    rows.append([security,STUDY.params.scenario_id,STUDY.params.valuation_date,exit_date,v['method'],basis,target,total,irr,low,margin,high,low,p['required_high'],p['required_low']])
            return pl.DataFrame(rows,schema={**result_schema.RETURNS_SCHEMA,'buy_price_high':pl.Float64,'buy_price_low':pl.Float64,'required_return_high':pl.Float64,'required_return_low':pl.Float64},orient='row')
        @view(name=f'{key}.returns',entity_id=security,inputs=[returns_build],schema=fields(result_schema.RETURNS_SCHEMA,{'target_price':'currency_per_unit','total_return':'decimal_ratio','xirr':'decimal_ratio','threshold_price':'currency_per_unit','safety_margin':'decimal_ratio'}),lineage={k:[returns_build.fields[k]] for k in result_schema.RETURNS_SCHEMA})
        def returns(inp):return inp[0].select(list(result_schema.RETURNS_SCHEMA))
        @view(name=f'{key}.buy_prices',entity_id=security,inputs=[returns_build],schema=fields(BUY,EXTRA['buy_prices.csv'][2]),lineage={k:[returns_build.fields[k]] for k in BUY if k!='currency'})
        def buy(inp):return inp[0].with_columns(pl.lit(currency).alias('currency'),pl.col('tax_basis').cast(pl.String)).select(list(BUY))
        @view(name=f'{key}.peer_market',entity_id=security,inputs=[a,counts,quote,fx,op_pars,build,ratio],schema=fields(MARKET,EXTRA['peer_market.csv'][2]),lineage={k:[a.fields.value,counts.fields.value,quote.fields.value,fx.fields.value,ratio.fields.value,*op_pars.fields.values(),*build.fields.values()] for k in MARKET})
        def market(inp):
            a,c,q,fx,p,f,ratios=inp;p=p.row(0,named=True);q=q.filter((pl.col('entity_id')==security)&(pl.col('metric_id')=='close_price')).sort('period_end').row(-1,named=True);shares=latest_share_pool(key,c);exchange=fx.sort('period_end').row(-1,named=True);conversion=conversion_rate(key,fx);ads=ads_ratio(key,security,ratios)
            mv=q['value']*shares['value']/1e6/ads/conversion;net=get(a,'net_parent','2025-12-31')+get(a,'net_parent','2026-06-30','H1')-get(a,'net_parent','2025-06-30','H1')
            if key=='gm':net-=get(a,'fair_value_liability_gain','2025-12-31') or 0;net+=(get(a,'fair_value_liability_gain','2025-06-30','H1') or 0)
            ebit=after_rent_ebit(a,'2026-06-30','H1',key)*2
            ttm_ebit=after_rent_ebit(a,'2025-12-31','FY',key)+after_rent_ebit(a,'2026-06-30','H1',key)-after_rent_ebit(a,'2025-06-30','H1',key)
            if key=='cha':
                # Normalize actual SBC to a recurring expense, never remove it forever.
                ttm_ebit+=get(a,'share_based_comp','2025-12-31')+get(a,'share_based_comp','2026-06-30','H1')-get(a,'share_based_comp','2025-06-30','H1')-p['award_expense']
            attributable=get(a,'net_parent','2026-06-30','H1')/get(a,'net_income','2026-06-30','H1')
            if key=='cha':attributable=get(a,'net_parent','2025-12-31')/get(a,'net_income','2025-12-31')
            normalized=(ttm_ebit-max(ttm_ebit,0)*p['tax'])*attributable
            cash=available_assets(a,key,p);book=get(a,'equity_parent','2026-06-30','AS_OF',True)
            if key=='cha':cash-=get(a,'revenue','2026-06-30','H1')*2*p['operating_cash']*get(a,'equity_parent','2026-06-30','AS_OF')/get(a,'equity','2026-06-30','AS_OF')
            fcfe=f.filter(pl.col('period')=='2026')['fcfe'].item()
            return pl.DataFrame([[security,STUDY.params.scenario_id,STUDY.params.valuation_date,q['period_end'],shares['period_end'],exchange['period_end'],q['value'] if currency=='HKD' else None,shares['value']/1e6/ads,mv,net,mv/net if net>0 else None,mv/book,get(a,'cash_equivalents','2026-06-30','AS_OF'),cash,ebit,(mv-cash)/ttm_ebit if ttm_ebit>0 else None,fcfe/mv,normalized,mv/normalized if normalized>0 else None,ttm_ebit,q['value'],currency,ads]],schema=MARKET,orient='row')
        @view(name=f'{key}.historical_valuation',entity_id=security,inputs=[market],schema=fields(HIST_VAL,EXTRA['historical_valuation.csv'][2]),lineage={k:list(market.fields.values()) for k in HIST_VAL})
        def historical(inp):
            r=inp[0].row(0,named=True)
            return pl.DataFrame([[security,STUDY.params.scenario_id,r['quote_date'].isoformat(),m,r[k],r['trading_price'],'only_current_observation_not_historical_distribution'] for m,k in [('PE','pe_ttm'),('PB','pb_latest')]],schema=HIST_VAL,orient='row')
        @view(name=f'{key}.valuation_evidence',entity_id=security,inputs=[build,assumptions,market],schema=fields(VALUATION_EVIDENCE,EXTRA['valuation_evidence.csv'][2]),lineage={k:list(build.fields.values())+list(assumptions.fields.values())+list(market.fields.values()) for k in VALUATION_EVIDENCE})
        def evidence(inp):
            f,p,m=inp;p=p.row(0,named=True);m=m.row(0,named=True);rows=[]
            for r in f.to_dicts():
                book=r['equity_parent'];roe=r['roe'] if book>0 else None
                for method,v,basis in [('PE_prior',p['pe'],'not_empirical_history_calibrated'),('PB_theory',(roe-p['terminal_growth'])/(p['discount']-p['terminal_growth']) if roe is not None else None,'theory_using_forecast_ROE'),('PB_peer_prior',p['pb_peer'],'not_observed_peer_distribution'),('PB_current',m['pb_latest'],'current_observation_not_history'),('PR_policy',p['pr'],'template_policy_not_empirical_law')]:rows.append([security,STUDY.params.scenario_id,int(r['period']),method,v,basis])
            return pl.DataFrame(rows,schema=VALUATION_EVIDENCE,orient='row')
        return valuation,coverage,returns,buy,market,historical,evidence
    v,c,r,b,m,h,e=create(key,issuer);VALS.append(v);COVERS.append(c);RETURNS.append(r);BUYS.append(b);MARKETS.append(m);HISTORIES.append(h);EVIDENCE.append(e)
valuation=combine('valuation',VALS,result_schema.VALUATION_SCHEMA)
coverage=combine('coverage',COVERS,COVERAGE)
returns=combine('returns',RETURNS,result_schema.RETURNS_SCHEMA)
buy=combine('buy_prices',BUYS,BUY,EXTRA['buy_prices.csv'][2])
market=combine('peer_market',MARKETS,MARKET,EXTRA['peer_market.csv'][2])
history=combine('historical_valuation',HISTORIES,HIST_VAL,EXTRA['historical_valuation.csv'][2])
evidence=combine('valuation_evidence',EVIDENCE,VALUATION_EVIDENCE,EXTRA['valuation_evidence.csv'][2])
