"""Evaluate a requested view in memory, then use the engine's inspector."""
import sys
from mid_term_capital.view_engine import show as engine_show
from mid_term_capital.view_engine.calculate import Runner, dependency_order
from mid_term_capital.view_engine.view import DEFAULT_REGISTRY
from deep_study import ROOT, STUDY
from deep_tables import RESULT_TABLES  # noqa: F401: registration only

def main():
    requested=sys.argv[1] if len(sys.argv)>1 else None
    if requested and requested!='params' and not requested.startswith('-'):
        target=DEFAULT_REGISTRY[requested];runner=Runner(STUDY,lambda _:None)
        for instance in dependency_order([target]):runner.run_view(instance)
    return engine_show.main([*sys.argv[1:],'--study',str(ROOT/'model/main.py')])
if __name__=='__main__':raise SystemExit(main())
