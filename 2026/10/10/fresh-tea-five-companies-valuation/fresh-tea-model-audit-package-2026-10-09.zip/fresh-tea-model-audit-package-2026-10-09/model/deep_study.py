"""Four listed issuers sharing one fact and parameter library."""
from pathlib import Path
from mid_term_capital.view_engine import loader
from metrics import FACT_FILES, FACTS

ROOT=Path(__file__).resolve().parents[1]
STUDY=loader.bind(ROOT,FACT_FILES,FACTS)
if STUDY.params.scenario_id not in ['deep_bear','deep_base','deep_bull']:
    raise ValueError('Current industry model requires deep_bear/base/bull; old general results are preserved. Set params/run.csv or run model/run_deep.py.')
COMPANIES={'gm':('古茗','01364'),'mx':('蜜雪集团','02097'),'cb':('茶百道','02555'),'ny':('奈雪的茶','02150'),'cha':('霸王茶姬','CHA')}
ISSUERS={k:f'issuer:{"蜜雪冰城" if k=="mx" else name}_{ticker}' for k,(name,ticker) in COMPANIES.items()}
SECURITIES={k:f'security:{"蜜雪冰城" if k=="mx" else name}_{ticker}.HK' for k,(name,ticker) in COMPANIES.items()}
SECURITIES['cha']='security:霸王茶姬_CHA.ADS'
YEARS=range(2026,2037)
NODES={2026,2027,2028,2029,2030,2031,2033,2036}

def get(frame,metric,ds,pt='FY',required=False):
    from datetime import date
    import polars as pl
    f=frame.filter((pl.col('metric_id')==metric)&(pl.col('period_end')==date.fromisoformat(ds))&(pl.col('period_type')==pt))
    if f.is_empty():
        if required:raise KeyError((metric,ds,pt))
        return None
    assert f.height==1
    return f['value'].item()

def latest_share_pool(key,counts,upper_bound=None):
    """Derive a common pool from directly disclosed class counts when newer."""
    from datetime import date
    import polars as pl
    limit=upper_bound or STUDY.params.valuation_date
    selected=counts.filter((pl.col('entity_id')==SECURITIES[key])&(pl.col('period_end')<=limit))
    total=selected.filter(pl.col('metric_id')=='shares_outstanding').sort('period_end').row(-1,named=True)
    if key=='cha':
        ca=selected.filter(pl.col('metric_id')=='shares_outstanding_class_a')
        cb=selected.filter(pl.col('metric_id')=='shares_outstanding_class_b')
        dates=set(ca['period_end'])&set(cb['period_end'])
        if dates and max(dates)>total['period_end']:
            ds=max(dates)
            value=ca.filter(pl.col('period_end')==ds)['value'].item()+cb.filter(pl.col('period_end')==ds)['value'].item()
            total={**total,'value':value,'period_end':ds}
    return total
