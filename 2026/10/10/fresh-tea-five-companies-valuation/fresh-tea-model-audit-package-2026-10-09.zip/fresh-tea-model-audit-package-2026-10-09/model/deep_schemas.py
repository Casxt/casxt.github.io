"""Promoted research outputs registered alongside the framework schemas."""
import polars as pl
from mid_term_capital.view_engine import Field, result_schema
from schemas import SCALE_SCHEMA, SCALE_KEY, SCALE_UNITS

def fields(schema, units=None):
    return {k:Field(t,(units or {}).get(k, 'count' if t in [pl.Int32,pl.Int64] else 'currency' if t==pl.Float64 else None),'行业研究：'+k+'；长表value实际物理单位由metric_id或unit列定义') for k,t in schema.items()}

COVERAGE={'entity_id':pl.String,'scenario':pl.String,'valuation_date':pl.Date,'target_year':pl.Int32,'method':pl.String,'status':pl.String,'confidence':pl.String,'reason':pl.String}
BUY={'entity_id':pl.String,'scenario':pl.String,'valuation_date':pl.Date,'exit_date':pl.Date,'method':pl.String,'tax_basis':pl.String,'currency':pl.String,'target_price':pl.Float64,'buy_price_high':pl.Float64,'buy_price_low':pl.Float64,'required_return_high':pl.Float64,'required_return_low':pl.Float64}
STORE={'entity_id':pl.String,'scenario':pl.String,'valuation_date':pl.Date,'period':pl.String,'segment_id':pl.String,'metric_id':pl.String,'value':pl.Float64,'unit':pl.String,'basis':pl.String}
SENS={'entity_id':pl.String,'scenario':pl.String,'period':pl.String,'key_variable_id':pl.String,'shock':pl.String,'reference_basis':pl.String,'reference_profit':pl.Float64,'delta_profit':pl.Float64,'delta_ratio':pl.Float64}
MARKET={'entity_id':pl.String,'scenario':pl.String,'valuation_date':pl.Date,'quote_date':pl.Date,'shares_date':pl.Date,'fx_date':pl.Date,'price_hkd':pl.Float64,'shares_million':pl.Float64,'market_cap_cny':pl.Float64,'ttm_net_parent':pl.Float64,'pe_ttm':pl.Float64,'pb_latest':pl.Float64,'cash_equivalents':pl.Float64,'available_net_financial_assets':pl.Float64,'lease_adjusted_ebit':pl.Float64,'ev_ebit':pl.Float64,'fcfe_yield':pl.Float64}
MARKET.update(normalized_ttm_profit=pl.Float64,pe_normalized=pl.Float64,normalized_ttm_ebit=pl.Float64,trading_price=pl.Float64,currency=pl.String,ordinary_per_traded_unit=pl.Float64)
HIST_VAL={'entity_id':pl.String,'scenario':pl.String,'period':pl.String,'method':pl.String,'multiple':pl.Float64,'price':pl.Float64,'basis':pl.String}
VALUATION_EVIDENCE={'entity_id':pl.String,'scenario':pl.String,'target_year':pl.Int32,'method':pl.String,'input_value':pl.Float64,'basis':pl.String}
MECHANISM={'entity_id':pl.String,'scenario':pl.String,'period':pl.String,'test_id':pl.String,'reference_profit':pl.Float64,'reference_fcfe':pl.Float64,'delta_profit':pl.Float64,'delta_fcfe':pl.Float64,'delta_revenue':pl.Float64,'delta_gmv':pl.Float64,'incremental_capex':pl.Float64,'conditional_payback_years':pl.Float64,'basis':pl.String}
CURRENCY_RETURN={'entity_id':pl.String,'scenario':pl.String,'valuation_date':pl.Date,'exit_date':pl.Date,'method':pl.String,'tax_basis':pl.String,'currency':pl.String,'fx_basis':pl.String,'quote_cost':pl.Float64,'target_price':pl.Float64,'buy_price_high':pl.Float64,'buy_price_low':pl.Float64,'xirr':pl.Float64}
ADS_PRESSURE={'entity_id':pl.String,'scenario':pl.String,'target_year':pl.Int32,'method':pl.String,'forecast_ordinary_shares':pl.Float64,'full_pool_floor_shares':pl.Float64,'base_price':pl.Float64,'pool_floor_price':pl.Float64,'price_change':pl.Float64,'currency':pl.String,'basis':pl.String}
EXTRA={
 'valuation_coverage.csv':(COVERAGE,tuple(list(COVERAGE)[:5]),{}),
 'buy_prices.csv':(BUY,tuple(list(BUY)[:6]),{k:'decimal_ratio' if k.startswith('required') else 'currency_per_unit' for k,t in BUY.items() if t==pl.Float64}),
 'store_economics.csv':(STORE,tuple(list(STORE)[:6]),{'value':'currency'}),
 'key_variable_sensitivity.csv':(SENS,('entity_id','scenario','period','key_variable_id'),{'reference_profit':'currency','delta_profit':'currency','delta_ratio':'decimal_ratio'}),
 'peer_market.csv':(MARKET,('entity_id','scenario','valuation_date'),{k:('currency_per_unit' if k in ['price_hkd','trading_price'] else 'count' if k=='shares_million' else 'multiple' if k in ['pe_ttm','pb_latest','ev_ebit','pe_normalized'] else 'decimal_ratio' if k in ['fcfe_yield','ordinary_per_traded_unit'] else 'currency') for k,t in MARKET.items() if t==pl.Float64}),
 'historical_valuation.csv':(HIST_VAL,('entity_id','scenario','period','method'),{'multiple':'multiple','price':'currency_per_unit'}),
 'valuation_evidence.csv':(VALUATION_EVIDENCE,('entity_id','scenario','target_year','method'),{'input_value':'multiple'}),
 'scale_check.csv':(SCALE_SCHEMA,SCALE_KEY,SCALE_UNITS),
 'chagee_mechanism_tests.csv':(MECHANISM,('entity_id','scenario','period','test_id'),{'conditional_payback_years':'multiple'}),
 'currency_returns.csv':(CURRENCY_RETURN,('entity_id','scenario','valuation_date','exit_date','method','tax_basis','currency','fx_basis'),{k:'decimal_ratio' if k=='xirr' else 'currency_per_unit' for k,t in CURRENCY_RETURN.items() if t==pl.Float64}),
 'ads_pool_pressure.csv':(ADS_PRESSURE,('entity_id','scenario','target_year','method'),{'forecast_ordinary_shares':'count','full_pool_floor_shares':'count','base_price':'currency_per_unit','pool_floor_price':'currency_per_unit','price_change':'decimal_ratio'}),
}
for name,(schema,key,units) in EXTRA.items():result_schema.register(name,schema,key)
