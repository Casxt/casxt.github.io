"""Unique calculation entry point; business logic lives in declared views."""
from mid_term_capital.view_engine import calculate
from deep_study import STUDY
from deep_tables import RESULT_TABLES
if __name__=='__main__':calculate.calculate(STUDY, RESULT_TABLES)
