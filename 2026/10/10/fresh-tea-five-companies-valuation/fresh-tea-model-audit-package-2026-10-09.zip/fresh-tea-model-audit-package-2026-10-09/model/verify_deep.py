"""Independent disclosed identities and meaningful financial model acceptance checks."""
from hashlib import sha256
from math import isclose
from pathlib import Path
from datetime import date
import subprocess,sys
import polars as pl
from mid_term_capital.view_engine import result_schema
from mid_term_capital.view_engine.calculate import dependency_order,Runner
from mid_term_capital.view_engine.view import DEFAULT_REGISTRY
from deep_study import STUDY,ROOT,ISSUERS,SECURITIES,get
from deep_tables import RESULT_TABLES
from deep_operating import ISSUER_VIEWS
from deep_valuation import METHODS

def main():
    facts=STUDY.all_facts();_=STUDY.params;_=STUDY.entity_meta;_=STUDY.data_gaps
    assert facts.select('entity_id','metric_id','period_end','period_type').unique().height==facts.height
    for source in STUDY.sources.to_dicts():
        path=ROOT/source['file_path'];assert path.is_file(),source['source_id'];assert sha256(path.read_bytes()).hexdigest()==source['file_sha256'],source['source_id']
    a=STUDY.fact_frame('amounts');c=STUDY.fact_frame('counts');identities=0
    for key,entity in ISSUERS.items():
        f=a.filter(pl.col('entity_id')==entity)
        for ds,pt in [('2025-12-31','FY'),('2025-06-30','H1'),('2026-06-30','H1')]:
            pbt=get(f,'profit_before_tax',ds,pt,True);tax=get(f,'tax_expense',ds,pt,True);profit=get(f,'net_income',ds,pt,True)
            assert isclose(pbt-tax,profit,abs_tol=.001),(key,ds,'PBT-tax=profit');identities+=1
        for ds in ['2025-12-31','2026-06-30']:
            assets=get(f,'assets',ds,'AS_OF')
            if assets is None:assets=get(f,'assets_current',ds,'AS_OF',True)+get(f,'assets_noncurrent',ds,'AS_OF',True)
            liabilities=get(f,'liabilities',ds,'AS_OF')
            if liabilities is None:liabilities=get(f,'liabilities_current',ds,'AS_OF',True)+get(f,'liabilities_noncurrent',ds,'AS_OF',True)
            assert isclose(assets,liabilities+get(f,'equity',ds,'AS_OF',True),abs_tol=.001),(key,ds,'A=L+E');identities+=1
    cb=c.filter(pl.col('entity_id')==ISSUERS['cb']);assert get(cb,'franchised_stores_domestic','2025-12-31','AS_OF')+get(cb,'stores_opened','2026-06-30','H1')-get(cb,'stores_closed','2026-06-30','H1')==get(cb,'franchised_stores_domestic','2026-06-30','AS_OF')
    ny=c.filter(pl.col('entity_id')==ISSUERS['ny'])
    for ds in ['2024-12-31','2025-12-31','2026-06-30']:assert get(ny,'owned_stores',ds,'AS_OF')+get(ny,'franchised_stores',ds,'AS_OF')==get(ny,'stores',ds,'AS_OF')
    base_hash=None
    for scenario in ['deep_bear','deep_base','deep_bull']:
        folder=ROOT/'results'/scenario
        for table in RESULT_TABLES:
            df=result_schema.read_result(folder/table.filename);assert df.select(table.key).unique().height==df.height,(scenario,table.filename)
            for col,dtype in df.schema.items():
                if dtype==pl.Float64:assert df[col].drop_nulls().is_finite().all(),(scenario,table.filename,col)
        hist=(folder/'history_facts.csv').read_bytes()
        if base_hash is None:base_hash=hist
        assert base_hash==hist,'Historical data changed with scenario'
        f=result_schema.read_result(folder/'forecast.csv');assert set(f['entity_id'])==set(ISSUERS.values());assert set(f['period'])==set(map(str,range(2026,2037)))
        assert set(f.filter(pl.col('period')=='2026')['basis'].cast(pl.String))=={'estimate'}
        assert set(f.filter(pl.col('period').is_in(['2032','2034','2035']))['node_type'].cast(pl.String))=={'interpolated'}
        v=result_schema.read_result(folder/'valuation.csv');assert ((v['equity_value']/v['diluted_shares']-v['price']).abs()<1e-8).all()
        coverage=result_schema.read_result(folder/'valuation_coverage.csv');assert coverage.height==len(ISSUERS)*11*len(METHODS);assert set(coverage['method'])==set(METHODS)
        assert coverage.filter(pl.col('method')=='SOTP')['status'].unique().to_list()==['not_applicable']
        b=result_schema.read_result(folder/'buy_prices.csv');positive=b.filter(pl.col('buy_price_low').is_not_null());assert (positive['buy_price_high']<=positive['buy_price_low']).all()
        m=result_schema.read_result(folder/'peer_market.csv');assert set(m['quote_date'])=={date(2026,10,9)};assert set(m['valuation_date'])=={date(2026,10,9)}
        for metric in ['normal_net_parent','fcfe','revenue','equity_parent','shares_outstanding']:
            assert f.filter(pl.col('metric_id')==metric).height==len(ISSUERS)*11,metric
    for instance in DEFAULT_REGISTRY:
        for field,declaration in instance.field_declarations.items():
            if declaration.unit and not instance.source:assert instance.declared_lineage(field),(instance.name,field)
    # Cash reconciling model source of Y0 is June30, not FY2025 plus six months twice.
    runner=Runner(STUDY,lambda _:None)
    for key,item in ISSUER_VIEWS.items():
        for instance in dependency_order([item['build']]):runner.run_view(instance)
    # Check deterministic output bytes by invoking the sole entry twice.
    before={t.filename:sha256((ROOT/'results/deep_base'/t.filename).read_bytes()).hexdigest() for t in RESULT_TABLES}
    for _ in range(2):subprocess.run([sys.executable,str(ROOT/'model/main.py')],stdout=subprocess.DEVNULL,check=True)
    after={t.filename:sha256((ROOT/'results/deep_base'/t.filename).read_bytes()).hexdigest() for t in RESULT_TABLES};assert before==after,'Non-deterministic outputs'
    # The independently disclosed rent-adjusted cash deficit must survive the report tables.
    store=result_schema.read_result(ROOT/'results/deep_base/store_economics.csv').filter((pl.col('entity_id')==ISSUERS['ny'])&(pl.col('metric_id')=='cfo_less_all_capex_and_lease'))
    assert store.filter(pl.col('period')=='2025-12-31')['value'].item()<0
    assert store.filter(pl.col('period')=='2026-06-30')['value'].item()<0
    from verify_chagee import main as verify_chagee
    verify_chagee()
    print(f'PASS: {facts.height} facts, {STUDY.sources.height} source hashes, {identities} independent financial identities; five issuers, three scenarios, 2026-2036; {len(RESULT_TABLES)} schemas; full method coverage, exact buy-price XIRR assertions, numeric lineage, identical history and deterministic outputs')

if __name__=='__main__':main()
