"""Only promoted tables cited by the reports; no intermediate exports."""
import polars as pl
from mid_term_capital.view_engine import Field, result_schema
from mid_term_capital.view_engine.loader import PERIOD_TYPE

def fields(schema, units):
    return {k: Field(t, units.get(k), k if k not in units else f'{k}；单位{units[k]}，精确口径见研究README') for k,t in schema.items()}
PEER_SCHEMA = {'entity_id':pl.String,'period_end':pl.Date,'period_type':PERIOD_TYPE,'revenue':pl.Float64,'gross_margin':pl.Float64,'net_parent':pl.Float64,'net_income':pl.Float64,'core_ebit':pl.Float64,'normalized_parent':pl.Float64,'cfo':pl.Float64,'cash_equivalents':pl.Float64,'strict_net_cash':pl.Float64,'cash_with_restricted':pl.Float64,'lease_liabilities':pl.Float64}
PEER_KEY=('entity_id','period_end','period_type')
PEER_UNITS={k:'currency' for k,t in PEER_SCHEMA.items() if t==pl.Float64};PEER_UNITS['gross_margin']='decimal_ratio'
OPERATING_SCHEMA={'entity_id':pl.String,'scenario':pl.String,'period':pl.String,'stores_end':pl.Float64,'average_stores':pl.Float64,'owned_gmv_share':pl.Float64,'core_ebit_margin':pl.Float64}
OPERATING_KEY=('entity_id','scenario','period')
OPERATING_UNITS={'stores_end':'count','average_stores':'count','owned_gmv_share':'decimal_ratio','core_ebit_margin':'decimal_ratio'}
MARKET_SCHEMA={'entity_id':pl.String,'valuation_date':pl.Date,'price_date':pl.Date,'share_date':pl.Date,'fx_date':pl.Date,'currency':pl.String,'share_basis':pl.String,'close_price':pl.Float64,'shares_million':pl.Float64,'market_value_cny':pl.Float64,'ttm_normalized_parent':pl.Float64,'ttm_core_ebit':pl.Float64,'pe_normalized':pl.Float64,'ev_ebit_strict_cash':pl.Float64,'ev_ebit_with_restricted':pl.Float64}
MARKET_KEY=('entity_id','valuation_date')
MARKET_UNITS={k:'currency' for k in ['market_value_cny','ttm_normalized_parent','ttm_core_ebit']}
MARKET_UNITS.update(close_price='currency_per_unit',shares_million='count',pe_normalized='multiple',ev_ebit_strict_cash='multiple',ev_ebit_with_restricted='multiple')
SENS_SCHEMA={'entity_id':pl.String,'scenario':pl.String,'key_variable_id':pl.String,'metric_id':pl.String,'period':pl.String,'shock':pl.String,'reference_profit':pl.Float64,'delta_profit':pl.Float64,'delta_ratio':pl.Float64}
SENS_KEY=('entity_id','scenario','key_variable_id','metric_id','period')
SENS_UNITS={'reference_profit':'currency','delta_profit':'currency','delta_ratio':'decimal_ratio'}
SCALE_SCHEMA={'entity_id':pl.String,'metric_id':pl.String,'period_end':pl.Date,'period_type':PERIOD_TYPE,'value':pl.Float64,'scale':pl.Float64,'scale_metric_id':pl.String,'ratio':pl.Float64,'threshold':pl.Float64,'exceeded':pl.Boolean}
SCALE_KEY=('entity_id','metric_id','period_end','period_type')
SCALE_UNITS={'value':'currency','scale':'currency','ratio':'decimal_ratio','threshold':'decimal_ratio'}
EXTRA={'peer_comparison.csv':(PEER_SCHEMA,PEER_KEY,PEER_UNITS),'operating_outlook.csv':(OPERATING_SCHEMA,OPERATING_KEY,OPERATING_UNITS),'peer_market.csv':(MARKET_SCHEMA,MARKET_KEY,MARKET_UNITS),'key_variable_sensitivity.csv':(SENS_SCHEMA,SENS_KEY,SENS_UNITS),'scale_check.csv':(SCALE_SCHEMA,SCALE_KEY,SCALE_UNITS)}
for name,(schema,key,units) in EXTRA.items():result_schema.register(name,schema,key)
POOL_SCHEMA={'entity_id':pl.String,'scenario':pl.String,'base_period':pl.String,'market_gmv':pl.Float64,'realization':pl.Float64,'operating_margin':pl.Float64,'estimated_store_operating_profit':pl.Float64}
POOL_KEY=('entity_id','scenario','base_period')
POOL_UNITS={'market_gmv':'currency','realization':'decimal_ratio','operating_margin':'decimal_ratio','estimated_store_operating_profit':'currency'}
CAPITAL_SCHEMA={'entity_id':pl.String,'event_id':pl.String,'event_date':pl.Date,'new_shares':pl.Float64,'existing_shares':pl.Float64,'potential_dilution':pl.Float64,'nominal_discount_cost_cny':pl.Float64,'annual_equivalent_cny':pl.Float64}
CAPITAL_KEY=('entity_id','event_id','event_date')
CAPITAL_UNITS={'new_shares':'count','existing_shares':'count','potential_dilution':'decimal_ratio','nominal_discount_cost_cny':'currency','annual_equivalent_cny':'currency'}
OP_HISTORY_SCHEMA={'entity_id':pl.String,'period_end':pl.Date,'period_type':PERIOD_TYPE,'stores_end':pl.Float64,'average_stores_estimate':pl.Float64,'hq_revenue_per_average_store':pl.Float64,'owned_revenue_share':pl.Float64,'gmv':pl.Float64,'per_store_gmv_reported':pl.Float64,'hq_revenue_yoy':pl.Float64,'hq_rps_yoy':pl.Float64,'gmv_yoy':pl.Float64,'per_store_gmv_yoy':pl.Float64,'owned_revenue_yoy':pl.Float64}
OP_HISTORY_KEY=('entity_id','period_end','period_type')
OP_HISTORY_UNITS={'stores_end':'count','average_stores_estimate':'count','hq_revenue_per_average_store':'currency_per_unit','owned_revenue_share':'decimal_ratio','gmv':'currency','per_store_gmv_reported':'currency','hq_revenue_yoy':'decimal_ratio','hq_rps_yoy':'decimal_ratio','gmv_yoy':'decimal_ratio','per_store_gmv_yoy':'decimal_ratio','owned_revenue_yoy':'decimal_ratio'}
for name,schema,key,units in [('industry_profit_pool.csv',POOL_SCHEMA,POOL_KEY,POOL_UNITS),('capital_effects.csv',CAPITAL_SCHEMA,CAPITAL_KEY,CAPITAL_UNITS),('operating_history.csv',OP_HISTORY_SCHEMA,OP_HISTORY_KEY,OP_HISTORY_UNITS)]:
    EXTRA[name]=(schema,key,units);result_schema.register(name,schema,key)
MIX_SCHEMA={'entity_id':pl.String,'period_end':pl.Date,'period_type':PERIOD_TYPE,'segment_id':pl.String,'revenue':pl.Float64,'revenue_share':pl.Float64,'gross_profit_estimate':pl.Float64,'gross_profit_share_estimate':pl.Float64,'profit_basis':pl.String}
MIX_KEY=('entity_id','period_end','period_type','segment_id')
MIX_UNITS={'revenue':'currency','revenue_share':'decimal_ratio','gross_profit_estimate':'currency','gross_profit_share_estimate':'decimal_ratio'}
EXTRA['business_mix.csv']=(MIX_SCHEMA,MIX_KEY,MIX_UNITS);result_schema.register('business_mix.csv',MIX_SCHEMA,MIX_KEY)
