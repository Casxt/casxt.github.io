"""Mixed network demand, composite franchise realization and owned-store cash."""
from math import isclose
from datetime import date
import polars as pl
from deep_study import STUDY, NODES, YEARS, get, latest_share_pool

CHA_PARAMS=['h2_growth','store_growth','productivity_growth','fixed_growth','tax','maintenance','expansion','depreciation_rate','working_capital','payout','share_change','award_expense','financial_realization','operating_cash','shock_sales','shock_margin','shock_fixed','cha_take','cha_h1_da','cha_h1_investment','cha_shock_owned','cha_owned_gmv_share','cha_owned_realization','cha_owned_material_ratio']
MIXED_UNITS={k:'currency' for k in ['gmv','franchise_revenue','owned_revenue','franchise_contribution','owned_contribution','h1_actual_cfo','h2_estimated_fcfe','maintenance_capex','expansion_capex']}
MIXED_UNITS.update(owned_gmv_share='decimal_ratio',composite_franchise_take='decimal_ratio',owned_stores='count',owned_gmv_per_store_relative='multiple',cash_earnings_attribution='decimal_ratio')

def cha_param(entity,p,y):
    pid=p if p.startswith('cha_owned') else 'deep_'+p
    if p=='h2_growth':y=2026
    try:return STUDY.params.resolve(entity,pid,str(y),STUDY.params.scenario_id)
    except KeyError:
        if p not in ['store_growth','productivity_growth','fixed_growth','cha_take','cha_owned_gmv_share']:raise
        lo=max(n for n in NODES if n<y);hi=min(n for n in NODES if n>y)
        a=STUDY.params.resolve(entity,pid,str(lo),STUDY.params.scenario_id)
        b=STUDY.params.resolve(entity,pid,str(hi),STUDY.params.scenario_id)
        return a+(b-a)*(y-lo)/(hi-lo)

def calibration(a,c,p):
    h=lambda m:get(a,m,'2026-06-30','H1',True)
    gmv=get(a,'gmv_q1','2026-03-31','Q1',True)+h('gmv_q2')
    owned_gmv=h('owned_revenue')/p['cha_owned_realization']
    franch_gmv=gmv-owned_gmv
    # Absolute raw-material cost per franchise terminal GMV stays fixed in V3 tests.
    # Changing composite receipts does not automatically reduce the material bill.
    material_per_gmv=(h('material_cost')-h('owned_revenue')*p['cha_owned_material_ratio'])/franch_gmv
    owned_cash_ratio=(h('owned_operating_cost')-p['cha_h1_da'])/h('owned_revenue')
    fixed=h('other_operating_cost')+h('selling_expense')+h('admin_expense')-h('share_based_comp')
    contribution=h('revenue')-h('material_cost')-h('owned_operating_cost')+p['cha_h1_da']
    assert isclose(contribution-fixed-p['cha_h1_da']-h('share_based_comp'),h('operating_profit_reported'),abs_tol=1e-6)
    mean=lambda metric:(get(c,metric,'2025-12-31','AS_OF',True)+get(c,metric,'2026-06-30','AS_OF',True))/2
    relative=(owned_gmv/mean('owned_stores'))/(franch_gmv/mean('franchised_stores'))
    assert 0<material_per_gmv<1 and 0<owned_cash_ratio<1 and relative>0
    return dict(gmv=gmv,owned_gmv=owned_gmv,franch_gmv=franch_gmv,material_per_gmv=material_per_gmv,owned_cash_ratio=owned_cash_ratio,fixed=fixed,contribution=contribution,franchise_contribution=h('franchise_revenue')-franch_gmv*material_per_gmv,owned_contribution=h('owned_revenue')*(1-p['cha_owned_material_ratio']-owned_cash_ratio),relative=relative)

def simulate_mixed(issuer,a,c,security_counts,params,internal):
    from deep_operating import available_assets
    h=lambda m:get(a,m,'2026-06-30','H1',True)
    cal=calibration(a,c,params[0]);p0=params[0]
    begin=get(c,'stores','2025-12-31','AS_OF',True);mid=get(c,'stores','2026-06-30','AS_OF',True)
    owned_begin=get(c,'owned_stores','2026-06-30','AS_OF',True)
    ppe=get(a,'ppe','2026-06-30','AS_OF',True)+get(a,'intangible_assets','2026-06-30','AS_OF',True)
    equity=get(a,'equity_parent','2026-06-30','AS_OF',True)
    pool=latest_share_pool('cha',security_counts,date(2026,6,30));sh=pool['value']
    # Advance only the gap after the latest directly disclosed class pool.
    elapsed_shares=(date(2026,6,30)-pool['period_end']).days/365
    sh*=1+p0['share_change']*elapsed_shares
    cash_share=get(a,'equity_parent','2026-06-30','AS_OF',True)/get(a,'equity','2026-06-30','AS_OF',True)
    cash=available_assets(a,'cha',p0)-h('revenue')*2*p0['operating_cash']*cash_share
    wc=h('revenue')*2*p0['working_capital'];previous_average=None;previous_gmv=None;rows=[]
    attribution=get(a,'net_parent','2025-12-31','FY',True)/get(a,'net_income','2025-12-31','FY',True)
    # Annual attribution avoids multiplying forecast earnings by a loss-making NCI ratio >1.
    for p in params:
        y=p['year'];share=p['cha_owned_gmv_share'];realize=p['cha_owned_realization']
        assert 0<=share<=.5
        end=mid*(1+p['store_growth']/2) if y==2026 else begin*(1+p['store_growth'])
        average=(begin+2*mid+end)/4 if y==2026 else (begin+end)/2
        if y==2026:
            old_h1=get(a,'gmv_q1','2025-03-31','Q1',True)+get(a,'gmv_q2','2025-06-30','H1',True)
            h2_gmv=(get(a,'gmv','2025-12-31','FY',True)-old_h1)*(1+p['h2_growth'])
            gmv=cal['gmv']+h2_gmv;future_gmv=h2_gmv;elapsed=.5
        else:
            gmv=previous_gmv*average/previous_average*(1+p['productivity_growth']);future_gmv=gmv;elapsed=1
        # Each terminal sale enters exactly one channel; conversions create no new demand.
        franch= future_gmv*(1-share)*p['cha_take']
        owned=future_gmv*share*realize
        fc=future_gmv*(1-share)*(p['cha_take']-cal['material_per_gmv'])
        oc=owned*(1-p['cha_owned_material_ratio']-cal['owned_cash_ratio'])
        annual_fixed=cal['fixed']*(2+p['fixed_growth']/2) if y==2026 else annual_fixed*(1+p['fixed_growth'])
        contribution=cal['contribution']+fc+oc if y==2026 else fc+oc
        revenue=h('revenue')+franch+owned if y==2026 else franch+owned
        # Endpoint count is a capital proxy using the estimated per-store GMV mix;
        # actual annual channel weights are not disclosed and remain a high-priority gap.
        owned_end=end*share/(cal['relative']*(1-share)+share)
        owned_end=max(owned_end,owned_begin) if y==2026 else owned_end
        maintenance=future_gmv*((1-share)*p['cha_take']+share*realize)*p['maintenance']
        expansion=max(owned_end-owned_begin,0)*p['expansion']
        future_capex=maintenance+expansion
        capex=p['cha_h1_investment']+future_capex if y==2026 else future_capex
        future_da=ppe*p['depreciation_rate']*elapsed
        depreciation=p['cha_h1_da']+future_da if y==2026 else future_da
        future_award=p['award_expense']*elapsed
        award=h('share_based_comp')+future_award if y==2026 else future_award
        ebit=contribution-annual_fixed-depreciation-award
        ni=ebit-max(ebit,0)*p['tax'];net=ni*attribution
        h1_normal=(h('operating_profit_reported')-max(h('operating_profit_reported'),0)*p['tax'])*attribution
        state_net=net-h1_normal if y==2026 else net
        wc_new=revenue*p['working_capital'];delta_wc=wc_new-wc
        remaining_fcfe=state_net+(future_da+future_award-future_capex-delta_wc)*attribution
        # Actual H1 cash is used once. The missing investment is an explicit prior.
        fcfe=(h('cfo')-p['cha_h1_investment'])*attribution+remaining_fcfe if y==2026 else remaining_fcfe
        # Future hypothetical annual dividends are all paid next May (interim_share=0).
        dividend=min(max(net,0)*p['payout'],max(cash+remaining_fcfe,0))
        cash_new=cash+remaining_fcfe-dividend
        equity_new=equity+state_net+future_award*attribution-dividend
        ppe_new=ppe+future_capex-future_da;shares_new=sh*(1+p['share_change']*elapsed)
        assert isclose(cash_new-cash,remaining_fcfe-dividend,abs_tol=1e-6)
        assert isclose(equity_new-equity,state_net+future_award*attribution-dividend,abs_tol=1e-6)
        assert isclose(ppe_new-ppe,future_capex-future_da,abs_tol=1e-6)
        assert end>0 and revenue>0 and ppe_new>=0
        annual_owned=h('owned_revenue')+owned if y==2026 else owned
        annual_franch=h('franchise_revenue')+franch if y==2026 else franch
        assert isclose(annual_franch+annual_owned,revenue,abs_tol=1e-6)
        annual_fc=cal['franchise_contribution']+fc if y==2026 else fc
        annual_oc=cal['owned_contribution']+oc if y==2026 else oc
        rows.append(dict(entity_id=issuer,scenario=STUDY.params.scenario_id,period=str(y),node_type='explicit' if y in NODES else 'interpolated',revenue=revenue,stores=end,average_stores=average,core_ebit=ebit,normal_net_parent=net,net_parent=net,net_income=ni,fcfe=fcfe,dividend=dividend,equity_parent=equity_new,shares_outstanding=shares_new,net_financial_assets=cash_new,owned_capital_base=ppe_new,capex=capex,depreciation=depreciation,working_capital=wc_new,contribution=contribution,fixed_cost=annual_fixed,cash_deficit=max(-cash_new,0),eps=net/(shares_new/1e6),dps=dividend/(shares_new/1e6),bvps=equity_new/(shares_new/1e6),roe=net/((equity+equity_new)/2),gmv=gmv,franchise_revenue=annual_franch,owned_revenue=annual_owned,franchise_contribution=annual_fc,owned_contribution=annual_oc,h1_actual_cfo=h('cfo') if y==2026 else None,h2_estimated_fcfe=remaining_fcfe if y==2026 else None,maintenance_capex=maintenance,expansion_capex=expansion,owned_gmv_share=(cal['owned_gmv']+future_gmv*share)/gmv if y==2026 else share,composite_franchise_take=p['cha_take'],owned_stores=owned_end,owned_gmv_per_store_relative=cal['relative'],cash_earnings_attribution=attribution))
        begin=end;owned_begin=owned_end;ppe=ppe_new;equity=equity_new;cash=cash_new;sh=shares_new;wc=wc_new;previous_gmv=gmv;previous_average=average
    return pl.DataFrame(rows,schema={**internal,**{k:pl.Float64 for k in MIXED_UNITS}})

def mixed_sensitivity(issuer,a,c,cs,p,f,schema,internal):
    base=f.filter(pl.col('period')=='2031').row(0,named=True);rows=[]
    denominator=base['normal_net_parent'] if base['normal_net_parent']>0 else base['contribution']
    basis='2031正常税后经营利润' if base['normal_net_parent']>0 else '2031变动成本后集团贡献；正常利润非正'
    test=p.filter(pl.col('year')==2031).row(0,named=True)
    options=[('V2','productivity_growth',test['shock_sales']),('V3','cha_take',test['shock_margin']),('V6','cha_owned_gmv_share',test['cha_shock_owned']),('V7','fixed_growth',-test['shock_fixed'])]
    for variable,metric,shock in options:
        for sign,suffix in [(1,'up'),(-1,'down')]:
            ps=p.to_dicts();idx=[r['year'] for r in ps].index(2031);ps[idx]=dict(ps[idx]);actual=shock*sign
            if variable in ['V2','V7']:ps[idx][metric]=(1+ps[idx][metric])*(1+actual)-1
            else:ps[idx][metric]+=actual
            new=simulate_mixed(issuer,a,c,cs,ps,internal).filter(pl.col('period')=='2031').row(0,named=True)
            if variable in ['V3','V6']:assert isclose(new['gmv'],base['gmv'],abs_tol=1e-6)
            delta=new['normal_net_parent']-base['normal_net_parent']
            rows.append([issuer,STUDY.params.scenario_id,'2031',variable+'_'+suffix,f'{metric} {actual:+.3f}',basis,denominator,delta,delta/denominator])
    return pl.DataFrame(rows,schema=schema,orient='row')
