"""After-rent operating model; no invented same-store or franchise net receipts."""
from datetime import date
from math import isclose
import polars as pl
from mid_term_capital.view_engine import ALL, Field, view, result_schema
from mid_term_capital.view_engine.loader import FACT_SCHEMA
from deep_study import STUDY, ISSUERS, SECURITIES, YEARS, NODES, get
from deep_schemas import fields, STORE, SENS, EXTRA

LEAVES={}
for key in STUDY.fact_files:
    unit=STUDY.fact_files[key].unit if hasattr(STUDY.fact_files[key],'unit') else None
    from metrics import FACT_FILES
    unit=FACT_FILES[key][1]
    def leaf_factory(key,unit):
        @view(name='deep.facts.'+key,entity_id=ALL,source=FACT_FILES[key][0],schema={k:Field(t,unit if k=='value' else None,'披露事实 '+k) for k,t in FACT_SCHEMA.items()})
        def leaf(inp):return STUDY.fact_frame(key)
        return leaf
    LEAVES[key]=leaf_factory(key,unit)

PARAM_IDS=['h2_growth','store_growth','productivity_growth','contribution_margin','fixed_growth','tax','maintenance','expansion','depreciation_rate','working_capital','payout','share_change','award_expense','paired_release','financial_realization','operating_cash','shock_sales','shock_margin','shock_fixed']

def param(entity,p,y):
    if p=='h2_growth':y=2026
    try:return STUDY.params.resolve(entity,'deep_'+p,str(y),STUDY.params.scenario_id)
    except KeyError:
        # Only the declared long-node annual operational inputs interpolate.
        if p not in ['store_growth','productivity_growth','contribution_margin','fixed_growth']:raise
        lo=max(n for n in NODES if n<y);hi=min(n for n in NODES if n>y)
        a=STUDY.params.resolve(entity,'deep_'+p,str(lo),STUDY.params.scenario_id)
        b=STUDY.params.resolve(entity,'deep_'+p,str(hi),STUDY.params.scenario_id)
        return a+(b-a)*(y-lo)/(hi-lo)

def after_rent_ebit(a,ds,pt,key):
    g=lambda m:get(a,m,ds,pt)
    if key=='cha':
        # US GAAP operating lease expense is already in operating costs.
        return g('operating_profit_reported')
    if key=='ny':
        recurring=['material_cost','staff_cost','other_rentals','other_depreciation','advertising_cost','delivery_fees','utilities','logistics_cost','other_expense']
        if any(g(m) is None for m in recurring) or g('lease_cash_paid') is None:return None
        return g('revenue')-sum(g(m) for m in recurring)-g('lease_cash_paid')
    if g('gross_profit') is None:return None
    costs=[g(m) for m in ['selling_expense','admin_expense','rd_expense']]
    if any(v is None for v in costs):return None
    operating=g('gross_profit')-sum(costs)-(g('other_expense') or 0)
    if key=='gm':operating+=(g('fx_loss') or 0)+(g('listing_expense') or 0)
    # Other expense gains are not capitalized as recurring operating earnings.
    dep=g('rou_depreciation');principal=g('lease_principal_cash');interest=g('lease_interest_cash')
    if dep is not None and principal is not None and interest is not None:operating+=dep-principal-interest
    else:return operating  # Explicit low-confidence lease adjustment gap in report.
    return operating

def available_assets(a,key,p):
    g=lambda m:get(a,m,'2026-06-30','AS_OF') or 0
    debt=g('bank_debt_current')+g('bank_debt_noncurrent')
    if key=='gm':
        # Financing deposits can settle the matched bank debt, not be paid as cash.
        paired=min(debt,g('restricted_cash'))*p['paired_release']
        assets=g('cash_bank_balances')+g('long_term_deposits')*p['financial_realization']
        return assets-debt+paired+g('financial_assets_fvtpl')*p['financial_realization']
    term=g('time_deposits')+g('time_deposits_current')+g('time_deposits_noncurrent')
    assets=g('cash_equivalents')+(term+g('financial_assets_fvtpl')+(g('short_term_investments') if key=='cha' else 0))*p['financial_realization']-debt
    if key=='cha':
        # Unknown cash ownership: book attribution is a disclosed-data proxy,
        # not a claim that every subsidiary can freely remit this cash.
        assets*=g('equity_parent')/g('equity')
    return assets

INTERNAL={'entity_id':pl.String,'scenario':pl.String,'period':pl.String,'node_type':pl.String,**{k:pl.Float64 for k in ['revenue','stores','average_stores','core_ebit','normal_net_parent','net_parent','net_income','fcfe','dividend','equity_parent','shares_outstanding','net_financial_assets','owned_capital_base','capex','depreciation','working_capital','contribution','fixed_cost','cash_deficit','eps','dps','bvps','roe']}}
UNITS={k:'currency' for k,t in INTERNAL.items() if t==pl.Float64}
for k in ['stores','average_stores','shares_outstanding']:UNITS[k]='count'
for k in ['eps','dps','bvps']:UNITS[k]='currency_per_unit'
UNITS['roe']='decimal_ratio'

def simulate(key,issuer,a,c,security_counts,params,shocks=None):
    if key=='cha':
        from deep_chagee import simulate_mixed
        return simulate_mixed(issuer,a,c,security_counts,params,INTERNAL)
    shocks=shocks or {};h=lambda m:get(a,m,'2026-06-30','H1',True);fy=lambda m:get(a,m,'2025-12-31','FY',True);prevh=lambda m:get(a,m,'2025-06-30','H1',True)
    cmetric='owned_stores' if key=='ny' else 'stores'
    def population(ds):
        observed=get(c,cmetric,ds,'AS_OF')
        if observed is not None:return observed
        assert key=='cb'
        return get(c,'stores_domestic',ds,'AS_OF',True)+get(c,'overseas_stores',ds,'AS_OF',True)
    begin=population('2025-12-31');mid=population('2026-06-30')
    h1_ebit=after_rent_ebit(a,'2026-06-30','H1',key)
    assert h1_ebit is not None
    h1_rev=h('revenue');h1_gp=h('gross_profit') if key!='ny' else h1_rev*(1-(h('material_cost')+h('delivery_fees')+h('advertising_cost')+h('logistics_cost'))/h1_rev)
    h1_dep=(get(a,'other_depreciation','2026-06-30','H1') or 0) if key=='ny' else sum(get(a,m,'2026-06-30','H1') or 0 for m in ['ppe_depreciation','intangible_amortization'])
    # Reclassify non-ROU D&A out of the aggregate fixed pool; deduct projected D&A once.
    fixed=h1_gp-h1_ebit-h1_dep
    g=lambda m:get(a,m,'2026-06-30','AS_OF',True)
    equity=g('equity_parent');ppe=g('ppe')+g('intangible_assets')
    sh=security_counts.filter(pl.col('metric_id')=='shares_outstanding').sort('period_end')['value'][-1]
    if key=='gm':
        possible=security_counts.filter(pl.col('metric_id')=='cb_conversion_shares')
        assert possible.height==1
        sh+=possible['value'].item()  # Fully converted sensitivity; proceeds excluded as reserved.
    elif key=='ny':
        # Treasury reissue dilutes: allow max granted treasury pool as constant precaution.
        pass
    p0=params[0];cash=available_assets(a,key,p0);minimum=h1_rev*2*p0['operating_cash'];cash-=minimum
    wc= h1_rev*2*p0['working_capital'];previous_revenue=None;previous_average=None;rows=[]
    for p in params:
        y=p['year'];p=dict(p)
        for metric,shock in shocks.items():
            if metric in ['store_growth','productivity_growth']:p[metric]+=shock
            elif metric=='contribution_margin':p[metric]+=shock
            elif metric=='fixed_growth':p[metric]+=shock
        if y==2026:
            end=mid*(1+p['store_growth']/2)
            # H1 actual revenue plus a separately forecast H2. No second time weight.
            revenue=h1_rev+(fy('revenue')-prevh('revenue'))*(1+p['h2_growth'])
            average=(begin+2*mid+end)/4
            contribution=h1_gp+(revenue-h1_rev)*p['contribution_margin']
            annual_fixed=fixed*(2+p['fixed_growth']/2)
            elapsed=.5  # State starts from June 30; annual statement already includes H1.
        else:
            end=begin*(1+p['store_growth']);average=(begin+end)/2
            revenue=previous_revenue*average/previous_average*(1+p['productivity_growth'])
            fixed=annual_fixed*(1+p['fixed_growth']);annual_fixed=fixed
            contribution=revenue*p['contribution_margin'];elapsed=1
        award=p['award_expense']*(.5 if y==2026 else 1)
        capex=revenue*p['maintenance']+max(end-begin,0)*p['expansion']
        # Inputs start June 30 in Y0; state updates use remaining cash/earnings.
        dep=ppe*p['depreciation_rate']
        h1_cap=sum(get(a,m,'2026-06-30','H1') or 0 for m in ['capex_ppe','capex_land','capex_intangible'])
        if y==2026:
            h2_cap=(revenue-h1_rev)*p['maintenance']+max(end-mid,0)*p['expansion']
            capex=h1_cap+h2_cap
            dep=h1_dep+ppe*p['depreciation_rate']*.5
        ppe_change=(h2_cap-(dep-h1_dep)) if y==2026 else capex-dep
        ppe_new=ppe+ppe_change
        wc_new=revenue*p['working_capital'];delta_wc=(wc_new-wc)*elapsed
        ebit=contribution-annual_fixed-dep-award
        tax=max(ebit,0)*p['tax']
        attribution=h('net_parent')/h('net_income')
        net=(ebit-tax)*attribution
        # SBC remains in normalized profit; add noncash costs to cash, and dilute shares.
        fcfe=net+dep+award-capex-(wc_new-wc)
        # Losses consume cash; do not assume continuous refinancing or negative dividends.
        dividend=min(max(net,0)*p['payout'],max(fcfe,0)+max(cash,0))
        h1_net=(h1_ebit-max(h1_ebit,0)*p['tax'])*attribution
        state_net=(net-h1_net) if y==2026 else net
        remaining_fcfe=state_net+(dep-h1_dep)+award-h2_cap-(wc_new-wc) if y==2026 else fcfe
        cash_new=cash+remaining_fcfe-dividend*elapsed
        equity_new=equity+state_net+award-dividend*elapsed
        shares_new=sh*(1+p['share_change']*elapsed)
        assert isclose(cash_new-cash,remaining_fcfe-dividend*elapsed,abs_tol=1e-6)
        assert isclose(equity_new-equity,state_net+award-dividend*elapsed,abs_tol=1e-6)
        assert isclose(ppe_new-ppe,ppe_change,abs_tol=1e-6)
        assert end>0 and revenue>0 and ppe_new>=0
        rows.append(dict(entity_id=issuer,scenario=STUDY.params.scenario_id,period=str(y),node_type='explicit' if y in NODES else 'interpolated',revenue=revenue,stores=end,average_stores=average,core_ebit=ebit,normal_net_parent=net,net_parent=net,net_income=ebit-tax,fcfe=fcfe,dividend=dividend,equity_parent=equity_new,shares_outstanding=shares_new,net_financial_assets=cash_new,owned_capital_base=ppe_new,capex=capex,depreciation=dep,working_capital=wc_new,contribution=contribution,fixed_cost=annual_fixed,cash_deficit=max(-cash_new,0),eps=net/(shares_new/1e6),dps=dividend/(shares_new/1e6),bvps=equity_new/(shares_new/1e6),roe=net/((equity+equity_new)/2) if equity+equity_new!=0 else None))
        begin=end;previous_average=average;previous_revenue=revenue;ppe=ppe_new;wc=wc_new;cash=cash_new;equity=equity_new;sh=shares_new
    return pl.DataFrame(rows,schema=INTERNAL)

ISSUER_VIEWS={}
FORECAST_VIEWS=[];HISTORY_VIEWS=[];ECON_VIEWS=[];SENS_VIEWS=[]
for key,issuer in ISSUERS.items():
    def issuer_factory(key,issuer):
        selected={}
        for file in ['amounts','counts']:
            upstream=LEAVES[file]
            def selection_factory(file,upstream):
                @view(name=f'{key}.deep_facts_{file}',entity_id=issuer,inputs=[upstream],schema=upstream.field_declarations,lineage={k:[upstream.fields[k]] for k in FACT_SCHEMA})
                def selected(inp):return inp[0].filter(pl.col('entity_id')==issuer)
                return selected
            selected[file]=selection_factory(file,upstream)
        a=selected['amounts'];c=selected['counts'];counts=LEAVES['counts']
        if key=='cha':
            from deep_chagee import CHA_PARAMS, cha_param
            pids=CHA_PARAMS
        else:pids=PARAM_IDS
        @view(name=f'{key}.deep_assumptions',entity_id=issuer,source='params/parameters.csv',schema={'year':Field(pl.Int32,'count','年度'),**{p:Field(pl.Float64,'currency' if p in ['award_expense','cha_h1_da','cha_h1_investment'] else 'currency_per_unit' if p=='expansion' else 'decimal_ratio',p if p.startswith('cha_owned') else 'deep_'+p) for p in pids}})
        def assumptions(inp):return pl.DataFrame([{'year':y,**{p:(cha_param(issuer,p,y) if key=='cha' else param(issuer,p,y)) for p in pids}} for y in YEARS],schema={'year':pl.Int32,**{p:pl.Float64 for p in pids}})
        refs=[a.fields.value,c.fields.value,counts.fields.value,*assumptions.fields.values()]
        units=dict(UNITS);build_schema=dict(INTERNAL)
        if key=='cha':
            from deep_chagee import MIXED_UNITS
            units.update(MIXED_UNITS);build_schema.update({k:pl.Float64 for k in MIXED_UNITS})
        @view(name=f'{key}.deep_forecast_build',entity_id=issuer,inputs=[a,c,counts,assumptions],schema=fields(build_schema,units),lineage={k:refs for k in build_schema})
        def build(inp):return simulate(key,issuer,inp[0],inp[1],inp[2].filter(pl.col('entity_id')==SECURITIES[key]),inp[3].to_dicts())
        @view(name=f'{key}.deep_forecast',entity_id=issuer,inputs=[build],schema=fields(result_schema.FORECAST_SCHEMA,{'value':'currency'}),lineage={k:list(build.fields.values()) for k in result_schema.FORECAST_SCHEMA})
        def forecast(inp):
            rows=[]
            for r in inp[0].to_dicts():
                for m in units:
                    metric='owned_stores' if key=='ny' and m=='stores' else m
                    rows.append([issuer,STUDY.params.scenario_id,r['period'],'consolidated',metric,'estimate' if r['period']=='2026' else 'forecast',r['node_type'],r[m]])
            return pl.DataFrame(rows,schema=result_schema.FORECAST_SCHEMA,orient='row')
        @view(name=f'{key}.deep_history',entity_id=issuer,inputs=[a,c,counts],schema=fields(result_schema.HISTORY_SCHEMA,{'value':'currency'}),lineage={k:[a.fields.value,c.fields.value,counts.fields.value] for k in result_schema.HISTORY_SCHEMA})
        def history(inp):
            amount,count,security_count=inp;rows=[]
            for year in range(2021,2026):
                history_metrics=[*units,*(['operating_profit_reported','cfo'] if key=='cha' else [])]
                for m in history_metrics:
                    if m in ['normal_net_parent','fcfe','average_stores','contribution','fixed_cost','cash_deficit','net_financial_assets']:continue
                    obs='owned_stores' if m=='stores' and key=='ny' else m
                    pt='AS_OF' if m in ['stores','owned_stores','equity_parent','shares_outstanding','ppe'] else 'FY'
                    source=count if m in ['stores','owned_stores','shares_outstanding'] else amount
                    if key=='cha' and m=='shares_outstanding':source=security_count.filter(pl.col('entity_id')==SECURITIES[key])
                    value=get(source,obs,f'{year}-12-31',pt)
                    # Derived normalized operating earnings do not masquerade as disclosed facts.
                    metric='owned_stores' if key=='ny' and m=='stores' else m
                    if value is not None:rows.append([issuer,'fact',str(year),'consolidated',metric,'actual','explicit',value])
            return pl.DataFrame(rows,schema=result_schema.HISTORY_SCHEMA,orient='row')
        @view(name=f'{key}.store_economics',entity_id=issuer,inputs=[a,build,assumptions],schema=fields(STORE,{'value':'currency'}),lineage={k:[a.fields.value,*build.fields.values(),*assumptions.fields.values()] for k in STORE})
        def economics(inp):
            a,f,p=inp;rows=[]
            for year in [2025,2026]:
                ds=f'{year}-12-31' if year==2025 else '2026-06-30';pt='FY' if year==2025 else 'H1'
                cfo=get(a,'cfo',ds,pt);cap=get(a,'capex_ppe',ds,pt);land=get(a,'capex_land',ds,pt) or 0;intang=get(a,'capex_intangible',ds,pt) or 0
                lease=get(a,'lease_cash_paid',ds,pt)
                if lease is None:
                    principal=get(a,'lease_principal_cash',ds,pt);interest=get(a,'lease_interest_cash',ds,pt)
                    lease=principal+interest if principal is not None and interest is not None else None
                if key=='cha':
                    # US GAAP CFO includes operating lease payments; do not subtract again.
                    acq=get(a,'acquisition_cash',ds,pt);prepay=get(a,'intangible_prepayment_cash',ds,pt)
                    if cfo is not None and cap is not None and acq is not None and prepay is not None:rows.append([issuer,STUDY.params.scenario_id,STUDY.params.valuation_date,ds,'consolidated','cfo_less_all_capex_and_lease',cfo-cap-acq-prepay,'CNY_million','derived_actual_USGAAP_lease_in_CFO'])
                elif cfo is not None and cap is not None and lease is not None:rows.append([issuer,STUDY.params.scenario_id,STUDY.params.valuation_date,ds,'consolidated','cfo_less_all_capex_and_lease',cfo-cap-land-intang-lease,'CNY_million','derived_actual'])
            for r in f.to_dicts():
                for metric in ['normal_net_parent','fcfe','capex','cash_deficit']:rows.append([issuer,STUDY.params.scenario_id,STUDY.params.valuation_date,r['period'],'consolidated',metric,r[metric],'CNY_million','forecast'])
                if key in ['ny','cha']:
                    # Group contribution cannot establish the payback of an owned-store cohort.
                    rows.append([issuer,STUDY.params.scenario_id,STUDY.params.valuation_date,r['period'],'owned','gross_capex_payback_years',None,'years','unavailable_no_store_cohort'])
            return pl.DataFrame(rows,schema=STORE,orient='row')
        @view(name=f'{key}.deep_sensitivity',entity_id=issuer,inputs=[a,c,counts,assumptions,build],schema=fields(SENS,EXTRA['key_variable_sensitivity.csv'][2]),lineage={k:refs+list(build.fields.values()) for k in SENS})
        def sensitivity(inp):
            a,c,cs,p,f=inp;year='2031';base=f.filter(pl.col('period')==year).row(0,named=True);rows=[]
            if key=='cha':
                from deep_chagee import mixed_sensitivity
                return mixed_sensitivity(issuer,a,c,cs.filter(pl.col('entity_id')==SECURITIES[key]),p,f,SENS,INTERNAL)
            denominator=base['normal_net_parent'] if base['normal_net_parent']>0 else base['contribution'];basis='2031正常税后经营利润' if base['normal_net_parent']>0 else '2031集团变动成本后贡献'
            options=[('V1','store_growth',param(issuer,'shock_sales',2031)),('V2_V3','productivity_growth',param(issuer,'shock_sales',2031)),('V5','contribution_margin',param(issuer,'shock_margin',2031))] if key!='ny' else [('V2','productivity_growth',param(issuer,'shock_sales',2031)),('V7','fixed_growth',-param(issuer,'shock_fixed',2031)),('V4','maintenance',param(issuer,'shock_margin',2031))]
            for variable,metric,shock in options:
                # A one-period single-factor test; keep preceding history and state fixed.
                ps=p.to_dicts();idx=[r['year'] for r in ps].index(2031);ps[idx]=dict(ps[idx]);label=f'{metric} {shock:+.3f}'
                if variable=='V1':
                    ps[idx][metric]=(1+ps[idx][metric]/2)*(1+shock)*2-2;label='average_operating_stores +5%'
                elif variable in ['V2','V2_V3']:
                    ps[idx][metric]=(1+ps[idx][metric])*(1+shock)-1;label='per_effective_store_realization +5%'
                elif variable=='V7':
                    ps[idx][metric]=(1+ps[idx][metric])*(1+shock)-1;label='fixed_cash_cost -10%'
                else:ps[idx][metric]+=shock
                new=simulate(key,issuer,a,c,cs.filter(pl.col('entity_id')==SECURITIES[key]),ps).filter(pl.col('period')==year).row(0,named=True)
                local_basis=basis;local_denominator=denominator
                if variable=='V4':
                    delta=new['fcfe']-base['fcfe'];local_denominator=base['fcfe'] if base['fcfe']>0 else base['contribution'];local_basis='2031FCFE' if base['fcfe']>0 else '2031集团变动成本后贡献；FCFE非正'
                else:delta=new['normal_net_parent']-base['normal_net_parent']
                rows.append([issuer,STUDY.params.scenario_id,year,variable,label,local_basis,local_denominator,delta,delta/local_denominator])
            return pl.DataFrame(rows,schema=SENS,orient='row')
        return dict(amounts=a,counts=c,assumptions=assumptions,build=build,forecast=forecast,history=history,economics=economics,sensitivity=sensitivity)
    instances=issuer_factory(key,issuer);ISSUER_VIEWS[key]=instances
    FORECAST_VIEWS.append(instances['forecast']);HISTORY_VIEWS.append(instances['history']);ECON_VIEWS.append(instances['economics']);SENS_VIEWS.append(instances['sensitivity'])

def combine(name,instances,schema,units=None):
    @view(name='deep.results.'+name,entity_id=ALL,inputs=instances,schema=fields(schema,units),lineage={k:[i.fields[k] for i in instances] for k in schema})
    def combined(inp):return pl.concat(inp)
    return combined

forecast=combine('forecast',FORECAST_VIEWS,result_schema.FORECAST_SCHEMA,{'value':'currency'})
history=combine('history',HISTORY_VIEWS,result_schema.HISTORY_SCHEMA,{'value':'currency'})
economics=combine('economics',ECON_VIEWS,STORE,{'value':'currency'})
sensitivity=combine('sensitivity',SENS_VIEWS,SENS,EXTRA['key_variable_sensitivity.csv'][2])
