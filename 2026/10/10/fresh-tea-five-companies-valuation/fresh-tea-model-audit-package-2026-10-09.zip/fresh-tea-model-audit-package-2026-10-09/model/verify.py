"""Compatibility command for current acceptance; the old verifier remains in Git."""
from verify_deep import main
if __name__=="__main__":main()
