"""Inspect declared source-to-field dependencies, without a lineage CSV copy."""
from pathlib import Path
from mid_term_capital.view_engine import graph as engine_graph
from deep_tables import RESULT_TABLES  # noqa: F401
if __name__=='__main__':
    import sys
    raise SystemExit(engine_graph.main([*sys.argv[1:],'--study',str(Path(__file__).with_name('main.py'))]))
