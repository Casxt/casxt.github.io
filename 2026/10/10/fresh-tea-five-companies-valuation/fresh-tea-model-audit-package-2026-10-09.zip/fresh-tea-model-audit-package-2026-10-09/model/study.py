"""Bind one common research root; never duplicate issuer data per report."""
from pathlib import Path
from mid_term_capital.view_engine import loader
from metrics import FACT_FILES, FACTS
ROOT = Path(__file__).resolve().parents[1]
STUDY = loader.bind(ROOT, FACT_FILES, FACTS)
ISSUERS = {'gm': 'issuer:古茗_01364', 'mx': 'issuer:蜜雪冰城_02097', 'cha': 'issuer:霸王茶姬_CHA'}
SECURITIES = {'gm': 'security:古茗_01364.HK', 'mx': 'security:蜜雪冰城_02097.HK', 'cha': 'security:霸王茶姬_CHA.ADS'}
EXIT_YEAR = int(STUDY.params.constant('exit_year'))
YEARS = list(range(STUDY.params.valuation_date.year, EXIT_YEAR + 1))
