"""Compatibility command for the industry model; historical outputs remain."""
from run_deep import main
if __name__=="__main__":main()
