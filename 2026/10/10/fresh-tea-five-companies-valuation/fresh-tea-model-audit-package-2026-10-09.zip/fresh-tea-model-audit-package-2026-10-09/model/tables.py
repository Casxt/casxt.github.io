"""Archive definitions use registered keys, never duplicate schema strings."""
from mid_term_capital.view_engine.calculate import ResultTable
from mid_term_capital.view_engine import result_schema
from schemas import EXTRA
from views import research as v
RESULT_TABLES=[ResultTable('history_facts.csv',v.history_facts,result_schema.PREDICTION_KEY),ResultTable('forecast.csv',v.forecast,result_schema.PREDICTION_KEY)]
for name,instance in [('peer_comparison.csv',v.peer),('operating_outlook.csv',v.operating),('peer_market.csv',v.market),('key_variable_sensitivity.csv',v.sensitivity),('scale_check.csv',v.scale_check)]:RESULT_TABLES.append(ResultTable(name,instance,EXTRA[name][1]))
for name,instance in [('industry_profit_pool.csv',v.industry_pool),('capital_effects.csv',v.capital_effects),('operating_history.csv',v.operating_history)]:RESULT_TABLES.append(ResultTable(name,instance,EXTRA[name][1]))
RESULT_TABLES.append(ResultTable('business_mix.csv',v.business_mix,EXTRA['business_mix.csv'][1]))
