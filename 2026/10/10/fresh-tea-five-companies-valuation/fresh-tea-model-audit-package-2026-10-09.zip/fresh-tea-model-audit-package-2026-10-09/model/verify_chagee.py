"""Independent mixed-channel, cash-classification and non-unity ADS checks."""
from datetime import date
from math import isclose
from pathlib import Path
import csv
import io
import subprocess
import polars as pl
from mid_term_capital.view_engine import result_schema
from mid_term_capital.view_engine.calculate import Runner, dependency_order
from mid_term_capital.view_engine.view import DEFAULT_REGISTRY
from deep_study import ROOT, STUDY, ISSUERS, SECURITIES, get
from deep_operating import ISSUER_VIEWS
from deep_tables import RESULT_TABLES

def main():
    issuer=ISSUERS['cha'];security=SECURITIES['cha'];a=STUDY.fact_frame('amounts').filter(pl.col('entity_id')==issuer)
    c=STUDY.fact_frame('counts').filter(pl.col('entity_id')==issuer)
    for ds in ['2025-12-31','2026-06-30']:
        assert get(c,'stores',ds,'AS_OF')==get(c,'owned_stores',ds,'AS_OF')+get(c,'franchised_stores',ds,'AS_OF')
    for ds,pt in [('2025-12-31','FY'),('2025-06-30','H1'),('2026-06-30','H1')]:
        assert isclose(get(a,'franchise_revenue',ds,pt)+get(a,'owned_revenue',ds,pt),get(a,'revenue',ds,pt),abs_tol=1e-6)
        costs=sum(get(a,m,ds,pt) for m in ['material_cost','owned_operating_cost','other_operating_cost','selling_expense','admin_expense'])
        assert isclose(get(a,'revenue',ds,pt)-costs,get(a,'operating_profit_reported',ds,pt),abs_tol=1e-6)
    for scenario in ['deep_bear','deep_base','deep_bull']:
        folder=ROOT/'results'/scenario
        f=result_schema.read_result(folder/'forecast.csv').filter(pl.col('entity_id')==issuer)
        def fv(metric,year):return f.filter((pl.col('metric_id')==metric)&(pl.col('period')==str(year)))['value'].item()
        for year in range(2026,2037):
            assert isclose(fv('revenue',year),fv('franchise_revenue',year)+fv('owned_revenue',year),abs_tol=1e-6)
            assert isclose(fv('contribution',year),fv('franchise_contribution',year)+fv('owned_contribution',year),abs_tol=1e-6)
            assert isclose(fv('core_ebit',year),fv('contribution',year)-fv('fixed_cost',year)-fv('depreciation',year)-(get(a,'share_based_comp','2026-06-30','H1')+STUDY.params.resolve(issuer,'deep_award_expense','ALL',scenario)/2 if year==2026 else STUDY.params.resolve(issuer,'deep_award_expense','ALL',scenario)),abs_tol=1e-6)
            assert fv('owned_stores',year)<=fv('stores',year)
        inv=STUDY.params.resolve(issuer,'deep_cha_h1_investment','ALL',scenario)
        attribution=get(a,'net_parent','2025-12-31')/get(a,'net_income','2025-12-31')
        assert isclose(fv('fcfe',2026),(get(a,'cfo','2026-06-30','H1')-inv)*attribution+fv('h2_estimated_fcfe',2026),abs_tol=1e-6)
        tests=result_schema.read_result(folder/'chagee_mechanism_tests.csv')
        assert tests.filter(pl.col('test_id').str.starts_with('V3')|pl.col('test_id').str.starts_with('V6'))['delta_gmv'].abs().max()<1e-6
        cr=result_schema.read_result(folder/'currency_returns.csv')
        for method in ['dcf_steady','PE','dcf_book_return']:
            for tax in ['pre_tax','after_tax']:
                selected=cr.filter((pl.col('method')==method)&(pl.col('tax_basis')==tax)&(pl.col('exit_date')==date(2031,12,31)))
                if selected.is_empty():continue
                usd=selected.filter((pl.col('currency')=='USD')&(pl.col('fx_basis')=='fixed_fx')).row(0,named=True)
                cny=selected.filter(pl.col('currency')=='CNY').row(0,named=True)
                assert isclose(cny['quote_cost']/usd['quote_cost'],6.733,abs_tol=1e-9)
                assert isclose(cny['target_price']/usd['target_price'],6.733,abs_tol=1e-9)
                if usd['xirr'] is not None:
                    assert isclose(usd['xirr'],cny['xirr'],abs_tol=1e-9)
                    for basis,move in [('CNY_depreciates',.015),('CNY_appreciates',-.015)]:
                        irr=selected.filter(pl.col('fx_basis')==basis)['xirr'].item()
                        assert isclose(1+irr,(1+usd['xirr'])/(1+move),abs_tol=1e-9)
        market=result_schema.read_result(folder/'peer_market.csv').filter(pl.col('entity_id')==security).row(0,named=True)
        assert market['currency']=='USD' and market['price_hkd'] is None
        assert market['shares_date']==date(2026,3,18)
        assert isclose(market['market_cap_cny'],11.25*190.763326*6.733,abs_tol=1e-6)
        cash=get(a,'cash_equivalents','2026-06-30','AS_OF')+(get(a,'time_deposits','2026-06-30','AS_OF')+get(a,'short_term_investments','2026-06-30','AS_OF'))*STUDY.params.resolve(issuer,'deep_financial_realization','ALL',scenario)-get(a,'bank_debt_current','2026-06-30','AS_OF')-get(a,'revenue','2026-06-30','H1')*2*STUDY.params.resolve(issuer,'deep_operating_cash','ALL',scenario)
        cash*=get(a,'equity_parent','2026-06-30','AS_OF')/get(a,'equity','2026-06-30','AS_OF')
        assert isclose(market['available_net_financial_assets'],cash,abs_tol=1e-6)
        actual=result_schema.read_result(folder/'store_economics.csv').filter((pl.col('entity_id')==issuer)&(pl.col('period')=='2025-12-31')&(pl.col('metric_id')=='cfo_less_all_capex_and_lease'))['value'].item()
        expected=get(a,'cfo','2025-12-31')-sum(get(a,m,'2025-12-31') for m in ['capex_ppe','acquisition_cash','intangible_prepayment_cash'])
        assert isclose(actual,expected,abs_tol=1e-6),'US GAAP lease payment deducted twice'
    # The actual ratio is 1:1; an explicit 3:1 fixture exposes otherwise hidden conversion bugs.
    instance=next(v for v in DEFAULT_REGISTRY if v.name=='cha.valuation_all_methods')
    runner=Runner(STUDY,lambda _:None)
    for v in dependency_order([instance]):runner.run_view(v)
    args=[v.frame for v in instance.input_list];baseline=instance.func(args)
    args[-1]=args[-1].with_columns(pl.when((pl.col('entity_id')==security)&(pl.col('metric_id')=='ads_ordinary_ratio')).then(pl.lit(3.)).otherwise(pl.col('value')).alias('value'))
    triple=instance.func(args)
    b=baseline.filter(pl.col('price').is_not_null());t=triple.filter(pl.col('price').is_not_null())
    assert ((t['price']-b['price']*3).abs()<1e-8).all()
    assert ((t['diluted_shares']*3-b['diluted_shares']).abs()<1e-8).all()
    assert ((t['equity_value']-b['equity_value']).abs()<1e-8).all()
    # Four-company numerical rows must survive extending the shared results.
    repo=next(p for p in ROOT.parents if (p/'.git').exists());relative=ROOT.relative_to(repo)
    for scenario in ['deep_bear','deep_base','deep_bull']:
        for name in ['forecast.csv','history_facts.csv','valuation.csv','returns.csv','buy_prices.csv','peer_market.csv']:
            raw=subprocess.check_output(['git','show',f'3e31b82:{relative}/results/{scenario}/{name}'],cwd=repo,text=True)
            old=list(csv.DictReader(io.StringIO(raw)))
            with (ROOT/'results'/scenario/name).open() as f:new=[r for r in csv.DictReader(f) if '霸王茶姬' not in r['entity_id']]
            assert old==[{k:r[k] for k in old[0]} for r in new],(scenario,name,'changed existing issuer numbers')
    print('PASS: Chagee demand/channel identities, annual cost and H1 cash bridge, V3/V6 fixed demand, USGAAP cash lease once, currency/FX returns, non-unity ADS fixture, four-company numerical regression')

if __name__=='__main__':main()
