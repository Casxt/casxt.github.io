"""Final economic and ADS/currency diagnostics cited in the company report."""
from datetime import date
from math import isclose
import polars as pl
from mid_term_capital.view_engine import Field, view
from mid_term_capital.view_engine.finance import present_value, investment_xirr
from deep_study import STUDY, ISSUERS, SECURITIES, get
from deep_operating import ISSUER_VIEWS, LEAVES, INTERNAL
from deep_chagee import simulate_mixed
from deep_valuation import VALS, conversion_rate, ads_ratio
from deep_schemas import fields, MECHANISM, CURRENCY_RETURN, ADS_PRESSURE, EXTRA

issuer=ISSUERS['cha'];security=SECURITIES['cha'];v=ISSUER_VIEWS['cha'];a=v['amounts'];c=v['counts'];counts=LEAVES['counts'];p=v['assumptions'];build=v['build']
refs=[a.fields.value,c.fields.value,counts.fields.value,*p.fields.values(),*build.fields.values()]
@view(name='cha.investment_bounds',entity_id=issuer,source='params/parameters.csv',schema={k:Field(pl.Float64,'currency','H1投入敏感性边界：'+k) for k in ['bear_bound','bull_bound']})
def investment_bounds(inp):
    return pl.DataFrame([{'bear_bound':STUDY.params.resolve(issuer,'deep_cha_h1_investment','ALL','deep_bear'),'bull_bound':STUDY.params.resolve(issuer,'deep_cha_h1_investment','ALL','deep_bull')}],schema={'bear_bound':pl.Float64,'bull_bound':pl.Float64})

@view(name='cha.mechanism_tests',entity_id=issuer,inputs=[a,c,counts,p,build,investment_bounds],schema=fields(MECHANISM,EXTRA['chagee_mechanism_tests.csv'][2]),lineage={k:refs+list(investment_bounds.fields.values()) for k in MECHANISM})
def mechanism(inp):
    a,c,cs,pars,f,bounds=inp;cs=cs.filter(pl.col('entity_id')==security);params=pars.to_dicts();rows=[]
    idx=[r['year'] for r in params].index(2031);b=f.filter(pl.col('period')=='2031').row(0,named=True)
    tests=[('V2','productivity_growth',params[idx]['shock_sales']),('V3','cha_take',params[idx]['shock_margin']),('V6','cha_owned_gmv_share',params[idx]['cha_shock_owned']),('V7','fixed_growth',-params[idx]['shock_fixed'])]
    for variable,metric,shock in tests:
        for sign,suffix in [(1,'up'),(-1,'down')]:
            ps=[dict(r) for r in params]
            if variable in ['V2','V7']:ps[idx][metric]=(1+ps[idx][metric])*(1+shock*sign)-1
            else:ps[idx][metric]+=shock*sign
            n=simulate_mixed(issuer,a,c,cs,ps,INTERNAL).filter(pl.col('period')=='2031').row(0,named=True)
            delta=lambda m:n[m]-b[m]
            # Recurring capacity contribution excludes upfront investment and tax is positive-only.
            recurring=delta('normal_net_parent')+(delta('depreciation')-delta('maintenance_capex'))*b['cash_earnings_attribution']
            payback=delta('expansion_capex')*b['cash_earnings_attribution']/recurring if delta('expansion_capex')>0 and recurring>0 else None
            rows.append([issuer,STUDY.params.scenario_id,'2031',variable+'_'+suffix,b['normal_net_parent'],b['fcfe'],delta('normal_net_parent'),delta('fcfe'),delta('revenue'),delta('gmv'),delta('capex'),payback,'单年边界实验；利润相同基期；转店不增加需求；回本缺同批证据，正贡献才可计算'])
    # Hold the current scenario's other drivers fixed while varying missing H1 investment.
    b=f.filter(pl.col('period')=='2026').row(0,named=True)
    for sc in ['deep_bear','deep_bull']:
        ps=[dict(r) for r in params]
        ps[0]['cha_h1_investment']=bounds['bear_bound' if sc=='deep_bear' else 'bull_bound'].item()
        n=simulate_mixed(issuer,a,c,cs,ps,INTERNAL).filter(pl.col('period')=='2026').row(0,named=True)
        rows.append([issuer,STUDY.params.scenario_id,'2026','H1_investment_'+sc,b['normal_net_parent'],b['fcfe'],n['normal_net_parent']-b['normal_net_parent'],n['fcfe']-b['fcfe'],0.,0.,n['capex']-b['capex'],None,'仅改H1未披露投资参数，取另一档边界；不冒充投资实际值'])
    return pl.DataFrame(rows,schema=MECHANISM,orient='row')

valuation=VALS[-1];fx=LEAVES['fx_usd_cny'];ratios=LEAVES['ratios'];quote=LEAVES['quote_usd']
rpids=['required_high','required_low','dividend_tax','interim_share','fx_shock']
@view(name='cha.currency_assumptions',entity_id=security,source='params/parameters.csv',schema={k:Field(pl.Float64,'decimal_ratio','deep_'+k) for k in rpids})
def currency_assumptions(inp):
    return pl.DataFrame([{k:STUDY.params.resolve(security,'deep_'+k,'ALL',STUDY.params.scenario_id) for k in rpids}],schema={k:pl.Float64 for k in rpids})

crefs=[*valuation.fields.values(),*build.fields.values(),*currency_assumptions.fields.values(),fx.fields.value,ratios.fields.value,quote.fields.value]
@view(name='cha.currency_returns',entity_id=security,inputs=[valuation,build,currency_assumptions,fx,ratios,quote],schema=fields(CURRENCY_RETURN,EXTRA['currency_returns.csv'][2]),lineage={k:crefs for k in CURRENCY_RETURN})
def currency_returns(inp):
    vals,f,p,fx,ratio,q=inp;p=p.row(0,named=True);fx=1/conversion_rate('cha',fx);ads=ads_ratio('cha',security,ratio)
    close=q.filter((pl.col('entity_id')==security)&(pl.col('period_end')==STUDY.params.valuation_date))['value'].item();rows=[]
    for val in vals.to_dicts():
        if val['target_year']==2026:continue
        end=date(val['target_year'],12,31)
        for tax_basis,tax in [('pre_tax',0.),('after_tax',p['dividend_tax'])]:
            baseflows=[]
            for r in f.to_dicts():
                year=int(r['period']);dps=r['dividend']/(r['shares_outstanding']/1e6)*ads/fx*(1-tax)
                for ds,portion in [(date(year,8,31),p['interim_share']),(date(year+1,5,31),1-p['interim_share'])]:
                    if STUDY.params.valuation_date<ds<=end:baseflows.append((ds,dps*portion))
            baseflows.append((end,val['price']))
            for currency,move,fx_basis in [('USD',0.,'fixed_fx'),('CNY',0.,'fixed_fx'),('USD',p['fx_shock'],'CNY_depreciates'),('USD',-p['fx_shock'],'CNY_appreciates')]:
                multiplier=fx if currency=='CNY' else 1.
                flows=[(ds,value*multiplier/(1+move)**((ds-STUDY.params.valuation_date).days/365)) for ds,value in baseflows]
                target=flows[-1][1];high=low=irr=None
                if target>=0 and any(value>0 for ds,value in flows):
                    high=present_value(STUDY.params.valuation_date,flows,p['required_high']);low=present_value(STUDY.params.valuation_date,flows,p['required_low'])
                    assert isclose(investment_xirr(STUDY.params.valuation_date,high,flows),p['required_high'],abs_tol=1e-9)
                    assert isclose(investment_xirr(STUDY.params.valuation_date,low,flows),p['required_low'],abs_tol=1e-9)
                    irr=investment_xirr(STUDY.params.valuation_date,close*multiplier,flows)
                rows.append([security,STUDY.params.scenario_id,STUDY.params.valuation_date,end,val['method'],tax_basis,currency,fx_basis,close*multiplier,target,high,low,irr])
    return pl.DataFrame(rows,schema=CURRENCY_RETURN,orient='row')

@view(name='cha.ads_pool_pressure',entity_id=security,inputs=[valuation,counts,ratios],schema=fields(ADS_PRESSURE,EXTRA['ads_pool_pressure.csv'][2]),lineage={k:[*valuation.fields.values(),counts.fields.value,ratios.fields.value] for k in ADS_PRESSURE})
def ads_pressure(inp):
    vals,c,ratio=inp;c=c.filter(pl.col('entity_id')==security);ads=ads_ratio('cha',security,ratio)
    floor=get(c,'shares_outstanding','2025-12-31','AS_OF',True)+get(c,'award_escrow_shares','2025-12-31','AS_OF',True)
    rows=[]
    for r in vals.to_dicts():
        shares=r['diluted_shares']*1e6*ads;stress=max(shares,floor);price=r['price']*shares/stress
        rows.append([security,STUDY.params.scenario_id,r['target_year'],r['method'],shares,stress,r['price'],price,price/r['price']-1 if r['price']!=0 else None,'USD','完整FY25奖励池归属的股数下限压力；与预测净稀释取较大值，避免奖励池重复添加；未知未来回购/新授未精确重建'])
    return pl.DataFrame(rows,schema=ADS_PRESSURE,orient='row')
