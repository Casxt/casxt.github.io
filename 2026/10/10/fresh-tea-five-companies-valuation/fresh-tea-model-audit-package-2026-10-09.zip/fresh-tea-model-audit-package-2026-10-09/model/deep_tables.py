"""Final outputs, rather than intermediate calculation snapshots."""
from datetime import date
import polars as pl
from mid_term_capital.view_engine import ALL, view
from mid_term_capital.view_engine.calculate import ResultTable
from mid_term_capital.view_engine import result_schema
from deep_study import STUDY
from deep_schemas import EXTRA, fields
from deep_operating import forecast,history,economics,sensitivity
from deep_valuation import valuation,coverage,returns,buy,market,history as historical_valuation,evidence
from deep_chagee_outputs import mechanism,currency_returns,ads_pressure

scale_schema,key,units=EXTRA['scale_check.csv']
@view(name='deep.results.scale_check',entity_id=ALL,inputs=[sensitivity,forecast],schema=fields(scale_schema,units),lineage={k:list(sensitivity.fields.values())+list(forecast.fields.values()) for k in scale_schema})
def scale(inp):
    s,f=inp;rows=[]
    for r in s.to_dicts():
        threshold=.1
        rows.append([r['entity_id'],r['key_variable_id'],date(2031,12,31),'FY',r['delta_profit'],r['reference_profit'],r['reference_basis'],r['delta_ratio'],threshold,abs(r['delta_ratio'])>=threshold])
    return pl.DataFrame(rows,schema=scale_schema,orient='row')

RESULT_TABLES=[ResultTable('forecast.csv',forecast,result_schema.PREDICTION_KEY),ResultTable('history_facts.csv',history,result_schema.PREDICTION_KEY),ResultTable('valuation.csv',valuation,result_schema.VALUATION_KEY),ResultTable('returns.csv',returns,result_schema.RETURNS_KEY)]
for name,instance in [('store_economics.csv',economics),('key_variable_sensitivity.csv',sensitivity),('scale_check.csv',scale),('valuation_coverage.csv',coverage),('buy_prices.csv',buy),('peer_market.csv',market),('historical_valuation.csv',historical_valuation),('valuation_evidence.csv',evidence)]:RESULT_TABLES.append(ResultTable(name,instance,EXTRA[name][1]))
for name,instance in [('chagee_mechanism_tests.csv',mechanism),('currency_returns.csv',currency_returns),('ads_pool_pressure.csv',ads_pressure)]:RESULT_TABLES.append(ResultTable(name,instance,EXTRA[name][1]))
