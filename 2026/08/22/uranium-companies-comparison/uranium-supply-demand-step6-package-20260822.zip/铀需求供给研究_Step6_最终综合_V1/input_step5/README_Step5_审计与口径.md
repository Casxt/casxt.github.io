# 铀需求供给研究 — Step5 整合审计 V2

本包是从 Step5_D_V1 包全新导出的审计/整合版本，不在旧表上编辑。

## 结构
- `data/`：面向程序读写的整合 CSV。
- `model/`：最小可复现模型代码与输入；运行 `python run_all.py` 可重新生成 Step5-B / Step5-D 原始输出。
- `铀需求供给研究_Step5_整合审计_V2.xlsx`：与 `data/` 同源生成的整合工作簿，不作为唯一数据源。

## 关键修复
1. 2025 美国核电运营商库存从旧的约 118.0 Mlb 口径更新为 EIA 的 118.256 Mlb，并重新换算 tracked pool。
2. Spot 超阈值结果不再把 LT 未解尾部伪装成单点概率，改成“有限价格下界 + 未解尾部上界”。
3. “existing-fleet disruption”改为更保守的“hard physical shortage proxy”，因为当前需求输入没有单独的现役机组刚性需求路径。
4. 概率假设表的需求延期触发点与代码统一为 0.90×xcrit，目标约 0.85×xcrit。
5. LT 网格显式加入 $300 边界。
6. 修正 uranium-only shadow 中 U → U3O8 的质量换算。
7. Step5-B 加入 `__main__` 写出保护，Step5-D import 不再自动重写 Step5-B 输出。
8. 新 XLSX 从整合 CSV 全量生成，避免旧工作簿的字段丢失。

## 仍保留的模型限制
- WNA Lower / Reference / Upper 是场景，不是统计分位；Beta 包装是分析师先验。
- xcrit、累计库存释放容忍度属于行为先验。
- LT clearing target 是“累计 gross deficit / 库存释放量”口径，不是单纯期末库存耗损。
- 项目风险仍主要按项目独立抽样；系统性许可、资本开支、地缘冲击相关性没有完整建模。
