# 铀需求供给研究 — Step6 最终综合 V1

本包以 `铀需求供给研究_Step5_整合审计_V2` 为唯一上游数据底座，完成最终综合、风险时间轴、LT/Spot 分层表达、库存/延期敏感性、关键项目监控和证伪框架。

## 目录
- `铀需求供给研究_Step6_最终综合报告_V1.md`：最终报告。
- `data/`：Step6 面向程序读写的新表；CSV 为主数据源。
- `input_step5/data/`：自包含的 Step5 V2 整合 CSV 输入镜像。
- `model/Step6_synthesis.py`：可复现生成脚本。
- `铀需求供给研究_Step6_最终综合_V1.xlsx`：由 Step6 CSV 同源生成的审计工作簿。

## Step6 不做什么
- 不把 ≥$300 的 LT censored 世界伪装成 $300 的真实价格预测。
- 不把 hard physical shortage proxy 解释成现役核电站停机概率。
- 不使用 Spot 价格倒推矿山同年产量；FID 仍服从时间因果。
- 不覆盖或原地编辑 Step5 旧文件。

## 更新顺序
年度/重大事件更新时，先更新 Step5 输入并重跑 Step5-B / Step5-D；确认 Gate 与 checks 后，再运行 Step6 synthesis。不要只手工改 Step6 结论表。
