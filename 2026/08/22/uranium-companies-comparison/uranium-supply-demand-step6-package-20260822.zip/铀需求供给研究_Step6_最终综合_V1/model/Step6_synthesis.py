from pathlib import Path
import csv, math, shutil, json, os
from collections import defaultdict

PKG_ROOT = Path(__file__).resolve().parents[1]
SRC_ROOT = PKG_ROOT/'input_step5'
OUT_ROOT = PKG_ROOT
(OUT_ROOT/'data').mkdir(parents=True, exist_ok=True)
(OUT_ROOT/'model').mkdir(parents=True, exist_ok=True)

def read_csv(path):
    with open(path, 'r', encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))

def write_csv(path, rows, fields=None):
    path.parent.mkdir(parents=True, exist_ok=True)
    if fields is None:
        fields = list(rows[0].keys()) if rows else []
    with open(path, 'w', encoding='utf-8-sig', newline='') as f:
        w=csv.DictWriter(f, fieldnames=fields, extrasaction='ignore')
        w.writeheader(); w.writerows(rows)

def f(x):
    if x is None or x=='': return None
    return float(x)

def pct(x, n=1):
    return f'{100*x:.{n}f}%'

def fmt(x,n=1):
    if x is None or (isinstance(x,float) and math.isnan(x)): return '—'
    return f'{x:.{n}f}'

D = SRC_ROOT/'data'
annual = read_csv(D/'05_annual_outputs.csv')
scans = read_csv(D/'06_price_scans.csv')
sens = read_csv(D/'07_scenario_sensitivities.csv')
tail = read_csv(D/'08_tail_drivers.csv')
checks5 = read_csv(D/'09_checks.csv')
sources = read_csv(D/'10_sources.csv')
projects = read_csv(D/'03_projects_master.csv')
tech = read_csv(D/'04_project_technical_supply_path.csv')
registry = read_csv(D/'02_model_registry.csv')

# ---------------- key anchors ----------------
reg_by_metric={r['metric']:r for r in registry}
tracked_pool=f(reg_by_metric['TOTAL_TRACKED_POOL']['value'])
current_lt=f(reg_by_metric['current_LT_price']['value'])
current_spot=f(reg_by_metric['current_spot_price']['value'])

a0,aN=annual[0],annual[-1]
y0,yN=int(a0['year']),int(aN['year'])
d0,dN=f(a0['base_Reference_demand_ktU']),f(aN['base_Reference_demand_ktU'])
demand_cagr=(dN/d0)**(1/(yN-y0))-1
p0,pN=f(a0['base_primary_P50_at_95_5_ktU']),f(aN['base_primary_P50_at_95_5_ktU'])
primary_cagr=(pN/p0)**(1/(yN-y0))-1
sat_pN=f(aN['base_primary_P50_at_price_saturation_ktU'])
extra_sat_2036=sat_pN-pN

def sens_rows(t): return [r for r in sens if r['analysis_type']==t]
inv_sens=sens_rows('inventory_draw_target')
delay=sens_rows('delay_penalty_50pct_inventory_target')
stress=sens_rows('inventory_access_and_demand_response_stress')

floor50=f(next(r for r in inv_sens if r['max_cumulative_draw_pct_pool']=='0.5')['minimum_LT_price_from_2027_2026real_USD_lb'])
floor45=f(next(r for r in inv_sens if r['max_cumulative_draw_pct_pool']=='0.45')['minimum_LT_price_from_2027_2026real_USD_lb'])

# Step5D scan key points
scanD=[r for r in scans if r['scan_type']=='Step5D_joint_worlds_known_plus_frontier']
def nearest_scan(P): return min(scanD,key=lambda r:abs(f(r['LT_price_2026real_USD_lb'])-P))
scan95=nearest_scan(95.5); scan100=nearest_scan(100.5); scan120=nearest_scan(120.5); scan300=nearest_scan(300)

# ---------------- 01 key metrics ----------------
key=[]
def add(section, metric, value, unit, interpretation, source_file, source_key=''):
    key.append({'section':section,'metric':metric,'value':value,'unit':unit,'interpretation':interpretation,'source_file':source_file,'source_key':source_key})
add('Market anchor','Long-term price anchor',current_lt,'USD/lb U3O8 (2026 quote)','FID/contracting signal; not spot scarcity price.','02_model_registry.csv','current_LT_price')
add('Market anchor','Spot price anchor',current_spot,'USD/lb U3O8 (2026 quote)','As-of 2026-07-31 model anchor.','02_model_registry.csv','current_spot_price')
add('Inventory','Tracked observable inventory pool',tracked_pool,'ktU','US + EU + East Asia observable pool; not all global inventory and not fully fungible.','02_model_registry.csv','TOTAL_TRACKED_POOL')
add('Demand','Reference demand 2027',d0,'ktU/y','Reference demand path start.','05_annual_outputs.csv','2027')
add('Demand','Reference demand 2036',dN,'ktU/y','Reference demand path end.','05_annual_outputs.csv','2036')
add('Demand','Reference demand CAGR 2027-2036',demand_cagr,'fraction/year','Demand grows faster than current-price primary supply.','05_annual_outputs.csv','2027-2036')
add('Supply','Current-LT primary P50 2036',pN,'ktU/y','Known-project primary supply at $95.5 LT under median execution.','05_annual_outputs.csv','2036')
add('Supply','Price-saturation primary P50 2036',sat_pN,'ktU/y','Known-project price-only saturation; high price cannot change lead times already missed.','05_annual_outputs.csv','2036')
add('Supply','Extra 2036 primary from price saturation vs current LT',extra_sat_2036,'ktU/y','Small marginal response demonstrates late-stage price-only saturation.','05_annual_outputs.csv','2036')
add('Balance','2036 deficit at current LT',-f(aN['base_balance_at_95_5_ktU']),'ktU/y','Reference demand + Base structural secondary minus primary.','05_annual_outputs.csv','2036')
add('Balance','2036 deficit at price saturation',-f(aN['base_balance_at_price_saturation_ktU']),'ktU/y','Residual gap after price-only activation of known projects.','05_annual_outputs.csv','2036')
add('LT clearing','50% cumulative inventory-draw floor from 2027',floor50,'USD/lb U3O8 (2026 real)','Median Reference known-project floor; target is cumulative gross deficit <=50% tracked pool.','07_scenario_sensitivities.csv','inventory_draw_target=0.50')
add('LT clearing','45% cumulative inventory-draw floor from 2027',floor45,'USD/lb U3O8 (2026 real)','Inventory-preserving floor; 42% target becomes infeasible in known universe.','07_scenario_sensitivities.csv','inventory_draw_target=0.45')
add('Joint distribution','Current LT sufficient world share',f(tail[0]['world_share']),'fraction','Worlds whose own inventory target is met at $95.5 LT.','08_tail_drivers.csv','Current_LT_sufficient')
add('Joint distribution','LT 100-150 solved world share',f(tail[1]['world_share']),'fraction','Moderate rerating resolves an additional material block of worlds.','08_tail_drivers.csv','Solved_100_to_150')
add('Joint distribution','LT 150-300 solved world share',f(tail[2]['world_share']),'fraction','Only a small finite-solution block requires very high LT before boundary.','08_tail_drivers.csv','Solved_150_to_300')
add('Joint distribution','LT >=300 censored world share',f(tail[3]['world_share']),'fraction','Right-censored tail: do not replace with an arbitrary finite target price.','08_tail_drivers.csv','LT_model_boundary_ge_300')
add('Joint distribution','P50 cumulative deficit at current LT',f(scan95['cum_deficit_P50_ktU']),'ktU','Known + frontier joint worlds.','06_price_scans.csv','Step5D $95.5')
add('Joint distribution','P50 cumulative deficit at $300 LT',f(scan300['cum_deficit_P50_ktU']),'ktU','Residual even at model boundary; reflects timing/execution and demand/inventory assumptions.','06_price_scans.csv','Step5D $300')
add('Spot tail','2036 finite spot conditional P50',f(aN['spot_spot_real_conditional_P50_USD_lb']),'USD/lb U3O8 (2026 real)','Conditional on worlds with a finite modelled spot quote.','05_annual_outputs.csv','2036')
add('Spot tail','2036 finite spot conditional P90',f(aN['spot_spot_real_conditional_P90_USD_lb']),'USD/lb U3O8 (2026 real)','Conditional finite tail; not unconditional P90 due censored worlds.','05_annual_outputs.csv','2036')
add('Spot tail','2036 P(Spot>$200) finite lower bound',f(aN['spot_prob_spot_gt_200_finite_lower_bound']),'fraction','Confirmed finite-quote worlds only.','05_annual_outputs.csv','2036')
add('Spot tail','2036 P(Spot>$200) incl unresolved upper bound',f(aN['spot_prob_spot_gt_200_or_unresolved_upper_bound']),'fraction','Treats unresolved boundary/dysfunction/shortage as potentially above threshold.','05_annual_outputs.csv','2036')
add('Regime','2036 seller-scarcity probability',f(aN['spot_seller_scarcity_probability']),'fraction','Finite normal regime where spot basis exceeds tight-market anchor.','05_annual_outputs.csv','2036')
add('Regime','2036 median inventory remaining',f(aN['spot_median_inventory_remaining_pct_initial']),'fraction of effective initial pool','State-machine median after demand schedule response and restocking.','05_annual_outputs.csv','2036')
write_csv(OUT_ROOT/'data/01_key_metrics.csv', key)

# ---------------- 02 annual dashboard ----------------
annual_dash=[]
for r in annual:
    year=int(r['year'])
    gcur=max(0.0,-f(r['base_balance_at_95_5_ktU']))
    gsat=max(0.0,-f(r['base_balance_at_price_saturation_ktU']))
    seller=f(r['spot_seller_scarcity_probability'])
    if year<=2033:
        phase='库存桥接/紧平衡前段'
    elif year==2034:
        phase='紧平衡显性化'
    elif year==2035:
        phase='稀缺转换窗口'
    else:
        phase='高非线性尾部窗口'
    annual_dash.append({
        'year':year,
        'phase':phase,
        'Reference_demand_ktU':f(r['base_Reference_demand_ktU']),
        'Base_structural_secondary_ktU':f(r['base_Base_structural_secondary_ktU']),
        'primary_P50_current_LT_ktU':f(r['base_primary_P50_at_95_5_ktU']),
        'primary_P50_price_saturation_ktU':f(r['base_primary_P50_at_price_saturation_ktU']),
        'annual_gap_current_LT_ktU':gcur,
        'annual_gap_price_saturation_ktU':gsat,
        'extra_primary_from_price_saturation_ktU':f(r['base_primary_P50_at_price_saturation_ktU'])-f(r['base_primary_P50_at_95_5_ktU']),
        'LT_required_real_P50_USD_lb':f(r['lt_LT_required_real_P50_USD_lb']),
        'LT_censored_share_ge_300':f(r['lt_share_LT_censored_ge_300']),
        'finite_spot_share':f(r['spot_finite_spot_share']),
        'spot_real_conditional_P50_USD_lb':f(r['spot_spot_real_conditional_P50_USD_lb']),
        'spot_real_conditional_P90_USD_lb':f(r['spot_spot_real_conditional_P90_USD_lb']),
        'spot_gt_200_finite_lower_bound':f(r['spot_prob_spot_gt_200_finite_lower_bound']),
        'spot_gt_200_unresolved_upper_bound':f(r['spot_prob_spot_gt_200_or_unresolved_upper_bound']),
        'market_dysfunction_probability':f(r['spot_market_dysfunction_probability']),
        'hard_physical_shortage_proxy_probability':f(r['spot_hard_physical_shortage_proxy_probability']),
        'seller_scarcity_probability':seller,
        'tight_inventory_probability':f(r['spot_tight_inventory_probability']),
        'buyer_comfortable_probability':f(r['spot_buyer_comfortable_probability']),
        'median_demand_schedule_response_ktU':f(r['spot_median_demand_response_to_WNA_Lower_envelope_ktU']),
        'P90_demand_schedule_response_ktU':f(r['spot_P90_demand_response_to_WNA_Lower_envelope_ktU']),
        'median_inventory_remaining_pct_initial':f(r['spot_median_inventory_remaining_pct_initial']),
    })
write_csv(OUT_ROOT/'data/02_annual_risk_dashboard.csv', annual_dash)

# ---------------- 03 price regime buckets ----------------
bucket_labels={
 'Current_LT_sufficient':'A_当前LT已足够',
 'Solved_100_to_150':'B_温和到显著LT重估可解决',
 'Solved_150_to_300':'C_高LT仍可有限清算',
 'LT_model_boundary_ge_300':'D_模型边界/右删失尾部',
}
regimes=[]
for r in tail:
    b=r['bucket']
    interp={
      'Current_LT_sufficient':'不需要进一步提高长期价即可满足该世界自身的累计库存释放容忍度。',
      'Solved_100_to_150':'主要依靠长期合同价重估、已有/前沿项目激活与库存桥接实现清算。',
      'Solved_150_to_300':'供需/执行组合已明显恶化，但模型 universe 内仍存在有限 LT 解。',
      'LT_model_boundary_ge_300':'即使测试到 $300 仍无法满足该世界的库存目标；价格不应被机械外推，关键是项目 universe、时间、库存可动员性或需求路径发生变化。',
    }[b]
    regimes.append({
      'regime':bucket_labels[b], 'raw_bucket':b,
      'world_share':f(r['world_share']),
      'median_required_LT_2026real_USD_lb':f(r['median_required_LT_USD_lb']),
      'median_demand_latent_u':f(r['median_demand_latent_u']),
      'median_effective_inventory_pool_multiplier':f(r['median_effective_pool_multiplier']),
      'median_cumulative_draw_cap':f(r['median_cumulative_draw_cap']),
      'median_one_year_xcrit':f(r['median_xcrit']),
      'median_secondary_latent_u':f(r['median_secondary_latent_u']),
      'interpretation':interp,
    })
write_csv(OUT_ROOT/'data/03_price_regime_buckets.csv', regimes)

# ---------------- 04 inventory target sensitivity ----------------
inv_out=[]
for r in inv_sens:
    inv_out.append({
      'max_cumulative_draw_pct_pool':f(r['max_cumulative_draw_pct_pool']),
      'target_cumulative_deficit_ktU':f(r['target_cumulative_deficit_ktU']),
      'required_LT_from_2027_2026real_USD_lb':f(r['minimum_LT_price_from_2027_2026real_USD_lb']),
      'status':r['status'],
      'current_LT_cum_deficit_P50_ktU':f(r['current_95_5_cumulative_deficit_P50_ktU']),
      'price_saturation_cum_deficit_P50_ktU':f(r['price_only_saturation_cumulative_deficit_P50_ktU']),
      'price_saturation_draw_pct_pool':f(r['price_only_saturation_draw_pct_pool']),
      'interpretation':r['interpretation'],
    })
write_csv(OUT_ROOT/'data/04_inventory_target_sensitivity.csv', inv_out)

# ---------------- 05 delay penalty ----------------
delay_out=[]
for r in delay:
    delay_out.append({
      'action_year':int(r['action_year']),
      'price_before_action_2026real_USD_lb':f(r['price_before_action_2026real_USD_lb']),
      'required_sustained_LT_2026real_USD_lb':f(r['required_sustained_LT_price_2026real_USD_lb']),
      'required_price_nominal_action_year_USD_lb':f(r['required_price_nominal_action_year_USD_lb']),
      'delay_penalty_vs_2026_action_USD_lb':f(r['delay_penalty_vs_2026_action_USD_lb']),
      'status':'SOLVED' if r['required_sustained_LT_price_2026real_USD_lb'] else 'NO_FINITE_PRICE_WITHIN_MODELLED_UNIVERSE',
      'interpretation':'同一 2036 累计 draw≤50% 目标；越晚形成投资价格信号，越多供给来不及在 2036 前兑现。',
    })
write_csv(OUT_ROOT/'data/05_delay_penalty.csv', delay_out)

# ---------------- 06 physical stress matrix ----------------
stress_out=[]
for r in stress:
    stress_out.append({
      'year':int(r['year']),
      'effective_inventory_multiplier':f(r['effective_inventory_shock_multiplier']),
      'newbuild_schedule_response_to_WNA_Lower':r['scarcity_newbuild_demand_response_to_WNA_Lower'],
      'market_dysfunction_probability':f(r['market_dysfunction_probability']),
      'hard_physical_shortage_proxy_probability':f(r['hard_physical_shortage_proxy_probability']),
      'combined_probability':f(r['dysfunction_or_hard_shortage_proxy_probability']),
      'semantic_warning':'该 proxy 不能单独识别现役机组停机概率；OFF 情景用于显示若新建/重启需求不能延期时的物理压力。',
    })
write_csv(OUT_ROOT/'data/06_physical_stress_matrix.csv', stress_out)

# ---------------- 07 project watchlist ----------------
# 2036 gross technical known-project path, before execution/availability risk.
tech36={r['project_id']:f(r['gross_technical_ktU']) for r in tech if r['year']=='2036'}
known_candidates=[]
for p in projects:
    if p['source_stage']=='Step4_V9_known' and p['lifecycle_type']=='pre_fid_dynamic' and tech36.get(p['project_id'],0)>0:
        known_candidates.append((tech36[p['project_id']],p))
known_candidates.sort(reverse=True,key=lambda x:x[0])
watch=[]
for v,p in known_candidates[:12]:
    watch.append({
      'watch_type':'Known_preFID_2036_critical', 'project':p['project'], 'country':p['country'],
      '2036_gross_technical_ktU':v, 'option_capacity_ktU_y':f(p['capacity_ktU_y']),
      'earliest_FID_year':p['earliest_fid_year'], 'construction_years':p['construction_years'],
      'hurdle_base_2026real_USD_lb':f(p['hurdle_base_2026real_USD_lb']),
      'realization_ceiling':f(p['p_realization_ceiling']), 'capacity_quality':p['capacity_quality'],
      'why_watch':'2036 gross technical supply relies on this pre-FID project; delay affects late-decade gap more than spot price can repair.',
      'status_source_url':p['status_source_url'],'capacity_source_url':p['capacity_source_url'],'schedule_source_url':p['schedule_source_url']
    })
frontier=[p for p in projects if p['source_stage']=='Step5C_frontier' and p['central_inclusion']=='1']
frontier.sort(key=lambda p:f(p['capacity_ktU_y']) or 0, reverse=True)
for p in frontier[:10]:
    watch.append({
      'watch_type':'Frontier_option', 'project':p['project'], 'country':p['country'],
      '2036_gross_technical_ktU':'', 'option_capacity_ktU_y':f(p['capacity_ktU_y']),
      'earliest_FID_year':p['earliest_fid_year'], 'construction_years':p['construction_years'],
      'hurdle_base_2026real_USD_lb':f(p['hurdle_base_2026real_USD_lb']),
      'realization_ceiling':f(p['p_realization_ceiling']), 'capacity_quality':p['capacity_quality'],
      'why_watch':'Frontier supply reduces the right tail only if economics, permitting and timing all convert into actual FID/production; high price alone does not guarantee realization.',
      'status_source_url':p['status_source_url'],'capacity_source_url':p['capacity_source_url'],'schedule_source_url':p['schedule_source_url']
    })
write_csv(OUT_ROOT/'data/07_project_watchlist.csv', watch)

# ---------------- 08 supply concentration ----------------
conc=[]
for y in [2027,2030,2033,2035,2036]:
    sub=[r for r in tech if int(r['year'])==y]
    total=sum(f(r['gross_technical_ktU']) or 0 for r in sub)
    bylife=defaultdict(float); bycountry=defaultdict(float)
    for r in sub:
        v=f(r['gross_technical_ktU']) or 0
        bylife[r['lifecycle_type']]+=v; bycountry[r['country']]+=v
    for k,v in sorted(bylife.items(), key=lambda x:-x[1]):
        conc.append({'year':y,'dimension':'lifecycle_type','bucket':k,'gross_technical_ktU':v,'share_of_year_total':v/total if total else None,'year_total_gross_technical_ktU':total,'warning':'Gross technical path before execution/availability/geopolitical realization.'})
    for k,v in sorted(bycountry.items(), key=lambda x:-x[1]):
        conc.append({'year':y,'dimension':'country','bucket':k,'gross_technical_ktU':v,'share_of_year_total':v/total if total else None,'year_total_gross_technical_ktU':total,'warning':'Gross technical path before execution/availability/geopolitical realization.'})
write_csv(OUT_ROOT/'data/08_supply_concentration.csv', conc)

# ---------------- 09 monitoring triggers ----------------
monitor=[
 {'priority':'P0','frequency':'Monthly/quarterly','variable':'Long-term uranium price','base_anchor_or_model_threshold':f'${current_lt:.1f}/lb anchor; ${floor50:.1f} 50% draw floor; ${floor45:.1f} 45% floor','bullish_or_tightening_signal':f'Sustained LT > ${floor50:.0f} validates investment repricing; > ${floor45:.0f} indicates stronger inventory-preservation pressure.','falsification_or_easing_signal':'LT remains near/below current anchor while FIDs accelerate and contracting gaps shrink.','action':'Update price path / FID state; do not use spot alone to trigger mine supply.','source_or_input':'Cameco price anchor + Step5 sensitivity'},
 {'priority':'P0','frequency':'Monthly/quarterly','variable':'Spot/LT basis','base_anchor_or_model_threshold':f'Current model anchor spot/LT={current_spot/current_lt:.3f}; tight-market magnitude prior centered ~1.40x','bullish_or_tightening_signal':'Spot/LT moves persistently >1.2x and approaches ~1.4x while inventory release rates rise.','falsification_or_easing_signal':'Spot trades below LT or basis normalizes while contracting/FID response improves.','action':'Classify transition from contract-led market to scarcity-led market; rerun spot state assumptions if basis behavior changes structurally.','source_or_input':'02_model_registry.csv + Step5-D calibration'},
 {'priority':'P0','frequency':'Quarterly','variable':'Critical pre-FID project schedules','base_anchor_or_model_threshold':'2036 known gross technical path contains ~35.6 ktU pre_fid_dynamic supply','bullish_or_tightening_signal':'Major projects (especially Arrow/PLS/Gryphon/Roughrider/Midwest) slip FID or first production by >=1 year.','falsification_or_easing_signal':'FID/financing/construction occur on or ahead of model schedule.','action':'Update project technical path and correlated execution assumptions, then rerun Step5-D.','source_or_input':'07_project_watchlist.csv'},
 {'priority':'P0','frequency':'Annual; interim when disclosed','variable':'Utility inventory pool','base_anchor_or_model_threshold':f'{tracked_pool:.0f} ktU tracked pool; stress tests at 0.8x and 0.6x effective access','bullish_or_tightening_signal':'Observed inventory declines and/or evidence suggests effective mobilizable pool is nearer 0.8x or lower.','falsification_or_easing_signal':'Inventories remain high/rising and cross-region material proves more fungible than assumed.','action':'Recalibrate effective-pool multiplier and xcrit/draw-cap priors.','source_or_input':'EIA + ESA + WNA inventory anchors'},
 {'priority':'P0','frequency':'Annual/quarterly project tracking','variable':'Demand schedule vs WNA Lower/Reference','base_anchor_or_model_threshold':'Scarcity response is allowed only toward WNA Lower; existing reactor demand is not smoothly price-elastic.','bullish_or_tightening_signal':'Reference/Upper reactor build and restart schedules continue without slippage.','falsification_or_easing_signal':'New-build/restart schedules materially move toward Lower path.','action':'Update demand wrapper; this variable dominates hard-shortage proxy sensitivity.','source_or_input':'01_annual_inputs.csv + Step5-D hierarchy'},
 {'priority':'P1','frequency':'Quarterly','variable':'Frontier FID conversion','base_anchor_or_model_threshold':'Central frontier option capacity ~19.65 ktU/y, with many low realization ceilings','bullish_or_tightening_signal':'LT crosses project hurdle bands but projects still fail to FID/permitting—evidence that price-only supply response is weaker.','falsification_or_easing_signal':'McArthur expansion/Trekkopje/other options FID earlier and ramp faster than assumed.','action':'Update frontier p_realization, delays, capacity and avoid double count with known universe.','source_or_input':'03b_frontier_projects_detail.csv'},
 {'priority':'P1','frequency':'Monthly','variable':'Financial inventory demand (SPUT/Yellow Cake)','base_anchor_or_model_threshold':'Base excludes incremental SPUT demand while SPUT is at discount to NAV','bullish_or_tightening_signal':'SPUT trades at sustained premium and resumes material physical purchases; financial demand competes for spot inventory.','falsification_or_easing_signal':'Persistent discount/no purchases or inventory is sold/redeployed.','action':'Add financial-demand shock to spot sensitivity, not to utility inventory pool.','source_or_input':'02_model_registry.csv market anchors'},
 {'priority':'P1','frequency':'Annual','variable':'US contracting gap','base_anchor_or_model_threshold':'2026-35 max contracted deliveries 174 Mlb vs 186 Mlb unfilled requirements in Step5 anchor','bullish_or_tightening_signal':'Unfilled requirements stay high while term contracting accelerates without equivalent new supply commitments.','falsification_or_easing_signal':'Unfilled requirements shrink together with new mine commitments and inventory remains comfortable.','action':'Use contracting as leading LT signal; do not equate contracted volumes with immediate physical shortage.','source_or_input':'EIA UMAR market anchor'},
 {'priority':'P2','frequency':'Semiannual/annual','variable':'Structural secondary supply','base_anchor_or_model_threshold':'Base falls from 3.5 ktU in 2027 toward 2.5 ktU in 2035-36','bullish_or_tightening_signal':'Secondary supply underperforms Base path.','falsification_or_easing_signal':'Government/commercial secondary releases materially exceed Base path.','action':'Update 01_annual_inputs and rerun both balance and price distributions.','source_or_input':'01_annual_inputs.csv'},
]
write_csv(OUT_ROOT/'data/09_monitoring_triggers.csv', monitor)

# ---------------- 10 falsification tests ----------------
falsify=[
 {'test_id':'F01','hypothesis_component':'Demand growth','what_would_falsify_or_weaken':'Actual reactor requirements / commissioning path converges to or below WNA Lower for multiple years.','model_effect':'Less annual deficit, slower inventory draw, lower LT and spot tail.','update_needed':'Demand scenario/wrapper'},
 {'test_id':'F02','hypothesis_component':'Inventory scarcity','what_would_falsify_or_weaken':'Observable utility inventory remains high and evidence supports effective pool >1.15x baseline or larger sustainable draw caps.','model_effect':'Delays/nonlinearizes scarcity transition to later years; reduces spot-tail probability.','update_needed':'Effective pool, cumulative draw cap, xcrit'},
 {'test_id':'F03','hypothesis_component':'Supply execution risk','what_would_falsify_or_weaken':'Large pre-FID projects reach FID/construction/production ahead of schedules and frontier options convert rapidly.','model_effect':'Raises 2032-36 primary supply and reduces right-censored LT tail.','update_needed':'Project paths, delays, realization ceilings'},
 {'test_id':'F04','hypothesis_component':'Price-only saturation','what_would_falsify_or_weaken':'Previously omitted high-capacity projects with credible <=2032 production dates enter the investable universe.','model_effect':'A higher price can call materially more timely supply than current model permits.','update_needed':'Expand project universe before interpreting >$300 tail'},
 {'test_id':'F05','hypothesis_component':'Scarcity demand rigidity','what_would_falsify_or_weaken':'Fuel-cycle constraints, policy changes or economics cause existing/restart demand to respond more strongly than the WNA-Lower envelope assumption.','model_effect':'Physical shortage risk and spot tail fall; but semantics must distinguish existing fleet from new-build/restart.','update_needed':'Demand hierarchy / rigid-demand floor'},
 {'test_id':'F06','hypothesis_component':'Financial demand neutrality','what_would_falsify_or_weaken':'Large financial holders become net sellers or sustained discounts prevent purchases during tight periods.','model_effect':'Reduces spot competition for inventory relative to a financial-demand shock case.','update_needed':'Financial-demand module only'},
]
write_csv(OUT_ROOT/'data/10_falsification_tests.csv', falsify)

# ---------------- 11 sources crosswalk ----------------
# Pass through source registry with Step6 role.
src_out=[]
for r in sources:
    role=[]
    topics=r['topics'].lower()
    if 'price' in topics: role.append('price_anchor_or_basis')
    if 'inventory' in topics: role.append('inventory_calibration')
    if 'demand' in topics or 'reactor' in topics: role.append('demand_or_elasticity')
    if 'contract' in topics: role.append('contracting_signal')
    if 'financial' in topics: role.append('financial_inventory_context')
    src_out.append({**r,'Step6_role':' | '.join(role) if role else 'upstream_model_source'})
write_csv(OUT_ROOT/'data/11_sources_crosswalk.csv', src_out)

# ---------------- 12 Step6 checks ----------------
checks=[]
def chk(name, ok, actual, expected, note=''):
    checks.append({'stage':'Step6','check':name,'status':'PASS' if ok else 'FAIL','actual':actual,'expected':expected,'note':note})
chk('All inherited Step5 checks PASS', all(r['status']=='PASS' for r in checks5), f"{sum(r['status']=='PASS' for r in checks5)}/{len(checks5)} PASS", f'{len(checks5)}/{len(checks5)} PASS')
share_sum=sum(f(r['world_share']) for r in tail)
chk('LT regime bucket shares sum to 1', abs(share_sum-1)<1e-9, share_sum, 1.0)
for r in annual:
    y=r['year']; finite=f(r['spot_finite_spot_share']); bound=f(r['spot_LT_model_boundary_probability']); dys=f(r['spot_market_dysfunction_probability']); hard=f(r['spot_hard_physical_shortage_proxy_probability'])
    chk(f'{y} spot state shares reconcile', abs((finite+bound+dys+hard)-1)<1e-8, finite+bound+dys+hard, 1.0)
    lo=f(r['spot_prob_spot_gt_200_finite_lower_bound']); hi=f(r['spot_prob_spot_gt_200_or_unresolved_upper_bound'])
    chk(f'{y} Spot>$200 lower<=upper', lo<=hi+1e-12, f'{lo:.6f}<={hi:.6f}', 'ordered')
chk('2036 price saturation still leaves deficit', -f(aN['base_balance_at_price_saturation_ktU'])>0, -f(aN['base_balance_at_price_saturation_ktU']), '>0 ktU')
# delay finite prices nondecreasing; unresolved from 2032 onward
finite_delay=[(int(r['action_year']), f(r['required_sustained_LT_price_2026real_USD_lb'])) for r in delay if r['required_sustained_LT_price_2026real_USD_lb']]
chk('Finite delay penalty prices nondecreasing', all(finite_delay[i][1]<=finite_delay[i+1][1]+1e-12 for i in range(len(finite_delay)-1)), finite_delay, 'nondecreasing')
unres=[int(r['action_year']) for r in delay if not r['required_sustained_LT_price_2026real_USD_lb']]
chk('No finite 50% target solution from 2032 onward', unres==[2032,2033,2034], unres, '[2032,2033,2034]')
# 2036 pre-FID concentration reconciliation
tech36_rows=[r for r in tech if r['year']=='2036']
total36=sum(f(r['gross_technical_ktU']) for r in tech36_rows)
prefid36=sum(f(r['gross_technical_ktU']) for r in tech36_rows if r['lifecycle_type']=='pre_fid_dynamic')
chk('2036 gross technical supply positive', total36>0, total36, '>0')
chk('2036 pre-FID share is material', prefid36/total36>0.25, prefid36/total36, '>25%', 'Used only as gross technical concentration indicator, not P50 supply.')
write_csv(OUT_ROOT/'data/12_checks.csv', checks)

# ---------------- report ----------------
# selected stress metrics
stress_key={(int(r['year']),f(r['effective_inventory_shock_multiplier']),r['scarcity_newbuild_demand_response_to_WNA_Lower']):f(r['dysfunction_or_hard_shortage_proxy_probability']) for r in stress}
# concentration 2036
bylife=defaultdict(float); bycountry=defaultdict(float)
for r in tech36_rows:
    v=f(r['gross_technical_ktU']); bylife[r['lifecycle_type']]+=v; bycountry[r['country']]+=v
canada=bycountry['Canada']; kaz=bycountry['Kazakhstan']
arrow=next((v for v,p in known_candidates if p['project']=='Rook I / Arrow'),0)
frontier_total=sum(f(p['capacity_ktU_y']) for p in projects if p['source_stage']=='Step5C_frontier' and p['central_inclusion']=='1')

report=f'''# 铀需求供给研究 — Step6 最终综合与投资监控框架 V1

## 0. Step6 Gate

**结论：CONDITIONAL PASS，可进入最终使用与滚动更新阶段。**

Step6 不再重新发明一套价格模型，而是把 Step5 已审计通过的需求、矿山技术供给、库存、长期合同价（LT）清算、Spot 稀缺状态机和联合 Monte Carlo 结果，转换成可以直接用于判断、跟踪和复核的最终结论。

需要保留三个硬边界：

1. **LT 是投资/长期合同信号，不是逐年自由浮动的现货预测。** 2027 起的 LT P50 ≈ ${f(a0['lt_LT_required_real_P50_USD_lb']):.1f}/lb（2026 real）应理解为持续的投资清算 floor。
2. **约 {pct(f(tail[3]['world_share']))} 的联合世界在 $300/lb 模型边界仍未满足各自库存目标。** 这部分是右删失（censored）尾部，不能把 $300 当作真实 P90 或确定目标价。
3. **hard physical shortage proxy 不是现役机组停机概率。** 当前模型先允许新建/重启/时间表需求向 WNA Lower 路径延期；只有该缓冲仍不足时才进入物理短缺 proxy。

因此，Step6 的目标不是给出一个“2036 铀一定涨到多少”的单点答案，而是回答四个问题：

- 什么价格足以让供给投资开始响应；
- 什么时候“价格上涨”已经无法弥补“时间不够”；
- 库存从缓冲器转成约束器时，Spot 为什么会非线性跳升；
- 哪些数据变化会证伪、推迟或强化这一结论。

---

## 1. 最终结论

### 1.1 核心矛盾不是“地下没有铀”，而是“合格供给能否按时转成可交付产量”

Reference demand 从 2027 年 {d0:.1f} ktU/y 增长到 2036 年 {dN:.1f} ktU/y，九年复合增速约 {pct(demand_cagr,2)}。在 $95.5/lb 的长期价锚下，已知项目 primary P50 从 {p0:.1f} ktU/y 增至 {pN:.1f} ktU/y，复合增速约 {pct(primary_cagr,2)}，明显慢于需求。

到 2036 年：

- Reference demand：**{dN:.1f} ktU**；
- Base structural secondary：**{f(aN['base_Base_structural_secondary_ktU']):.1f} ktU**；
- 当前 LT 下 primary P50：**{pN:.1f} ktU**；
- 年度缺口：**{-f(aN['base_balance_at_95_5_ktU']):.1f} ktU**。

更关键的是，即使把价格提高到已知项目的 price-only saturation，2036 primary P50 也只有 **{sat_pN:.1f} ktU**，比当前 LT 情形只多 **{extra_sat_2036:.1f} ktU**，年度缺口仍有 **{-f(aN['base_balance_at_price_saturation_ktU']):.1f} ktU**。

推导关系很直接：**高价格可以改变未 FID 项目的经济性，但不能把已经错过的许可、融资、建设和爬坡时间倒流。** 因此 2034–2036 的风险不是传统静态成本曲线意义上的“再涨一点价就会有更多矿出来”，而是时间、项目执行和新项目 universe 的问题。

### 1.2 长期合同价只需要温和上调，就能解决中位情景的一部分问题；但越晚行动，所需价格非线性上升

在 Reference demand + Base secondary + known-project median execution 下：

- 若 2027 起长期价维持约 **${floor50:.1f}/lb（2026 real）**，2036 前累计 gross deficit 可控制在 tracked pool 的 50% 以内；
- 若希望累计 draw 不超过 45%，需要约 **${floor45:.1f}/lb**；
- 若要求不超过 42%，现有已知项目 universe 已无有限价格解。

时间惩罚更重要。同一“2036 累计 draw ≤ 50% pool”目标：

|开始形成更高 LT 信号|所需持续 LT（2026 real）|相对 2026 行动的价格惩罚|
|---:|---:|---:|
|2026|$101.1|—|
|2027|$101.9|+$0.8|
|2028|$103.1|+$2.0|
|2029|$105.1|+$4.0|
|2030|$109.6|+$8.5|
|2031|$123.8|+$22.7|
|2032 起|**无有限解**|时间已经无法由价格完全补偿|

这说明长期合同市场的作用不是“预测未来 Spot”，而是**提前把未来稀缺转化成今天的 FID 与建设决策**。越早形成投资价格，越有可能用中等幅度的 LT 重估换来真实供应；越晚，市场越依赖库存和需求延期，Spot 的非线性风险越大。

### 1.3 联合分布不是“多数世界都要 $300”，而是“一个很厚的不可线性外推尾部”

Step5-D 的联合世界可分成四类：

|LT 清算状态|世界占比|中位所需 LT（2026 real）|解释|
|---|---:|---:|---|
|当前 $95.5 已足够|{pct(f(tail[0]['world_share']))}|${f(tail[0]['median_required_LT_USD_lb']):.1f}|库存/需求/执行组合较友好|
|$100–150 可解决|{pct(f(tail[1]['world_share']))}|${f(tail[1]['median_required_LT_USD_lb']):.1f}|温和到显著 LT 重估 + 供给响应可清算|
|$150–300 可解决|{pct(f(tail[2]['world_share']))}|${f(tail[2]['median_required_LT_USD_lb']):.1f}|高价仍有有限解，但情景已明显恶化|
|≥$300 模型边界|{pct(f(tail[3]['world_share']))}|≥$300|现有模型 universe/库存容忍度内无有限解|

因此可以同时成立两件事：

- **中心价格并不极端。** LT P50 仅约 ${f(a0['lt_LT_required_real_P50_USD_lb']):.1f}/lb；
- **右尾极厚。** {pct(f(tail[3]['world_share']))} 的世界不是“需要正好 $300”，而是“价格本身已经不再是足够的控制变量”。

这也是为什么最终报告不采用普通的 P10/P50/P90 单点表来描述 LT 尾部。

### 1.4 用户提出的“紧平衡温和上涨 → 库存约束触发后跳升”在模型中成立，但属于条件性机制

有限 Spot 世界的 conditional P50 在 2027–2033 年大致维持在 $96–99/lb（2026 real），2034 年约 **${f(annual[7]['spot_spot_real_conditional_P50_USD_lb']):.1f}**，2035 年约 **${f(annual[8]['spot_spot_real_conditional_P50_USD_lb']):.1f}**，到 2036 年跳到 **${f(aN['spot_spot_real_conditional_P50_USD_lb']):.1f}**；2036 conditional P90 达 **${f(aN['spot_spot_real_conditional_P90_USD_lb']):.1f}**。

同时 2036：

- seller-scarcity 状态概率约 **{pct(f(aN['spot_seller_scarcity_probability']))}**；
- Spot>$200 的**有限世界下界**约 **{pct(f(aN['spot_prob_spot_gt_200_finite_lower_bound']))}**；
- 若把 unresolved tail 当作“可能高于 $200”，上界约 **{pct(f(aN['spot_prob_spot_gt_200_or_unresolved_upper_bound']))}**；
- LT 模型边界世界仍占 **{pct(f(aN['spot_LT_model_boundary_probability']))}**。

这与非线性命题一致：**库存可以在多年缺口中平滑现货价格，但库存释放能力有状态依赖和极限。当所需单年释放率接近 xcrit，Spot/LT basis 会迅速扩大，随后普通有限现货定价失去可靠性。**

但这里不能倒果为因。模型显示的是“一组需求、库存行为、供应执行假设下会出现非线性转换”，并没有证明 2036 必然发生价格爆发。

### 1.5 需求的“刚性”需要拆开：现役燃料需求很刚，但新建/重启时间表可以延期

Step5-D 没有给现役反应堆燃料需求设置平滑价格弹性；这符合核燃料成本占核电发电成本较低、短期停堆代价高的常识方向。但模型仍允许 scarcity response 向 WNA Lower 路径移动，主要代表新建、重启或时间表延期。

这项假设对物理尾部极其重要。2036 年 combined dysfunction + hard-shortage proxy：

|有效库存|允许向 WNA Lower 延期|不允许延期|
|---:|---:|---:|
|1.0×|{pct(stress_key[(2036,1.0,'ON')],2)}|{pct(stress_key[(2036,1.0,'OFF')],1)}|
|0.8×|{pct(stress_key[(2036,0.8,'ON')],2)}|{pct(stress_key[(2036,0.8,'OFF')],1)}|
|0.6×|{pct(stress_key[(2036,0.6,'ON')],2)}|{pct(stress_key[(2036,0.6,'OFF')],1)}|

这意味着：**Base 中 hard-shortage proxy 很低，并不是因为供给没有压力，而是因为模型假定在真正影响现役机组之前，会先有相当一部分新建/重启需求延期。** 如果未来要研究“核电站是否会因缺铀停机”，下一版必须单独构造 existing-fleet rigid demand floor，不能直接拿当前 proxy 代替。

---

## 2. 2027–2036 风险时间轴

|年份|Reference demand ktU|当前 LT 年缺口 ktU|有限 Spot P50|有限 Spot P90|卖方稀缺概率|Spot>$200 下界–上界|模型阶段|
|---:|---:|---:|---:|---:|---:|---:|---|
'''
for r in annual_dash:
    report += f"|{r['year']}|{r['Reference_demand_ktU']:.1f}|{r['annual_gap_current_LT_ktU']:.1f}|${r['spot_real_conditional_P50_USD_lb']:.1f}|${r['spot_real_conditional_P90_USD_lb']:.1f}|{pct(r['seller_scarcity_probability'])}|{pct(r['spot_gt_200_finite_lower_bound'])}–{pct(r['spot_gt_200_unresolved_upper_bound'])}|{r['phase']}|\n"

report += f'''

时间轴的核心不是某一年精确价格，而是**风险形态发生变化**：2034 前主要是库存桥接与 LT 定价问题；2035 开始 seller-scarcity 显著出现；2036 的有限 Spot 分布出现明显右偏，同时仍有右删失世界无法给出普通现货价格。

---

## 3. 供应侧：为什么高价格不能自动解决 2036

### 3.1 已知项目的 2036 gross technical path 高度依赖尚未 FID 的项目

2036 已知项目 gross technical path 合计约 **{total36:.1f} ktU**。其中：

- pre_fid_dynamic：**{prefid36:.1f} ktU，占 {pct(prefid36/total36)}**；
- Canada：**{canada:.1f} ktU，占 {pct(canada/total36)}**；
- Kazakhstan：**{kaz:.1f} ktU，占 {pct(kaz/total36)}**；
- Arrow 单项目 gross technical 约 **{arrow:.1f} ktU，占 {pct(arrow/total36)}**。

这些数字是**风险折减前的技术路径，不是 P50 产量预测**。它们的用途是告诉我们：如果几个大项目同时延迟，2036 的供应缺口会具有相关性；把项目失败全部按独立随机事件处理，可能低估系统性尾部。

优先监控的 known pre-FID 项目包括 Arrow、PLS、Gryphon、Roughrider、Midwest Main、Mkuju River，以及纳米比亚的 Etango/Tumas 等。详细字段和来源见 `07_project_watchlist.csv`。

### 3.2 Frontier supply 是必要的“宇宙扩展”，但不是高价必然供应

Step5-C/5-D 中央纳入的 frontier option capacity 合计约 **{frontier_total:.2f} ktU/y**。其中 McArthur River/Key Lake licensed-capacity expansion 约 3.3 ktU/y，Trekkopje restart 约 3.2 ktU/y，Yeelirrie 3.0 ktU/y，Kintyre 2.7 ktU/y。

但这些项目的 realization ceiling 差异很大，很多只有 15%–55%，因为政治、许可、资本开支、公司优先级和建设周期不能靠 uranium price 一项变量解决。联合扫描也证明这一点：

- 当前 LT $95.5：P50 cumulative deficit ≈ **{f(scan95['cum_deficit_P50_ktU']):.1f} ktU**，满足各世界自身库存目标的比例 **{pct(f(scan95['share_worlds_meeting_own_inventory_target']))}**；
- LT ≈ $120.5：P50 cumulative deficit ≈ **{f(scan120['cum_deficit_P50_ktU']):.1f} ktU**，满足比例 **{pct(f(scan120['share_worlds_meeting_own_inventory_target']))}**；
- LT $300：P50 cumulative deficit 仍 ≈ **{f(scan300['cum_deficit_P50_ktU']):.1f} ktU**，满足比例只提高到 **{pct(f(scan300['share_worlds_meeting_own_inventory_target']))}**。

从 $120.5 再提高到 $300，收益已经明显递减。这不是“铀价不重要”，而是**价格在足够高以后，边际约束从矿山经济性转移到了时间与执行**。

---

## 4. 库存：不是“有没有库存”，而是“谁持有、能不能动、愿意多快动”

Step5 可观察 inventory pool 为 **{tracked_pool:.1f} ktU**，由 US reactor operators、EU utilities 与 East Asia 公开口径拼接。它不是全球全部库存，也不是完全可互换的单一池。

模型把库存不确定性分成三层：

1. **有效可动员规模**：0.85–1.15× tracked pool 的先验；
2. **累计释放容忍度**：大约 38%–58%；
3. **单年释放临界 xcrit**：大约 19%–31%。

这三层解释了为什么“库存还能用很多年”与“Spot 可以突然紧张”并不矛盾：累计库存可能仍有相当余额，但如果某一年的即时缺口需要从剩余库存中抽出过高比例，市场会先出现 basis 扩张、供应商惜售、现货流动性恶化。

因此，季度/年度回归时最重要的不是机械计算 `总库存 / 年需求`，而是更新：区域库存、已签合同覆盖、库存可转移性、持有者行为和单年释放强度。

---

## 5. 对“铀价长期走势”的最终表达方式

### 5.1 不建议给出单一 2027–2036 Spot 路径

原因是 LT 和 Spot 的经济角色不同：LT 决定 FID/建设；Spot 是库存和短期稀缺的边际市场。若把两者强行并成一条连续曲线，会把最重要的非线性机制抹掉。

更合适的表达是三层：

- **投资价格层（LT）**：中心清算大约 $100–120/lb（2026 real），决定未来供给能否按时形成；
- **库存清算层（normal Spot）**：大部分年份可在 LT 附近上下波动，tight inventory 时 basis 扩张；
- **尾部层（dysfunction / censored）**：不再给出普通有限目标价，而用阈值概率、库存 stress 和项目失败条件描述。

### 5.2 对投资者真正有用的不是“目标价”，而是领先指标顺序

领先顺序应当是：

**长期合同价与签约 → FID/融资 → 建设与爬坡 → utility inventory/交付缺口 → Spot/LT basis → 极端 Spot。**

如果前四项已经改善，即使 Spot 很高，也可能意味着周期正在自我修复；反之，如果 Spot 尚未大涨，但 LT、合同与项目时间表持续恶化，风险可能已经在累积。

---

## 6. 证伪条件与上行风险

### 会显著削弱结论的证据

1. 实际 reactor requirements 连续向 WNA Lower 或更低收敛；
2. 可动员库存明显高于 1.15× baseline，且实际 draw tolerance 高于模型假设；
3. Arrow/PLS 等大型 pre-FID 项目和 frontier options 大量提前兑现；
4. 出现此前遗漏、但能够在 2032 前贡献大规模产量的可信项目；
5. 二次供应持续显著高于 Base path；
6. 实际需求对价格/燃料周期的响应比模型允许的 WNA-Lower 延期更强。

### 会强化右尾的证据

1. 大型项目出现**相关性延迟**，而不是独立小概率延迟；
2. 有效库存可用性更接近 0.8×甚至 0.6×；
3. Reference/Upper demand 兑现，且新建/重启项目不愿延期；
4. LT 上涨但无法推动 frontier FID，说明非价格约束更强；
5. SPUT 等金融持有者重新成为净买方，加剧 Spot 对可交易库存的竞争；
6. Kazakhstan、Canada 或关键转换/浓缩/燃料环节的系统性冲击改变可交付节奏。

---

## 7. 滚动跟踪框架

建议把 Step6 作为以后季度/半年度回归的固定面板，而不是每次重做整套研究。

### 每月/季度

- Cameco/UxC/TradeTech LT 与 Spot、Spot/LT basis；
- 大项目 FID、融资、许可、建设里程碑；
- SPUT/Yellow Cake 持仓及 SPUT premium/discount；
- 主要矿商产量指引、停产/减产、交付变化；
- 美国/欧洲 utility contracting 动态。

### 每半年

- 重新评估项目 hurdle、建设周期、realization ceiling；
- 重新检查 frontier universe，重点找“高价下 2032 前可落地产能”是否新增；
- 检查项目风险是否需要从独立抽样升级为国家/资本开支/许可相关性因子。

### 每年

- EIA/ESA/WNA demand、inventory、contract coverage 全量更新；
- 重估有效库存 pool、累计 draw cap 与 xcrit；
- 全量重跑 Step5-B / Step5-D，再由 Step6 自动刷新最终面板。

具体触发条件见 `09_monitoring_triggers.csv`，证伪测试见 `10_falsification_tests.csv`。

---

## 8. 最终判断

**对“未来铀市场可能出现非线性涨价”的判断：支持，但必须附条件。**

支持它的根本原因不是“需求一定无限刚性”，也不是“世界上没有铀”，而是：

1. 2027–2036 Reference demand 增长速度高于当前长期价下的 primary 供给兑现速度；
2. 2036 即使 price-only saturation，已知项目仍保留约 {-f(aN['base_balance_at_price_saturation_ktU']):.1f} ktU 年度缺口；
3. 长期合同价格若过晚上调，价格无法补偿项目时间损失，2032 后 known universe 对 50% inventory target 无有限解；
4. 库存可以多年吸收缺口，但单年释放率接近行为临界时 Spot basis 会非线性扩张；
5. 联合模型中，中心 LT 仍温和，但约 {pct(f(tail[3]['world_share']))} 的世界进入 ≥$300 的右删失边界，说明尾部由时间、执行、库存和需求共同决定。

因此最合理的基准判断不是“铀价长期单边暴涨”，而是：

> **中期 LT 需要维持足够高的投资激励，才能避免把供给问题推迟到 2030 年代中后期；如果长期合同/FID响应不足，而需求继续兑现，市场可能先经历多年紧平衡和温和重估，随后在库存释放约束变硬时出现显著的 Spot 非线性。**

反过来，只要长期价较早完成重估、关键项目按时 FID/建设、需求向 Lower 方向延期或库存比模型更充裕，这个极端尾部就会被显著削弱或推迟。

---

## 9. 数据与审计说明

- Step6 所有数值均从 `input_step5/data/` 的 Step5 整合审计 V2 表读取并程序化生成；不修改原 Step5 工作簿。
- Step5 继承的 {len(checks5)} 项检查在输入包中全部 PASS；Step6 另有 `12_checks.csv` 做状态份额、概率上下界、延迟价格单调性与供给集中度等二次检查。
- 市场锚点以 Step5 包中记录的 as-of 为准：Cameco Spot/LT 为 2026-07-31；SPUT 为 2026-08-14；库存与需求数据各自遵循 source registry 的 as-of。
- 价格单位除明确标注 nominal 外均为 **2026 real USD/lb U3O8**；需求/供给主要单位为 **ktU**。
- 所有原始外部 URL 见 `11_sources_crosswalk.csv`；项目级来源见 `07_project_watchlist.csv` 与 Step5 `03_projects_master.csv`。
'''
(OUT_ROOT/'铀需求供给研究_Step6_最终综合报告_V1.md').write_text(report,encoding='utf-8')

# ---------------- README ----------------
readme=f'''# 铀需求供给研究 — Step6 最终综合 V1

本包以 `铀需求供给研究_Step5_整合审计_V2` 为唯一上游数据底座，完成最终综合、风险时间轴、LT/Spot 分层表达、库存/延期敏感性、关键项目监控和证伪框架。

## 目录
- `铀需求供给研究_Step6_最终综合报告_V1.md`：最终报告。
- `data/`：Step6 面向程序读写的新表；CSV 为主数据源。
- `input_step5/data/`：自包含的 Step5 V2 整合 CSV 输入镜像。
- `model/Step6_synthesis.py`：可复现生成脚本。
- `铀需求供给研究_Step6_最终综合_V1.xlsx`：由 Step6 CSV 同源生成的审计工作簿（后续单独生成）。

## Step6 不做什么
- 不把 ≥$300 的 LT censored 世界伪装成 $300 的真实价格预测。
- 不把 hard physical shortage proxy 解释成现役核电站停机概率。
- 不使用 Spot 价格倒推矿山同年产量；FID 仍服从时间因果。
- 不覆盖或原地编辑 Step5 旧文件。

## 更新顺序
年度/重大事件更新时，先更新 Step5 输入并重跑 Step5-B / Step5-D；确认 Gate 与 checks 后，再运行 Step6 synthesis。不要只手工改 Step6 结论表。
'''
(OUT_ROOT/'README_Step6.md').write_text(readme,encoding='utf-8')

# ---------------- manifest ----------------

manifest=[]
for p in sorted((OUT_ROOT/'data').glob('*.csv')):
    rows=read_csv(p)
    cols=len(rows[0]) if rows else 0
    desc={
      '01_key_metrics.csv':'Step6 headline metrics and lineage.',
      '02_annual_risk_dashboard.csv':'2027-2036 demand/supply/LT/Spot/regime dashboard.',
      '03_price_regime_buckets.csv':'Joint LT clearing regimes including censored tail.',
      '04_inventory_target_sensitivity.csv':'Known-universe LT floor by cumulative inventory draw target.',
      '05_delay_penalty.csv':'Time-value of delayed LT repricing for 50% draw target.',
      '06_physical_stress_matrix.csv':'Inventory-access and demand-schedule-response physical stress.',
      '07_project_watchlist.csv':'Critical known pre-FID and frontier supply options.',
      '08_supply_concentration.csv':'Gross technical supply concentration by lifecycle and country.',
      '09_monitoring_triggers.csv':'Quarterly/annual variables, triggers and actions.',
      '10_falsification_tests.csv':'Explicit conditions that weaken the nonlinear scarcity thesis.',
      '11_sources_crosswalk.csv':'Step5 external sources mapped to Step6 roles.',
      '12_checks.csv':'Step6 reconciliation and semantic checks.',
    }.get(p.name,'')
    manifest.append({'file_name':p.name,'rows':len(rows),'columns':cols,'description':desc,'upstream':'Step5 integrated audit V2'})
write_csv(OUT_ROOT/'data/00_manifest.csv', manifest)

print('Built',OUT_ROOT)
print('Report length',len(report))
print('Step6 checks',sum(r['status']=='PASS' for r in checks),'/',len(checks))
