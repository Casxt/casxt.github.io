"""Recalculate textile manufacturer valuations from the accompanying CSV files.

Usage: python3 recalculate.py
Only Python's standard library is required. Operating forecasts are fixed inputs.
Cash amounts are reporting-currency units, not millions. Outputs use trading currency.
"""
import csv
import math
from pathlib import Path
from datetime import date

HERE=Path(__file__).resolve().parent
START=date(2026,9,5)

def read(name):
    with (HERE/name).open(encoding='utf-8-sig',newline='') as f:
        return list(csv.DictReader(f))

def number(row,key):
    return None if row[key]=='' else float(row[key])

def present_value(flows,rate):
    return sum(amount/(1+rate)**((dt-START).days/365) for dt,amount in flows)

def dated_return(price,flows):
    # All valid cases have a single negative investment followed by positive receipts.
    low,high=-0.95,1.0
    while present_value(flows,high)>price:
        high=2*high+1
    for _ in range(200):
        mid=(low+high)/2
        if present_value(flows,mid)>price:low=mid
        else:high=mid
    return (low+high)/2

def check(actual,expected,label):
    assert math.isclose(actual,expected,rel_tol=1e-9,abs_tol=1e-5),(label,actual,expected)

forecast={(r['company_id'],r['scenario'],int(r['year'])-2026):r for r in read('financial-forecast.csv')}
parameters={(r['company_id'],r['scenario'],int(r['year_index'])):r for r in read('valuation-parameters.csv')}
values={(r['company_id'],r['scenario'],int(r['year_index']),r['method']):r for r in read('valuation-methods.csv')}
returns={(r['company_id'],r['scenario'],int(r['horizon'])):r for r in read('holding-period-returns.csv')}
dividends=read('dividend-cashflows.csv')
results=[]

for key,f in forecast.items():
    company,scenario,y=key
    if y==0:
        # Y0 combines actual H1 with forecast H2. Main reproducible valuation chain starts Y1.
        continue
    if f['status']=='unfunded_mechanical_only':
        assert number(values[(*key,'Fusion')],'price_base') is None
        results.append({'company':company,'scenario':scenario,'year':2026+y,'status':'融资未解决，持续经营估值不适用'})
        continue
    p=parameters[key]
    growth,roe,ke,shares,fx=[float(p[k]) for k in ['g','roe','ke','shares','fx']]
    eps=float(f['full_parent_profit'])/shares/fx
    pe=(1+growth)*(1-growth/roe)/(ke-growth)
    pe_price=eps*pe
    dy=values[(*key,'DividendYield')]
    dy_price=(float(f['discretionary_dividend'])/shares/fx/(ke-growth)
              if number(dy,'price_base') is not None else None)
    blended=pe_price*float(values[(*key,'PE')]['weight'])+(dy_price or 0)*float(dy['weight'])
    check(pe_price,number(values[(*key,'PE')],'price_base'),(key,'PE'))
    if dy_price is not None:check(dy_price,number(dy,'price_base'),(key,'cash_dividend'))
    check(blended,number(values[(*key,'Fusion')],'price_base'),(key,'blended'))
    r=returns[key]
    end=date.fromisoformat(r['terminal_date'])
    flows=[(date.fromisoformat(z['date']),float(z['amount'])) for z in dividends
           if (z['company_id'],z['scenario'])==(company,scenario) and date.fromisoformat(z['date'])<=end]
    flows.append((end,blended))
    buy=present_value(flows,float(p['required_return']))
    irr=dated_return(float(p['price0']),flows)
    check(buy,float(r['max_buy_price']),(key,'11pct_buy'))
    check(irr,float(r['xirr']),(key,'dated_return'))
    results.append({'company':company,'scenario':scenario,'year':2026+y,'status':'条件测算',
                    'eps_trading_currency':eps,'pe':pe,'pe_price':pe_price,
                    'cash_dividend_price':dy_price,'blended_price':blended,
                    'required_return_buy_price':buy,'dated_annual_return':irr})

output=HERE/'recalculated-valuations.csv'
fields=list(dict.fromkeys(k for r in results for k in r))
with output.open('w',encoding='utf-8-sig',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(results)
print(f'完成 {len(results)} 个公司、情景与年度组合；写入 {output.name}。')
print('含聚阳Bear 10个融资未解决组合，其估值留空。经营预测作为固定输入，未自动重建。')
