"""Recalculate the published conditional valuation. Python 3 standard library only."""
import csv, math
from pathlib import Path
from datetime import date
BASE=Path(__file__).resolve().parent

def read(name):
    with (BASE/name).open(encoding="utf-8-sig",newline="") as f:
        return list(csv.DictReader(f))
def num(v): return float(v)
def close(a,b):
    if not math.isclose(a,b,rel_tol=1e-8,abs_tol=1e-7):
        raise AssertionError((a,b))
ops={(r["company"],r["scenario"],r["year"]):r for r in read("operating.csv")}
pars={(r["company"],r["scenario"],r["year"]):r for r in read("valuation-parameters.csv")}
flows=read("dated-cashflows.csv")
fin={(r["company"],r["scenario"],r["period"],r["metric"]):r["value"] for r in read("financial-forecast.csv")}
checked=0
for r in read("returns.csv"):
    key=(r["company"],r["scenario"],r["exit_year"])
    o,p=ops[key],pars[key]
    period="2026FY" if key[2]=="2026" else key[2]
    v=lambda k:float(fin[(key[0],key[1],period,k)])
    close(v("revenue"),num(o["revenue"]))
    close(v("net_parent"),num(o["net_parent"]))
    close(v("net_profit")-v("net_minority"),v("net_parent"))
    if int(key[2])<2036:
        nex=ops[(key[0],key[1],str(int(key[2])+1))]
        close(num(nex["revenue"])/num(o["revenue"])-1,num(p["growth_next"]))
    if not r["exit_price"]:
        assert o["whole_path_financed"]=="0"
        continue
    growth=min(.15,max(-.10,num(p["growth_next"])))
    pe=min(num(p["pe_cap"]),max(num(p["pe_floor"]),(1+num(p["window"])*growth)*num(p["quality"])/num(p["ke"])))
    price=num(o["net_parent"])/num(o["shares"])*pe
    close(price,num(r["exit_price"]))
    rows=[f for f in flows if (f["company"],f["scenario"],f["exit_year"])==key and f["value"]]
    start=date(2026,9,4)
    cf=[((date.fromisoformat(f["date"])-start).days/365,num(f["value"])) for f in rows]
    future=[(t,v) for t,v in cf if t>0]
    pv=sum(v/(1+num(p["ke"]))**t for t,v in future)
    close(pv,num(r["buy_price_for_11pct"]))
    def npv(rate):return sum(v/(1+rate)**t for t,v in cf)
    lo,hi=-.999999,2.
    while npv(hi)>0 and hi<1e20: hi*=2
    assert npv(lo)*npv(hi)<0
    for _ in range(160):
        mid=(lo+hi)/2
        if npv(mid)>0:lo=mid
        else:hi=mid
    close((lo+hi)/2,num(r["xirr"]))
    checked+=1
print(f"Verified {len(ops)} annual operating cases; {checked} financed PE/PV/XIRR results. Unfunded cases remain unavailable.")
