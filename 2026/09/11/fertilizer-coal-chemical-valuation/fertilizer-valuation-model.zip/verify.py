"""Independent arithmetic verification of frozen public model tables. Python 3 stdlib only."""
from pathlib import Path
from datetime import date
from collections import defaultdict
import csv, json, math
ROOT=Path(__file__).resolve().parent
counts=defaultdict(int)
def read(d,n):
 if d.name=='yonfer':n=n.replace('_v013','_v018').replace('_v014','_v018')
 return list(csv.DictReader((d/(n+'.csv')).open(encoding='utf-8-sig')))
def near(a,b,label):
 assert math.isclose(float(a),float(b),rel_tol=1e-8,abs_tol=1e-5),(label,a,b)
 counts[label]+=1
def time(a,b):return (date.fromisoformat(a)-date.fromisoformat(b)).days/365
for d in ROOT.iterdir():
 if not d.is_dir() or d.name=="xlx":continue
 cfg=json.loads((d/'operating-inputs.json').read_text())
 groups=defaultdict(float)
 for r in read(d,'group_forecast_v013'):groups[r['scenario'],r['fiscal_year']]+=float(r['revenue'])
 for r in read(d,'financial_forecast_v013'):
  v=lambda k:float(r[k])
  near(groups[r['scenario'],r['fiscal_year']],v('revenue'),'segment_sum')
  near(v('revenue')-v('cash_cogs')-v('opex')-v('depreciation'),v('ebit'),'ebit')
  near(v('profit_before_tax')-v('cash_tax'),v('group_profit'),'profit')
  near(v('group_profit')-v('nci_profit'),v('parent_profit'),'parent_profit')
  near(v('parent_profit')/v('shares_million'),v('eps_proxy'),'eps')
  near(v('ebit')-v('operating_cash_tax')+v('depreciation')-v('capex')-v('delta_nwc'),v('fcff'),'fcff')
 ev=defaultdict(float)
 for r in read(d,'valuation_cashflow_v014'):
  if r['included_in_value']!='True':continue
  pv=float(r['amount'])/(1+float(r['discount_rate']))**time(r['cash_date'],r['valuation_date'])
  near(pv,r['present_value'],'discount')
  ev[r['scenario'],r['valuation_date'],r['bound']]+=pv
 values={}
 for r in read(d,'valuation_v014'):values[r['scenario'],r['valuation_date'],r['bound'],r['method']]=r['price_cny']
 for r in read(d,'valuation_bridge_v014'):
  if not r['enterprise_value']:continue
  v=lambda k:float(r[k]); key=r['scenario'],r['valuation_date'],r['bound']
  near(ev[key],v('enterprise_value'),'enterprise_value')
  eq=v('enterprise_value')-v('interest_bearing_debt')+v('surplus_cash')+v('non_operating_assets')-v('nci_value')-v('other_claims')
  near(eq,v('equity_value'),'equity_bridge')
  q=values.get(key+('DCF',))
  if q:near(eq/cfg['shares_million'],q,'dcf_per_share')
 for r in read(d,'valuation_fusion_v014'):
  if not r['price_cny']:continue
  key=r['scenario'],r['valuation_date'],r['bound']
  near(.6*float(values[key+('DCF',)])+.4*float(values[key+('PE',)]),r['price_cny'],'fusion')
 flows=defaultdict(list)
 for r in read(d,'return_cashflows_v014'):
  if 'scenario' in r:flows[r['scenario'],r['exit_date'],r['bound'],r['dividend_tax_assumption']].append(r)
 for r in read(d,'returns_v014'):
  if not r['threshold_buy_cny']:continue
  fs=flows[r['scenario'],r['exit_date'],r['bound'],r['dividend_tax_assumption']]
  future=[x for x in fs if x['component']!='purchase']
  if not fs:
   for f in read(d,'financial_forecast_v013'):
    if f['scenario']!=r['scenario'] or f['period_end']>r['exit_date']:continue
    div=float(f['dps_proxy'])
    if f['fiscal_year']=='2026':div=0 if cfg['committed_parent_dividend_h2']>0 else div*112/184
    future.append({'amount':div*(1-float(r['dividend_tax_assumption'])),'cash_date':f['period_end']})
   future.append({'amount':float(r['target_cny'])*.999,'cash_date':r['exit_date']})
  threshold=sum(float(x['amount'])/1.11**time(x['cash_date'],'2026-09-10')for x in future)/1.001
  near(threshold,r['threshold_buy_cny'],'threshold')
  if r['xirr']:
   rate=float(r['xirr']);npv=sum(float(x['amount'])/(1+rate)**time(x['cash_date'],'2026-09-10')for x in fs)
   near(npv,0,'xirr_equation')
print(json.dumps({'passed':True,'checks':dict(counts),'total':sum(counts.values())},ensure_ascii=False,indent=2))

import runpy
runpy.run_path(str(ROOT/"verify_xlx.py"),run_name="__main__")
