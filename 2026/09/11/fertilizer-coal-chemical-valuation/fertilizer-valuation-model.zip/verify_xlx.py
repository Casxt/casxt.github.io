"""Independent checks of the XLX conditional model; no writes or external dependencies."""
from pathlib import Path
from datetime import date
from collections import defaultdict
import csv,json,math
ROOT=Path(__file__).resolve().parent/'xlx'
def read(n):return list(csv.DictReader((ROOT/(n+'.csv')).open(encoding='utf-8-sig')))
P=json.loads((ROOT/'valuation-parameters.json').read_text());counts=defaultdict(int)
def near(a,b,label):
 assert math.isclose(float(a),float(b),rel_tol=1e-8,abs_tol=1e-5),(label,a,b)
 counts[label]+=1
def days(a,b):return (date.fromisoformat(a)-date.fromisoformat(b)).days/365
F=read('forecast_v006');C=read('valuation_cache_v007');V=read('valuation_v007');H=read('historical_financials_v002');I=read('interim_financials_v002')
lookup={(r['scenario'],r['year']):r for r in F};cache={(r['scenario'],r['date']):r for r in C}
ops=defaultdict(lambda:[0.,0.]);h1={(r['period'],r['metric_id']):r['value']for r in I}
for r in read('operating_forecast_v004'):
 near(float(r['revenue'])*float(r['gross_margin']),r['gross_profit'],'group_gross_profit')
 ops[r['scenario'],r['period']][0]+=float(r['revenue']);ops[r['scenario'],r['period']][1]+=float(r['gross_profit'])
for r in F:
 n=lambda k:float(r[k]);sc=r['scenario'];tax=P['tax_rates'][sc]
 near(ops[sc,r['period']][0],n('revenue'),'group_revenue_sum');near(ops[sc,r['period']][1],n('gross_profit'),'group_gross_profit_sum')
 near(n('gross_profit')-n('selling')-n('admin')-n('additional_losses')-n('penalty'),n('ebit'),'ebit')
 near(n('ebit')-n('interest'),n('profit_before_tax'),'pretax')
 near(n('profit_before_tax')-n('tax_expense'),n('group_profit'),'group_profit')
 near(n('group_profit')-n('nci_profit'),n('parent_profit'),'parent_profit')
 if r['eps_proxy']:near(n('parent_profit')/n('shares_million'),n('eps_proxy'),'eps')
 near(n('ebit')*(1-tax)+n('depreciation')-n('capex')-n('delta_operating_capital')-n('extra_operating_capital')-n('extra_cash_tax'),n('fcff_proxy'),'fcff')
 for k in r:
  if k.endswith('_residual'):near(n(k),0,'balance_'+k)
 near(n('bank_principal_due'),n('new_bank_borrowing'),'full_rollover');near(n('parent_dividend_model_paid'),0,'retained_parent_cash')
ev=defaultdict(float)
for r in read('cashflow_schedule_v007'):
 if r['included_in_value']!='True':continue
 pv=float(r['amount'])/(1+float(r['discount_rate']))**days(r['cash_date'],r['valuation_date'])
 near(pv,r['present_value'],'discount');ev[r['scenario'],r['valuation_date']]+=pv
for r in C:
 n=lambda k:float(r[k]);sc=r['scenario'];dt=r['date'];year=dt[:4];f=lookup[sc,year]
 near(ev[sc,dt],n('EV_RMB_million'),'enterprise_value')
 nci=(n('NCI_low')+n('NCI_high'))/2
 eq=n('EV_RMB_million')-n('bank_debt')-n('lease_debt')+n('surplus_cash')-nci
 near(eq/P['shares_million']/P['fx_CNY_per_HKD'],n('DCF_HKD'),'equity_fx_bridge')
 pp=float(f['parent_profit'])+(float(h1['2026H1','parent_profit'])if year=='2026'else 0)
 near(pp,n('parent_profit'),'annual_profit')
 eps=pp/P['shares_million']/P['fx_CNY_per_HKD'];near(eps*P['PE'][sc],n('PE_HKD'),'PE')
 near(n('parent_equity')/P['shares_million']/P['fx_CNY_per_HKD']*P['PB'][sc],n('PB_HKD'),'PB')
 near(eps*P['PR'][sc]*n('ROE_proxy')*100,n('PR_HKD'),'PR')
 if year=='2026':
  hist={x['metric_id']:float(x['value'])for x in H if x['period']=='2025'}
  start=hist['balance.total_equity']-hist['balance.nci_equity']
 else:start=float(f['parent_equity_open'])
 near(pp/((start+float(f['parent_equity_close']))/2),n('ROE_proxy'),'roe_full_year')
 terminal=lookup[sc,'2036'];cap=max(float(terminal['capex']),float(terminal['depreciation']))
 near(cap,n('terminal_capex'),'terminal_capex')
 tcf=float(terminal['ebit'])*(1-P['tax_rates'][sc])+float(terminal['depreciation'])-cap
 near(tcf,n('terminal_FCFF'),'terminal_fcff')
 near(tcf/.11/(1.11**days('2036-12-31',dt)),n('TV_PV'),'terminal_pv')
 if sc=='Bear':assert not r['fusion_HKD'];counts['bear_inapplicable']+=1
 else:near(.6*n('DCF_HKD')+.25*n('PE_HKD')+.15*n('PB_HKD'),n('fusion_HKD'),'weighted_value')
for r in V:
 sc=r['scenario'];method=r['method'];k={'DCF':'DCF_HKD','PE':'PE_HKD','PB':'PB_HKD','PR':'PR_HKD','fusion':'fusion_HKD','FUSION':'fusion_HKD'}.get(method)
 if sc=='Bear':assert not r['value'];counts['bear_prices_empty']+=1
 elif k and r['value']:near(r['value'],cache[sc,r['valuation_date']][k],'published_valuation')
for r in read('returns_v007'):
 assert r['official_total_return'].startswith('N/A');counts['unverified_return_absent']+=1
 if r['scenario']=='Bear':assert not r['buy_threshold_11pct_zero_dividend_HKD'];continue
 t=days(r['date'],'2026-09-10');near(t,r['years_actual365'],'elapsed_years')
 near(float(cache[r['scenario'],r['date']]['fusion_HKD'])/1.11**t,r['buy_threshold_11pct_zero_dividend_HKD'],'zero_dividend_threshold')
print(json.dumps({'company':'XLX','passed':True,'checks':dict(counts),'total':sum(counts.values())},ensure_ascii=False,indent=2))
