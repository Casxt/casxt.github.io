"""Validate the current growth-to-valuation model, without changing any input."""
import csv,math
from pathlib import Path
from datetime import date
P=Path(__file__).resolve().parent
def read(name):
    with (P/(name+'.csv')).open(encoding='utf-8-sig') as f:return list(csv.DictReader(f))
checks=0
def close(a,b):
    global checks
    assert math.isclose(float(a),float(b),rel_tol=1e-10,abs_tol=1e-9),(a,b)
    checks+=1
drivers=read('scenario_growth_inputs'); paths=read('EPS_paths'); anchors={r['company_id']:r for r in read('EPS_anchors')}
lookup={(r['company_id'],r['scenario'],r['year']):r for r in paths}
di={(r['company_id'],r['scenario'],r['year']):r for r in drivers}
assert len(di)==96 and len(lookup)==120
parts=['volume_NI_growth_contribution_pp','spread_NI_growth_contribution_pp','financing_NI_growth_contribution_pp','efficiency_NI_growth_contribution_pp','affiliate_NI_growth_contribution_pp','temporary_recovery_NI_growth_contribution_pp']
for r in drivers:
    q=((1+float(r['available_sales_capacity_proxy_growth_pct'])/100)*(1+float(r['net_hours_growth_pct'])/100)-1)*100
    close(q,r['quantity_growth_pct'])
    if r['scenario']=='Bull':
        cap=float(r['available_sales_capacity_proxy_growth_pct']);h=float(r['net_hours_growth_pct'])
        v=h*float(r['stock_hours_coefficient'])+cap*(1+h/100)*float(r['new_capacity_profit_density'])
        close(v,r['volume_NI_growth_contribution_pp'])
        close(sum(float(r[k]) for k in parts),r['operating_growth_before_depreciation_pct'])
    if r['scenario']=='Base':
        bull=di[r['company_id'],'Bull',r['year']]
        close(float(bull['EPS_growth_pct'])/2,r['EPS_growth_pct'])
for c,a in anchors.items():
    for sc in ['Bear','Base','Bull']:
        eps=float(a['EPS_CNY']);qi=100
        for year in range(2027,2032):
            r=lookup[c,sc,str(year)]
            if year>2027:
                x=di[c,sc,str(year)];eps*=1+float(x['EPS_growth_pct'])/100;qi*=1+float(x['quantity_growth_pct'])/100
            else: assert r['EPS_growth_pct']==''
            close(eps,r['EPS_CNY']);close(qi,r['quantity_index_2027_100'])
            close(eps*float(r['shares_million']),r['ordinary_profit_CNY_million'])
for r in read('growth_summary'):
    x=lookup[r['company_id'],r['scenario'],'2031'];a=anchors[r['company_id']]
    close(x['EPS_CNY'],r['EPS2031_CNY']);close((float(x['EPS_CNY'])/float(a['EPS_CNY']))**.25*100-100,r['EPS_CAGR_2027_2031_pct'])
    close((float(x['quantity_index_2027_100'])/100)**.25*100-100,r['quantity_CAGR_2027_2031_pct'])
# Independently reconstruct the operating/depreciation split and Base recurrence.
bridge={(r['company_id'],r['year']):r for r in read('EPS_operating_depreciation_bridge')}
dep={(r['scenario'],r['year']):float(r['ordinary_EPS_level_CNY']) for r in read('depreciation_schedule')}
for c,a in anchors.items():
    op=float(a['EPS_CNY']);prev=op
    for y in range(2028,2032):
        r=di[c,'Bull',str(y)];op*=1+float(r['operating_growth_before_depreciation_pct'])/100
        level=dep['Full_eligible',str(y)] if c=='CYPC' else 0
        total=op+level;z=bridge[c,str(y)]
        close(op,z['operating_EPS_CNY']);close(level,z['depreciation_EPS_level_CNY']);close(total,lookup[c,'Bull',str(y)]['EPS_CNY'])
        close((total/prev-1)*100,r['EPS_growth_pct']);prev=total
for r in read('growth_sensitivity'):
    close((float(r['EPS2031_CNY'])/float(lookup[r['company_id'],r['scenario'],'2031']['EPS_CNY'])-1)*100,r['change_vs_scenario_pct'])
# Historical proxy formulas and three-year medians.
from statistics import median
hist=read('historical_elasticities');hc={(r['company_id'],r['year']):r for r in read('historical_controls')}
for r in hist:
    if r['historical_stock_hours_PBT_proxy']:
        close((float(r['revenue_million'])-float(r['cost_million'])+float(r['depreciation_million']))/float(r['PBT_million']),r['historical_stock_hours_PBT_proxy'])
for r in read('calibrated_operating_parameters'):
    sample=[x for x in hist if x['company_id']==r['company_id'] and int(x['year'])>=2023 and x['historical_stock_hours_PBT_proxy']]
    close(median(float(x['historical_stock_hours_PBT_proxy']) for x in sample),r['stock_hours_coefficient'])
    close(median(float(x['historical_expansion_core_profit_share']) for x in sample),r['new_capacity_profit_density'])
pe={r['company_id']:r for r in read('PE_parameters')};values=read('valuation_components');vmap={r['result_id']:r for r in values}
for r in values:
    x=lookup[r['company_id'],r['earnings_scenario'],r['year']]
    close(x['EPS_CNY'],r['ordinary_EPS_CNY'])
    close(pe[r['company_id']][{'Bear':'PE_low','Base':'PE_base','Bull':'PE_high'}[r['multiple_scenario']]],r['PE'])
    close(float(r['ordinary_EPS_CNY'])*float(r['PE']),r['price_CNY'])
    close(float(r['ordinary_profit_CNY_million'])*float(r['PE']),r['ordinary_equity_CNY_million'])
returns=read('returns')
for r in returns:
    key=f"V_{r['company_id']}_{r['year']}_{r['earnings_scenario']}_{r['earnings_scenario']}"
    t=(date.fromisoformat(r['exit_date'])-date(2026,9,7)).days/365
    price=float(vmap[key]['price_CNY'])/float(r['FX_CNY_per_quote_currency'])
    close(t,r['holding_years_ACT365']);close(price,r['exit_price'])
    close(price/1.11**t,r['zero_dividend_buy_limit_11pct'])
    close((price/float(r['quote_reference']))**(1/t)-1,r['zero_dividend_exit_only_annual_return'])
    assert r['formal_admitted_dividends']==r['formal_total_return_XIRR']==''
for r in read('return_summary'):
    rows={x['earnings_scenario']:x for x in returns if x['security_id']==r['security_id'] and x['year']=='2031'}
    for sc,k in [('Bear','low'),('Base','base'),('Bull','high')]:
        close(rows[sc]['exit_price'],r['exit_price_'+k]);close(rows[sc]['zero_dividend_buy_limit_11pct'],r['zero_div_buy11_'+k])
    x=rows['Base'];close(x['zero_dividend_exit_only_annual_return'],r['exit_only_return_base'])
    close(float(x['quote_reference'])*1.11**float(x['holding_years_ACT365'])*float(x['FX_CNY_per_quote_currency'])/float(pe[r['company_id']]['PE_base']),r['required_EPS_for_11pct'])
assert len(values)==360 and len(returns)==165
print(f'PASS: {checks} numeric checks; 96 drivers, 120 EPS rows, 324 sensitivity result ratios, 360 valuation combinations, 165 returns; unknown dividends preserved.')
